"""Профиль, реферальная программа, топ богачей, заработок звёзд и команды меню."""
import logging
from datetime import datetime, timedelta

from aiogram import Router, Bot, F
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from app.handlers.common import (
    check_subscription,
    show_subscription_message,
    show_main_menu,
    show_earn_tasks,
    get_bot_username,
)
from app.keyboards.user import back_markup, main_menu_markup, top_period_markup
from app.services.settings import get_settings
from app.services.users import get_user, get_all_users, count_invited
from app.services.withdrawals import get_user_withdrawals
from html import escape

from app.config import ADMIN_IDS
from app.database import get_connection
from app.utils.currency import format_coins, format_stars

logger = logging.getLogger(__name__)
router = Router(name="menu")



def _build_profile_text(user: dict) -> str:
    reg_date = datetime.fromisoformat(user["registration_date"]).strftime("%m.%d.%Y")
    referrals_count = len(user.get("referrals", []))
    invited_count = count_invited(user["user_id"])
    tasks_count = user.get("tasks_done", 0)
    withdrawals_count = len(
        [w for w in get_user_withdrawals(user["user_id"]) if w["status"] == "Звезды отправлены"]
    )
    return (
        "🔵 <b>Мой профиль</b>\n"
        "▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        f"🆔 ID: <code>{user['user_id']}</code>\n"
        f"📅 Регистрация: {reg_date}\n\n"
        f"💰 Баланс: <b>{format_coins(user['casino_coins'])} 🪙</b> (≈ {format_stars(user['balance'])} ⭐ к выводу)\n"
        f"✅ Выполнено заданий: {tasks_count}\n"
        f"👥 Рефералов засчитано: {referrals_count} (перешло по ссылке: {invited_count})\n\n"
        "🏆 <b>Статистика</b>\n"
        f"💸 Всего выводов: {withdrawals_count}"
    )


async def _build_referral_text(bot: Bot, user: dict) -> str:
    settings = get_settings()
    referral_reward = settings.get("referral_reward", 1)
    referrals_count = len(user.get("referrals", []))
    invited_count = count_invited(user["user_id"])
    required = int(settings.get("referral_tasks_required", 5) or 5)

    bot_username = await get_bot_username(bot)
    referral_link = f"https://t.me/{bot_username}?start={user['user_id']}"
    return (
        "👥 <b>Реферальная программа</b>\n"
        "▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        f"Приглашай друзей и получай {format_stars(referral_reward)} ⭐ после того, как приглашённый выполнит {required} заданий.\n\n"
        "🔗 <b>Твоя реферальная ссылка</b>\n"
        "<i>Нажми, чтобы скопировать ссылку</i>\n"
        f"<code>{referral_link}</code>\n\n"
        "📊 <b>Статистика</b>\n"
        f"├ 👀 Перешло по ссылке: {invited_count}\n"
        f"├ ✅ Засчитано рефералов: {referrals_count}\n"
        f"└ ⭐️ Оплата за одного: {format_stars(referral_reward)}"
    )


def _build_top_text(period: str = "day", user_id: int | None = None) -> str:
    """Топ богачей по монетам (админы из .env не участвуют)."""
    rows = get_connection().execute(
        "SELECT user_id, first_name, last_name, casino_coins FROM users "
        "WHERE casino_coins > 0 AND frozen = 0 ORDER BY casino_coins DESC"
    ).fetchall()
    rows = [r for r in rows if r["user_id"] not in ADMIN_IDS]
    header = "🏆 <b>Топ богачей</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
    if not rows:
        return header + "Пока нет данных для топа!"
    medals = ["🥇", "🥈", "🥉"]
    lines = []
    for i, r in enumerate(rows[:10]):
        name = escape(f"{r['first_name'] or ''} {r['last_name'] or ''}".strip() or "Игрок")
        place = medals[i] if i < 3 else f"{i + 1}."
        lines.append(f"{place} {name} — {format_coins(r['casino_coins'])} 🪙")
    text = header + "\n".join(lines)
    if user_id is not None:
        for place, r in enumerate(rows, start=1):
            if r["user_id"] == user_id:
                text += f"\n\n📍 Твоё место: {place} · {format_coins(r['casino_coins'])} 🪙"
                break
    return text


@router.callback_query(F.data == "earn_stars")
async def earn_stars_callback(call: CallbackQuery, bot: Bot, state: FSMContext) -> None:
    user_id = call.from_user.id
    if not await check_subscription(bot, user_id):
        await show_subscription_message(bot, call.message.chat.id)
        return
    await call.answer()
    try:
        await bot.delete_message(call.message.chat.id, call.message.message_id)
    except Exception:
        pass
    shown = await show_earn_tasks(bot, call.message.chat.id, user_id, state)
    if not shown:
        await bot.send_message(call.message.chat.id, "😔 Сейчас нет доступных заданий. Загляните позже!")


@router.callback_query(F.data == "profile")
async def profile_callback(call: CallbackQuery, bot: Bot) -> None:
    user_id = call.from_user.id
    if not await check_subscription(bot, user_id):
        await show_subscription_message(bot, call.message.chat.id)
        return

    user = get_user(user_id)
    if not user:
        await call.answer("Пользователь не найден. Используйте /start.")
        return

    await bot.edit_message_text(
        chat_id=call.message.chat.id,
        message_id=call.message.message_id,
        text=_build_profile_text(user),
        reply_markup=back_markup("cancel"),
        parse_mode="HTML",
    )


@router.callback_query(F.data == "referral")
async def referral_callback(call: CallbackQuery, bot: Bot) -> None:
    user_id = call.from_user.id
    if not await check_subscription(bot, user_id):
        await show_subscription_message(bot, call.message.chat.id)
        return

    user = get_user(user_id)
    if not user:
        await call.answer("Пользователь не найден. Используйте /start.")
        return

    await bot.edit_message_text(
        chat_id=call.message.chat.id,
        message_id=call.message.message_id,
        text=await _build_referral_text(bot, user),
        reply_markup=back_markup("cancel"),
        parse_mode="HTML",
    )


@router.callback_query(F.data.startswith("top_"))
async def top_callback(call: CallbackQuery, bot: Bot) -> None:
    period = call.data.split("_")[1]
    await bot.edit_message_text(
        chat_id=call.message.chat.id,
        message_id=call.message.message_id,
        text=_build_top_text(period, call.from_user.id),
        reply_markup=top_period_markup(period),
        parse_mode="HTML",
    )


@router.callback_query(F.data == "cancel")
async def cancel_callback(call: CallbackQuery, bot: Bot) -> None:
    menu_text = (
        "🏠 <b>Главное меню</b>\n"
        "▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        "Выбирай действие ниже 👇"
    )
    await bot.edit_message_text(
        chat_id=call.message.chat.id,
        message_id=call.message.message_id,
        text=menu_text,
        reply_markup=main_menu_markup(),
        parse_mode="HTML",
    )


@router.callback_query(F.data == "none")
async def none_callback(call: CallbackQuery) -> None:
    await call.answer()



@router.message(Command("menu"))
async def menu_command(message: Message, bot: Bot) -> None:
    """Открыть главное меню."""
    user_id = message.from_user.id
    if not await check_subscription(bot, user_id):
        await show_subscription_message(bot, message.chat.id)
        return
    await show_main_menu(bot, message.chat.id)


@router.message(Command("earn"))
async def earn_command(message: Message, bot: Bot, state: FSMContext) -> None:
    """Показать доступные задания PiarFlow."""
    user_id = message.from_user.id
    if not await check_subscription(bot, user_id):
        await show_subscription_message(bot, message.chat.id)
        return
    shown = await show_earn_tasks(bot, message.chat.id, user_id, state)
    if not shown:
        await message.answer("😔 Сейчас нет доступных заданий. Загляните позже!")


@router.message(Command("profile"))
async def profile_command(message: Message, bot: Bot) -> None:
    """Показать профиль пользователя."""
    user_id = message.from_user.id
    if not await check_subscription(bot, user_id):
        await show_subscription_message(bot, message.chat.id)
        return

    user = get_user(user_id)
    if not user:
        await message.reply("Пользователь не найден. Используйте /start.")
        return

    await message.answer(
        _build_profile_text(user),
        reply_markup=back_markup("cancel"),
        parse_mode="HTML",
    )


@router.message(Command("referral"))
async def referral_command(message: Message, bot: Bot) -> None:
    """Показать реферальную ссылку и статистику."""
    user_id = message.from_user.id
    if not await check_subscription(bot, user_id):
        await show_subscription_message(bot, message.chat.id)
        return

    user = get_user(user_id)
    if not user:
        await message.reply("Пользователь не найден. Используйте /start.")
        return

    await message.answer(
        await _build_referral_text(bot, user),
        reply_markup=back_markup("cancel"),
        parse_mode="HTML",
    )


@router.message(Command("top"))
async def top_command(message: Message) -> None:
    """Показать топ богачей."""
    await message.answer(
        _build_top_text("day", message.from_user.id),
        reply_markup=top_period_markup("day"),
        parse_mode="HTML",
    )


