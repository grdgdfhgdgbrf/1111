"""
Хелперы для показа экранов бота с картинкой.

Как добавить картинку к любому экрану:
1. Положите PNG/JPG в папку images/ (см. app/config.py -> IMAGES_DIR)
   с именем, указанным в соответствующей константе IMAGE_* (app/config.py).
2. Больше ничего делать не нужно — send_screen сам найдёт файл и пришлёт
   сообщение как фото с подписью. Если файла нет — просто текстом, как сейчас.

Пример (уже используется в app/handlers/common.py):
    from app.config import IMAGE_MAIN_MENU
    from app.utils.images import send_screen

    await send_screen(bot, chat_id, "<b>Главное меню</b>", image=IMAGE_MAIN_MENU, reply_markup=...)
"""
import logging
from pathlib import Path
from typing import Optional

from aiogram import Bot
from aiogram.types import InlineKeyboardMarkup, FSInputFile, Message

from app.config import IMAGES_DIR

logger = logging.getLogger(__name__)


def _image_path(filename: Optional[str | Path]) -> Optional[Path]:
    if not filename:
        return None
    path = Path(IMAGES_DIR) / filename
    return path if path.is_file() else None


async def send_screen(
    bot: Bot,
    chat_id: int,
    text: str,
    image: Optional[str | Path] = None,
    reply_markup: Optional[InlineKeyboardMarkup] = None,
    parse_mode: str = "HTML",
) -> Message:
    """Отправляет НОВОЕ сообщение: с картинкой, если файл найден, иначе текстом."""
    path = _image_path(image)
    if path:
        return await bot.send_photo(
            chat_id,
            photo=FSInputFile(path),
            caption=text,
            reply_markup=reply_markup,
            parse_mode=parse_mode,
        )
    return await bot.send_message(
        chat_id,
        text=text,
        reply_markup=reply_markup,
        parse_mode=parse_mode,
    )


async def edit_screen(
    bot: Bot,
    chat_id: int,
    message_id: int,
    text: str,
    reply_markup: Optional[InlineKeyboardMarkup] = None,
    parse_mode: str = "HTML",
) -> None:
    """
    Редактирует существующее сообщение. Понимает оба случая: если исходное
    сообщение было текстовым — редактирует текст, если фото с подписью
    (пришло через send_screen с картинкой) — редактирует подпись.
    Используйте вместо bot.edit_message_text, если экран может быть с картинкой.
    """
    try:
        await bot.edit_message_text(
            chat_id=chat_id,
            message_id=message_id,
            text=text,
            reply_markup=reply_markup,
            parse_mode=parse_mode,
        )
    except Exception:
        await bot.edit_message_caption(
            chat_id=chat_id,
            message_id=message_id,
            caption=text,
            reply_markup=reply_markup,
            parse_mode=parse_mode,
        )
