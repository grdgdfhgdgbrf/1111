"""CRUD-операции над таблицей заданий (SQLite)."""
from typing import Optional

from app.database import get_connection


def get_all_tasks() -> list[dict]:
    conn = get_connection()
    rows = conn.execute("SELECT * FROM tasks ORDER BY id").fetchall()
    return [dict(r) for r in rows]


def get_task(task_id: int) -> Optional[dict]:
    conn = get_connection()
    row = conn.execute("SELECT * FROM tasks WHERE id = ?", (task_id,)).fetchone()
    return dict(row) if row else None


def get_available_tasks(completed_task_ids: list[int]) -> list[dict]:
    return [t for t in get_all_tasks() if t["id"] not in completed_task_ids]


def add_task(channel_id: str, link: str, reward: float) -> int:
    conn = get_connection()
    cur = conn.execute(
        "INSERT INTO tasks (channel_id, link, reward) VALUES (?, ?, ?)", (channel_id, link, reward)
    )
    conn.commit()
    return cur.lastrowid


def delete_task(task_id: int) -> None:
    conn = get_connection()
    conn.execute("DELETE FROM tasks WHERE id = ?", (task_id,))
    conn.commit()
