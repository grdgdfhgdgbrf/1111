"""Точные преобразования и отображение баланса для звёзд и казино-монет."""
from decimal import Decimal, InvalidOperation, ROUND_DOWN, ROUND_CEILING


DEFAULT_STAR_TO_COINS = 10_000  # курс по умолчанию: 1 ⭐ = 10 000 🪙 (0.1 ⭐ = 1 000 🪙)
MIN_RATE = 10
MAX_RATE = 10_000_000
_rate_cache: int | None = None


def _valid_rate(value) -> bool:
    return isinstance(value, int) and not isinstance(value, bool) and MIN_RATE <= value <= MAX_RATE and value % 10 == 0


def get_rate() -> int:
    """Текущий курс: сколько 🪙 стоит 1 ⭐. Меняется админом в «Настройки казино → Курс звёзд»."""
    global _rate_cache
    if _rate_cache is not None:
        return _rate_cache
    try:
        from app.database import get_connection
        row = get_connection().execute("SELECT star_rate FROM settings WHERE id = 1").fetchone()
        value = int(row["star_rate"]) if row and row["star_rate"] else DEFAULT_STAR_TO_COINS
    except Exception:
        return DEFAULT_STAR_TO_COINS  # БД ещё не готова — не кэшируем
    if not _valid_rate(value):
        value = DEFAULT_STAR_TO_COINS
    _rate_cache = value
    return value


def set_rate(value: int) -> int:
    """Меняет курс (🪙 за 1 ⭐) и пересчитывает все суммы в монетах пропорционально,
    чтобы стоимость в ⭐ у игроков, ставок, бонусов и заявок НЕ менялась."""
    global _rate_cache
    if not _valid_rate(value):
        raise ValueError(f"Курс: целое число от {MIN_RATE} до {MAX_RATE}, кратное 10")
    from app.database import get_connection
    old = get_rate()
    if value == old:
        return value
    k = value / old
    conn = get_connection()
    try:
        conn.execute("BEGIN IMMEDIATE")
        # кошельки игроков
        conn.execute("UPDATE users SET casino_coins = CAST(ROUND(casino_coins * ?) AS INTEGER) WHERE casino_coins != 0", (k,))
        # лимиты ставок и статистика казино
        conn.execute("UPDATE casino_settings SET min_bet = CAST(ROUND(min_bet * ?) AS INTEGER), max_bet = CAST(ROUND(max_bet * ?) AS INTEGER) WHERE id = 1", (k, k))
        conn.execute("UPDATE casino_stats SET total_won = ROUND(total_won * ?), total_lost = ROUND(total_lost * ?)", (k, k))
        # бонус
        conn.execute("UPDATE settings SET bonus_base = CAST(ROUND(bonus_base * ?) AS INTEGER), bonus_step = CAST(ROUND(bonus_step * ?) AS INTEGER) WHERE id = 1", (k, k))
        # ставки в незавершённых дуэлях
        conn.execute("UPDATE duels SET bet = CAST(ROUND(bet * ?) AS INTEGER) WHERE status IN ('pending', 'playing')", (k,))
        # ожидающие заявки на вывод: комиссия в монетах и курс переводятся на новый курс (возврат пойдёт по нему)
        for table in ("withdrawals", "casino_withdrawals"):
            conn.execute(
                f"UPDATE {table} SET fee_coins = CAST(ROUND(fee_coins * ?) AS INTEGER), rate = ? WHERE status = 'Ожидание'",
                (k, value),
            )
        conn.execute("UPDATE settings SET star_rate = ? WHERE id = 1", (value,))
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    _rate_cache = value
    return value


BALANCE_STEP = Decimal("0.001")
COIN_STEP = 1  # минимальный шаг ставок/сумм в монетах


def floor_stars(value: int | float | str | Decimal) -> float:
    """Округляет баланс вниз до 0.001 ⭐."""
    try:
        amount = Decimal(str(value))
    except (InvalidOperation, ValueError, TypeError):
        raise ValueError("Некорректная сумма звёзд")
    if not amount.is_finite():
        raise ValueError("Некорректная сумма звёзд")
    return float(amount.quantize(BALANCE_STEP, rounding=ROUND_DOWN))


def parse_stars(raw: str, *, allow_zero: bool = False) -> float:
    text = raw.strip().replace(",", ".")
    try:
        amount = Decimal(text)
    except (InvalidOperation, ValueError):
        raise ValueError("Введите сумму числом")
    if not amount.is_finite() or amount < 0 or (amount == 0 and not allow_zero):
        raise ValueError("Сумма должна быть положительной")
    if amount.as_tuple().exponent < -3:
        raise ValueError("Допускается не более трёх знаков после запятой")
    return floor_stars(amount)


def coins_to_stars(coins: int) -> float:
    if coins <= 0 or coins % COIN_STEP:
        raise ValueError(f"Сумма монет должна быть кратна {COIN_STEP}")
    return float(Decimal(coins) / Decimal(get_rate()))


def stars_to_coins(stars: int | float | str | Decimal) -> int:
    amount = Decimal(str(floor_stars(stars)))
    return int((amount * get_rate()).to_integral_value(rounding=ROUND_DOWN))


def format_stars(stars: int | float | str | Decimal) -> str:
    return f"{floor_stars(stars):g}"


def floor_coins(coins: int | float | str | Decimal) -> int:
    try:
        amount = Decimal(str(coins))
    except (InvalidOperation, ValueError, TypeError):
        raise ValueError("Некорректная сумма монет")
    if not amount.is_finite() or amount < 0:
        raise ValueError("Некорректная сумма монет")
    whole_coins = int(amount.to_integral_value(rounding=ROUND_DOWN))
    return whole_coins // COIN_STEP * COIN_STEP


def format_coins(coins: int | float | str | Decimal) -> str:
    return f"{int(coins):,}".replace(",", " ")



def min_bet_floor() -> int:
    """Нижняя граница минимальной ставки в монетах: 0.1 ⭐ по текущему курсу."""
    return max(COIN_STEP, get_rate() // 10)


def rate_tenth_text() -> str:
    return f"{format_coins(get_rate() // 10)} 🪙 = 0.1 ⭐"


def rate_star_text() -> str:
    return f"1 ⭐ = {format_coins(get_rate())} 🪙"


def withdrawal_total_coins(stars: int, fee_coins: int = 0, rate: int | None = None) -> int:
    """Сколько монет списано по заявке на вывод — по курсу на момент заявки (для точного возврата)."""
    return int(stars) * int(rate or DEFAULT_STAR_TO_COINS) + int(fee_coins or 0)


def withdraw_fee_coins(stars: int | float | str | Decimal, fee_percent: int | float | str | Decimal) -> int:
    """Комиссия на вывод в монетах. Округляется ВВЕРХ до шага COIN_STEP, чтобы бот не недобирал."""
    try:
        percent = Decimal(str(fee_percent or 0))
    except (InvalidOperation, ValueError, TypeError):
        percent = Decimal(0)
    if not percent.is_finite() or percent <= 0:
        return 0
    base = Decimal(str(stars)) * get_rate()
    fee = base * percent / 100
    steps = (fee / COIN_STEP).to_integral_value(rounding=ROUND_CEILING)
    return int(steps) * COIN_STEP
