"""Доступ к единственной записи настроек бота (SQLite)."""
from app.database import get_connection


def get_settings() -> dict:
    conn = get_connection()
    row = conn.execute("SELECT * FROM settings WHERE id = 1").fetchone()
    if row is None:
        return {}
    d = dict(row)
    d["piarflow_enabled"] = bool(d["piarflow_enabled"])
    return d


def update_settings(**fields) -> None:
    if not fields:
        return
    conn = get_connection()
    set_parts = []
    values = []
    for key, value in fields.items():
        if key == "piarflow_enabled":
            value = int(bool(value))
        set_parts.append(f"{key} = ?")
        values.append(value)
    conn.execute(f"UPDATE settings SET {', '.join(set_parts)} WHERE id = 1", values)
    conn.commit()
