"""Exclusive casino controls reserved for configured bot administrators."""
from app.config import ADMIN_IDS
from app.database import get_connection
from app.utils.currency import min_bet_floor


def is_admin(user_id: int) -> bool:
    return user_id in ADMIN_IDS


def set_loss_chance(value: float) -> None:
    if not 0 <= value <= 95:
        raise ValueError("loss chance must be between 0 and 95")
    conn = get_connection()
    conn.execute("UPDATE casino_settings SET loss_chance=? WHERE id=1", (value,))
    conn.commit()


def set_bet_limits(minimum: float, maximum: float) -> None:
    if minimum < min_bet_floor() or minimum != int(minimum) or maximum < minimum or maximum != int(maximum):
        raise ValueError("invalid bet limits")
    conn = get_connection()
    conn.execute("UPDATE casino_settings SET min_bet=?, max_bet=? WHERE id=1", (minimum, maximum))
    conn.commit()


