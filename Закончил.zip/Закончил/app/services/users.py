"""CRUD-операции над таблицей пользователей (SQLite)."""
import json
from datetime import datetime
from typing import Optional

from app.database import get_connection
from decimal import Decimal

from app.utils.currency import get_rate, floor_stars, stars_to_coins

_JSON_FIELDS = {"completed_tasks", "referrals", "used_promo_codes", "piarflow_links"}
_BOOL_FIELDS = {"frozen", "casino_banned", "piarflow_completed"}


def _row_to_user(row) -> Optional[dict]:
    if row is None:
        return None
    d = dict(row)
    # Единый кошелёк — монеты. «balance» в ⭐ — это эквивалент монет (для показа и вывода).
    d["balance"] = floor_stars(Decimal(str(d.get("casino_coins", 0) or 0)) / get_rate() + Decimal(str(d["balance"] or 0)))
    d["completed_tasks"] = json.loads(d["completed_tasks"])
    d["referrals"] = json.loads(d["referrals"])
    d["used_promo_codes"] = json.loads(d["used_promo_codes"])
    d["piarflow_links"] = json.loads(d["piarflow_links"])
    d["frozen"] = bool(d["frozen"])
    d["casino_banned"] = bool(d.get("casino_banned", 0))
    d["piarflow_completed"] = bool(d["piarflow_completed"])
    return d


def get_user(user_id: int) -> Optional[dict]:
    conn = get_connection()
    row = conn.execute("SELECT * FROM users WHERE user_id = ?", (user_id,)).fetchone()
    return _row_to_user(row)


def get_user_by_username(username: str) -> Optional[dict]:
    normalized = username.strip().lstrip("@").lower()
    if not normalized or normalized == "nousername":
        return None
    conn = get_connection()
    row = conn.execute(
        "SELECT * FROM users WHERE lower(username) = ? LIMIT 1",
        (normalized,),
    ).fetchone()
    return _row_to_user(row)


def user_exists(user_id: int) -> bool:
    conn = get_connection()
    row = conn.execute("SELECT 1 FROM users WHERE user_id = ?", (user_id,)).fetchone()
    return row is not None


def create_user(
    user_id: int,
    first_name: str,
    last_name: Optional[str],
    username: Optional[str],
    referrer_id: Optional[str],
) -> None:
    conn = get_connection()
    conn.execute(
        "INSERT INTO users (user_id, balance, first_name, last_name, referrer_id, completed_tasks, "
        "registration_date, referrals, username, frozen, used_promo_codes, piarflow_completed, "
        "piarflow_links) VALUES (?, 0, ?, ?, ?, '[]', ?, '[]', ?, 0, '[]', 0, '[]')",
        (
            user_id,
            first_name,
            last_name or "",
            referrer_id,
            datetime.now().isoformat(),
            username or "NoUsername",
        ),
    )
    conn.commit()


def update_user(user_id: int, **fields) -> None:
    if not fields:
        return
    conn = get_connection()
    set_parts = []
    values = []
    for key, value in fields.items():
        if key in _JSON_FIELDS:
            value = json.dumps(value)
        elif key == "balance":
            # Совместимость: звёзды всегда хранятся монетами (абсолютное значение баланса в ⭐).
            if "casino_coins" not in fields:
                set_parts.append("casino_coins = ?")
                values.append(stars_to_coins(value))
            key, value = "balance", 0
        elif key in _BOOL_FIELDS:
            value = int(bool(value))
        set_parts.append(f"{key} = ?")
        values.append(value)
    values.append(user_id)
    conn.execute(f"UPDATE users SET {', '.join(set_parts)} WHERE user_id = ?", values)
    conn.commit()


def get_all_users() -> list[dict]:
    conn = get_connection()
    rows = conn.execute("SELECT * FROM users").fetchall()
    return [_row_to_user(r) for r in rows]


def add_referral(referrer_id: int, new_user_id: int, reward: float) -> Optional[dict]:
    referrer = get_user(referrer_id)
    if not referrer or referrer.get("frozen", False):
        return None
    add_stars(referrer_id, reward)
    referrals = referrer.get("referrals", []) + [new_user_id]
    update_user(referrer_id, referrals=referrals)
    referrer = get_user(referrer_id)
    new_balance = referrer["balance"]
    return referrer








def count_invited(user_id: int) -> int:
    """Сколько человек вообще перешло по ссылке пользователя (включая ещё не засчитанных)."""
    conn = get_connection()
    row = conn.execute(
        "SELECT COUNT(*) AS c FROM users WHERE CAST(referrer_id AS TEXT) = ?", (str(user_id),)
    ).fetchone()
    return int(row["c"])


def increment_tasks_done(user_id: int) -> None:
    conn = get_connection()
    conn.execute("UPDATE users SET tasks_done = tasks_done + 1 WHERE user_id = ?", (user_id,))
    conn.commit()


def add_coins(user_id: int, coins: int) -> None:
    """Атомарно начисляет монеты (coins может быть отрицательным)."""
    conn = get_connection()
    conn.execute("UPDATE users SET casino_coins = casino_coins + ? WHERE user_id = ?", (int(coins), user_id))
    conn.commit()


def add_stars(user_id: int, stars: float) -> int:
    """Начисляет звёзды: они сразу зачисляются монетами. Возвращает число монет."""
    coins = stars_to_coins(stars)
    add_coins(user_id, coins)
    return coins


def spend_stars(user_id: int, stars: float) -> bool:
    """Атомарно списывает звёзды с кошелька (в монетах). False — если не хватает."""
    coins = stars_to_coins(stars)
    conn = get_connection()
    cur = conn.execute(
        "UPDATE users SET casino_coins = casino_coins - ? WHERE user_id = ? AND casino_coins >= ?",
        (coins, user_id, coins),
    )
    conn.commit()
    return cur.rowcount == 1


def spend_coins(user_id: int, coins: int) -> bool:
    """Атомарно списывает монеты. False — если не хватает."""
    conn = get_connection()
    cur = conn.execute(
        "UPDATE users SET casino_coins = casino_coins - ? WHERE user_id = ? AND casino_coins >= ?",
        (int(coins), user_id, int(coins)),
    )
    conn.commit()
    return cur.rowcount == 1
