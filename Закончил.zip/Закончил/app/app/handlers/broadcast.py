"""Рассылка сообщения всем пользователям бота (только для админа)."""
import asyncio
import logging

from aiogram import Router, Bot, F
from aiogram.exceptions import TelegramForbiddenError, TelegramRetryAfter, TelegramBadRequest
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, Message

from app.config import ADMIN_IDS
from app.keyboards.admin import admin_panel_markup
from app.keyboards.user import cancel_input_markup
from app.services.users import get_all_users

logger = logging.getLogger(__name__)
router = Router(name="broadcast")


class BroadcastStates(StatesGroup):
    waiting_content = State()
    waiting_confirm = State()


def _is_admin(user_id: int) -> bool:
    return user_id in ADMIN_IDS


def _confirm_markup():
    from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="✅ Отправить", callback_data="broadcast_send"),
                InlineKeyboardButton(text="❌ Отмена", callback_data="admin_cancel"),
            ]
        ]
    )


@router.callback_query(F.data == "admin_broadcast")
async def start_broadcast(call: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(call.from_user.id):
        return
    await state.set_state(BroadcastStates.waiting_content)
    await call.message.answer(
        "📢 Отправьте сообщение для рассылки (текст, фото, видео — с подписью или без).\n"
        "Оно будет разослано ВСЕМ пользователям бота как есть.",
        reply_markup=cancel_input_markup(),
    )


@router.message(BroadcastStates.waiting_content)
async def receive_broadcast_content(message: Message, state: FSMContext) -> None:
    if not _is_admin(message.from_user.id):
        return
    users_count = len(get_all_users())
    await state.update_data(
        broadcast_chat_id=message.chat.id, broadcast_message_id=message.message_id
    )
    await state.set_state(BroadcastStates.waiting_confirm)
    await message.answer(
        f"👆 Вот так будет выглядеть рассылка.\n\n"
        f"Получателей: {users_count}\n\n"
        "Отправить всем?",
        reply_markup=_confirm_markup(),
    )


@router.callback_query(F.data == "broadcast_send", BroadcastStates.waiting_confirm)
async def confirm_broadcast(call: CallbackQuery, bot: Bot, state: FSMContext) -> None:
    if not _is_admin(call.from_user.id):
        return

    data = await state.get_data()
    src_chat_id = data.get("broadcast_chat_id")
    src_message_id = data.get("broadcast_message_id")
    await state.clear()

    users = get_all_users()
    await call.message.edit_text(f"📤 Рассылка запущена... 0/{len(users)}")

    sent, failed = 0, 0
    for i, user in enumerate(users, 1):
        try:
            await bot.copy_message(
                chat_id=user["user_id"], from_chat_id=src_chat_id, message_id=src_message_id
            )
            sent += 1
        except TelegramRetryAfter as e:
            await asyncio.sleep(e.retry_after)
            try:
                await bot.copy_message(
                    chat_id=user["user_id"], from_chat_id=src_chat_id, message_id=src_message_id
                )
                sent += 1
            except Exception:
                failed += 1
        except (TelegramForbiddenError, TelegramBadRequest):
            failed += 1
        except Exception as e:
            logger.error(f"Broadcast error for {user['user_id']}: {e}")
            failed += 1

        if i % 25 == 0:
            try:
                await call.message.edit_text(f"📤 Рассылка запущена... {i}/{len(users)}")
            except Exception:
                pass
        await asyncio.sleep(0.05)

    await call.message.edit_text(
        f"✅ Рассылка завершена!\n\nДоставлено: {sent}\nНе доставлено: {failed}",
        reply_markup=admin_panel_markup(),
    )
