"""Разбор текстовых команд без слэша: суммы, ставки, получатели."""
import re
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation

from aiogram.types import Message

from app.utils.currency import get_rate

_AMOUNT_RE = re.compile(r"^(\d+(?:[.,]\d+)?)(кк|kk|к|k|⭐|зв\w*)?$", re.I)


def parse_amount(token: str) -> int | None:
    """Сумма в МОНЕТАХ. Понимает 1000, 1к, 2.5к, 1кк, а также 5⭐ / 5зв (звёзды -> монеты)."""
    m = _AMOUNT_RE.match((token or "").strip())
    if not m:
        return None
    try:
        number = Decimal(m.group(1).replace(",", "."))
    except InvalidOperation:
        return None
    suffix = (m.group(2) or "").lower()
    if suffix in ("к", "k"):
        mult = 1000
    elif suffix in ("кк", "kk"):
        mult = 1_000_000
    elif suffix:
        mult = get_rate()
    else:
        mult = 1
    coins = number * mult
    if coins != coins.to_integral_value():
        return None
    return int(coins)


@dataclass
class Parsed:
    user_id: int | None = None
    username: str | None = None
    amount: str | None = None


def _entity_user_id(message: Message) -> int | None:
    for ent in message.entities or []:
        if ent.type == "text_mention" and ent.user and not ent.user.is_bot:
            return ent.user.id
    return None


def _reply_user_id(message: Message) -> int | None:
    reply = message.reply_to_message
    if reply and reply.from_user and not reply.from_user.is_bot:
        return reply.from_user.id
    return None


def extract_target_and_amount(message: Message, rest: str) -> Parsed:
    """Форматы: [ответом] 100 | @user 100 | 100 @user | ID 100 | (упоминание без @) 100."""
    tokens = rest.split()
    result = Parsed()
    mention = next((t for t in tokens if t.startswith("@") and len(t) > 1), None)
    others = [t for t in tokens if t != mention]
    if mention:
        result.username = mention.lstrip("@").rstrip(".,!?;:")
    result.user_id = _entity_user_id(message)
    if result.user_id is None and result.username is None:
        result.user_id = _reply_user_id(message)
    if result.user_id is None and result.username is None:
        if len(others) == 2 and others[0].isdigit() and parse_amount(others[1]) is not None:
            result.user_id, result.amount = int(others[0]), others[1]
        elif len(others) == 1 and parse_amount(others[0]) is not None:
            result.amount = others[0]
        return result
    for token in others:
        if parse_amount(token) is not None:
            result.amount = token
            break
    return result


def extract_target_only(message: Message, rest: str) -> Parsed:
    """Для «инфо» / «бан»: ID, @username, упоминание или ответ на сообщение."""
    result = Parsed()
    for token in rest.split():
        if token.startswith("@") and len(token) > 1:
            result.username = token.lstrip("@").rstrip(".,!?;:")
            break
        if token.isdigit():
            result.user_id = int(token)
            break
    if result.user_id is None and result.username is None:
        result.user_id = _entity_user_id(message) or _reply_user_id(message)
    return result


def resolve_user(parsed: Parsed):
    """Возвращает запись пользователя из БД или None."""
    from app.services.users import get_user, get_user_by_username
    if parsed.user_id is not None:
        return get_user(parsed.user_id)
    if parsed.username:
        return get_user_by_username(parsed.username)
    return None
