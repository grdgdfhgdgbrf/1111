"""Точные преобразования и отображение баланса для звёзд и казино-монет."""
from decimal import Decimal, InvalidOperation, ROUND_DOWN


STAR_TO_COINS = 10_000  # 0.1 ⭐ = 1 000 🪙
BALANCE_STEP = Decimal("0.001")
COIN_STEP = 10  # 0.001 ⭐ = 10 🪙


def floor_stars(value: int | float | str | Decimal) -> float:
    """Округляет баланс вниз до 0.001 ⭐."""
    try:
        amount = Decimal(str(value))
    except (InvalidOperation, ValueError, TypeError):
        raise ValueError("Некорректная сумма звёзд")
    if not amount.is_finite():
        raise ValueError("Некорректная сумма звёзд")
    return float(amount.quantize(BALANCE_STEP, rounding=ROUND_DOWN))


def parse_stars(raw: str, *, allow_zero: bool = False) -> float:
    text = raw.strip().replace(",", ".")
    try:
        amount = Decimal(text)
    except (InvalidOperation, ValueError):
        raise ValueError("Введите сумму числом")
    if not amount.is_finite() or amount < 0 or (amount == 0 and not allow_zero):
        raise ValueError("Сумма должна быть положительной")
    if amount.as_tuple().exponent < -3:
        raise ValueError("Допускается не более трёх знаков после запятой")
    return floor_stars(amount)


def coins_to_stars(coins: int) -> float:
    if coins <= 0 or coins % COIN_STEP:
        raise ValueError(f"Сумма монет должна быть кратна {COIN_STEP}")
    return float(Decimal(coins) / Decimal(STAR_TO_COINS))


def stars_to_coins(stars: int | float | str | Decimal) -> int:
    amount = Decimal(str(floor_stars(stars)))
    return int((amount * STAR_TO_COINS).to_integral_value(rounding=ROUND_DOWN))


def format_stars(stars: int | float | str | Decimal) -> str:
    return f"{floor_stars(stars):g}"


def floor_coins(coins: int | float | str | Decimal) -> int:
    try:
        amount = Decimal(str(coins))
    except (InvalidOperation, ValueError, TypeError):
        raise ValueError("Некорректная сумма монет")
    if not amount.is_finite() or amount < 0:
        raise ValueError("Некорректная сумма монет")
    whole_coins = int(amount.to_integral_value(rounding=ROUND_DOWN))
    return whole_coins // COIN_STEP * COIN_STEP


def format_coins(coins: int | float | str | Decimal) -> str:
    return f"{int(coins):,}".replace(",", " ")

