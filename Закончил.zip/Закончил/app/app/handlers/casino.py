"""Casino games, Star deposits, transfers and game-based withdrawals."""
import asyncio
import random
from html import escape
import re
from datetime import datetime, timezone
from aiogram import Router, F
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import Message, CallbackQuery, LabeledPrice, PreCheckoutQuery, InlineKeyboardButton, InlineKeyboardMarkup
from app.config import ADMIN_CHANNEL_ID, IMAGE_CASINO_MENU
from app.database import get_connection
from app.services.users import get_user, add_coins
from app.services.exclusive import is_admin
from app.states import CasinoBet, CasinoTopUp, CasinoExchange
from app.keyboards.user import casino_games_markup, bet_cancel_markup
from app.utils.images import send_screen, edit_screen
from app.utils.currency import COIN_STEP, STAR_TO_COINS, floor_coins, format_coins, format_stars
from app.utils.textcmd import parse_amount, extract_target_and_amount, resolve_user

router = Router(name="casino")
GAME_INFO = {
    "slots": ("🎰 Слоты", "🎰", ["слоты", "слот", "slot"]),
    "dice": ("🎲 Кости", "🎲", ["кости", "кубик", "кубики", "dice"]),
    "blackjack": ("🃏 Блэкджек", "🃏", ["блэкджек", "блекджек", "blackjack", "бж", "очко", "21"]),
    "football": ("⚽ Футбол", "⚽", ["футбол", "футболл", "пенальти", "football"]),
    "bowling": ("🎳 Боулинг", "🎳", ["боулинг", "bowling"]),
    "darts": ("🎯 Дартс", "🎯", ["дартс", "dart", "darts"]),
    "basketball": ("🏀 Баскетбол", "🏀", ["баскетбол", "баскет", "basketball"]),
    "coin": ("🪙 Монетка", "🪙", ["монетка", "монетку", "монета", "coin"]),
    "number": ("🔢 Число 1–10", "🔢", ["число", "рулетка", "number"]),
    "crash": ("🚀 Краш", "🚀", ["краш", "crash"]),
    "mines": ("💣 Мины", "💣", ["мины", "мина", "mines"]),
    "tower": ("🗼 Башня", "🗼", ["башня", "башню", "tower"]),
}
GAME_ALIASES = {alias: key for key, (_, _, aliases) in GAME_INFO.items() for alias in aliases}
BET_PATTERN = r"(?:\d+(?:[.,]\d+)?(?:кк|kk|к|k)?|все|всё|all)"
GAME_CMD_RE = re.compile(
    r"^(?P<game>" + "|".join(re.escape(x) for x in sorted(GAME_ALIASES, key=len, reverse=True)) + r")\s+(?P<bet>" + BET_PATTERN + r")(?:\s+(?P<extra>\S+))?\s*$",
    re.I,
)
DEFAULT_MINES = 3  # сколько мин, если в команде число не указано
TELEGRAM_DICE = {"football": "⚽", "bowling": "🎳", "darts": "🎯", "basketball": "🏀"}
# Telegram's built-in animated dice only support a small set of emojis. Use the
# closest game-themed animation for games without a dedicated animation.
def settings():
    return dict(get_connection().execute("SELECT * FROM casino_settings WHERE id=1").fetchone())

def stats(uid):
    row=get_connection().execute("SELECT * FROM casino_stats WHERE user_id=?",(uid,)).fetchone()
    return dict(row) if row else {"games_played":0,"wins":0,"total_won":0,"total_lost":0}

def record(uid, bet, paid):
    conn=get_connection(); won=max(0,paid-bet); lost=max(0,bet-paid)
    conn.execute("INSERT INTO casino_stats(user_id,games_played,wins,total_won,total_lost) VALUES(?,?,?, ?,?) ON CONFLICT(user_id) DO UPDATE SET games_played=games_played+1,wins=wins+excluded.wins,total_won=total_won+excluded.total_won,total_lost=total_lost+excluded.total_lost",(uid,1,int(paid>bet),won,lost)); conn.commit()

def game_result(game, bet, extra=None):
    if game == "slots":
        symbols=["🍒","🍋","🍇","⭐","💎","7️⃣"]; reels=random.choices(symbols,weights=[30,26,20,14,7,3],k=3)
        if reels[0]==reels[1]==reels[2]: return bet*{"7️⃣":15,"💎":10,"⭐":6}.get(reels[0],3),"🎰 "+" ".join(reels)+" — джекпот!"
        if len(set(reels))<3: return bet*2,"🎰 "+" ".join(reels)+" — пара!"
        return 0,"🎰 "+" ".join(reels)+" — мимо."
    if game == "dice":
        roll=random.randint(2,12); high=not (extra or "").lower().startswith("м")
        return (bet*1.9 if (roll>7 if high else roll<7) else 0),f"🎲 Выпало {roll}; ставка на {'больше' if high else 'меньше'} 7."
    if game == "blackjack":
        player=sum(random.randint(1,11) for _ in range(2)); dealer=sum(random.randint(1,11) for _ in range(2))
        return (bet*2.5 if player==21 else bet*2 if player>dealer else bet if player==dealer else 0),f"🃏 У тебя {player}, у дилера {dealer}."
    if game == "coin":
        heads=not (extra or "").lower().startswith("р"); result_heads=random.random()<.5
        return (bet*1.9 if result_heads==heads else 0),f"🪙 Выпал {'орёл' if result_heads else 'решка'}; выбрано {'орёл' if heads else 'решка'}."
    if game == "number":
        try: guess=int(extra); assert 1<=guess<=10
        except (ValueError,TypeError,AssertionError): return None,"Укажи число от 1 до 10, например: число 100 7"
        result=random.randint(1,10); return (bet*8 if result==guess else 0),f"🎡 Выпало {result}; ты выбрал {guess}."
    if game == "crash":
        mult=0 if random.random()<.45 else random.choice([1.2,1.3,1.5,1.8,2,2.5,3,5])
        return bet*mult,f"🚀 Краш: x{mult:g}."
    return 0,"Ошибка игры."


def telegram_dice_result(game, value, bet):
    if game == "football":
        mult=1.9 if value in (3,4,5) else 0
    elif game == "bowling":
        mult=2.5 if value==6 else 1.5 if value in (4,5) else 0
    elif game == "darts":
        mult=3 if value==6 else 1.8 if value in (4,5) else 0
    else:
        mult=1.9 if value in (4,5) else 0
    return bet*mult,f"{GAME_INFO[game][0]} Результат броска: {value}."


async def _delete_message(bot, chat_id, message_id):
    if not message_id:
        return
    try:
        await bot.delete_message(chat_id, message_id)
    except Exception:
        pass


async def _temporary_reply(message: Message, text: str, delay: float = 8) -> None:
    """Keep validation chatter brief in busy group chats."""
    reply = await message.answer(text)
    await _delete_message(message.bot, message.chat.id, message.message_id)
    asyncio.create_task(_delete_after(message.bot, message.chat.id, reply.message_id, delay))


async def _delete_after(bot, chat_id, message_id, delay: float) -> None:
    await asyncio.sleep(delay)
    await _delete_message(bot, chat_id, message_id)


@router.callback_query(F.data == "casino_open")
async def casino_open(call: CallbackQuery):
    try:
        await call.message.delete()
    except Exception:
        pass
    await send_screen(call.bot, call.message.chat.id, "🎰 <b>Выбери игру</b>\nСтавки в монетах · 1 000 🪙 = 0.1 ⭐", image=IMAGE_CASINO_MENU, reply_markup=casino_games_markup())
    await call.answer()


@router.message(F.text.lower().in_({"игры","казино","games"}))
@router.message(Command("games"))
async def games_command(message: Message):
    await message.answer("🎰 Выбери игру:\nСтавки в монетах · 1 000 🪙 = 0.1 ⭐",reply_markup=casino_games_markup())
    await _delete_message(message.bot,message.chat.id,message.message_id)


@router.callback_query(F.data.startswith("casino_pick:"))
async def pick_game(call: CallbackQuery, state: FSMContext):
    game = call.data.split(":", 1)[1]
    if game not in GAME_INFO:
        await call.answer("Такой игры нет", show_alert=True)
        return
    user = get_user(call.from_user.id)
    if not user or user.get("frozen") or user.get("casino_banned"):
        await call.answer("Игра недоступна для этого аккаунта.", show_alert=True)
        return
    await state.update_data(game=game, prompt_message_id=call.message.message_id, owner_id=call.from_user.id)
    label = GAME_INFO[game][0]
    minimum = max(1000, int(settings()["min_bet"]))
    maximum = int(settings()["max_bet"])
    stake_hint = f"Курс: 1 000 🪙 = 0.1 ⭐. Введи ставку в монетах от {format_coins(minimum)} до {format_coins(maximum)}."
    if game == "mines":
        await state.set_state(CasinoBet.waiting_mine_count)
        await edit_screen(call.bot, call.message.chat.id, call.message.message_id,
                          f"{label}\nВыбери количество мин на поле 5×5:",
                          reply_markup=_mines_count_markup())
    else:
        await state.set_state(CasinoBet.waiting_stake)
        await edit_screen(call.bot, call.message.chat.id, call.message.message_id,
                          f"{label}\n{stake_hint}",
                          reply_markup=bet_cancel_markup(), parse_mode="HTML")
    await call.answer()


def _mines_count_markup() -> InlineKeyboardMarkup:
    values = [InlineKeyboardButton(text=f"💣 {n}", callback_data=f"mines_count:{n}") for n in range(1, 25)]
    rows = [values[i:i + 4] for i in range(0, len(values), 4)]
    rows.append([InlineKeyboardButton(text="↩️ К играм", callback_data="casino_menu")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


@router.callback_query(CasinoBet.waiting_mine_count, F.data.startswith("mines_count:"))
async def select_mine_count(call: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    if call.from_user.id != data.get("owner_id"):
        await call.answer("Это не твоя игра.", show_alert=True)
        return
    try:
        mine_count = int(call.data.split(":", 1)[1])
    except ValueError:
        await call.answer("Некорректное количество мин.", show_alert=True)
        return
    if not 1 <= mine_count <= 24:
        await call.answer("Выбери от 1 до 24 мин.", show_alert=True)
        return
    await state.update_data(mine_count=mine_count)
    await state.set_state(CasinoBet.waiting_stake)
    cfg = settings()
    stake_hint = f"Введи ставку в монетах от {format_coins(max(1000, int(cfg['min_bet'])))} до {format_coins(cfg['max_bet'])}. Курс: 1 000 🪙 = 0.1 ⭐."
    await edit_screen(call.bot, call.message.chat.id, call.message.message_id,
                      f"💣 Мин: {mine_count}\n{stake_hint}",
                      reply_markup=bet_cancel_markup(), parse_mode="HTML")
    await call.answer()

@router.callback_query(F.data == "casino_menu")
async def back_to_games(call: CallbackQuery,state:FSMContext):
    current=await state.get_data()
    if current.get("owner_id") and current["owner_id"]!=call.from_user.id:
        await call.answer("Это не твоя игра.",show_alert=True); return
    await state.clear()
    await edit_screen(call.bot, call.message.chat.id, call.message.message_id, "🎰 <b>Выбери игру</b>",reply_markup=casino_games_markup(),parse_mode="HTML")
    await call.answer()


@router.message(CasinoBet.waiting_stake)
async def receive_stake(message: Message, state: FSMContext):
    raw = (message.text or "").strip()
    if not raw.isdigit():
        await _temporary_reply(message, "Введи ставку целым числом монет, например 1000.")
        return
    stake_coins = int(raw)
    if stake_coins <= 0 or stake_coins % COIN_STEP:
        await _temporary_reply(message, f"Ставка должна быть положительной и кратной {COIN_STEP} монетам.")
        return
    bet = stake_coins
    data = await state.get_data()
    game = data.get("game")
    cfg = settings()
    minimum = max(1000, int(cfg["min_bet"]))
    maximum = int(cfg["max_bet"])
    if bet < minimum or bet > maximum:
        await _temporary_reply(message, f"Ставка должна быть от {format_coins(minimum)} до {format_coins(maximum)} 🪙.")
        return
    user = get_user(message.from_user.id)
    if not user or user.get("frozen") or user.get("casino_banned") or user["casino_coins"] < bet:
        await _temporary_reply(message, "Недостаточно монет или игра для аккаунта недоступна.")
        return
    if game in {"mines", "tower"}:
        await start_grid_game(message, state, game, bet, data)
        return
    await state.update_data(owner_id=message.from_user.id, bet=bet, forced_loss=random.random() * 100 < float(cfg["loss_chance"]))
    await state.set_state(CasinoBet.playing_game)
    if not await _show_choice_menu(message.bot, message.chat.id, data.get("prompt_message_id"), game, bet, message.from_user.id):
        sent = await message.answer(f"{GAME_INFO[game][0]} · ставка {format_coins(bet)} 🪙\nВыбери ход:", reply_markup=_choice_markup(game))
        await state.update_data(prompt_message_id=sent.message_id)
    await _delete_message(message.bot, message.chat.id, message.message_id)

def _choice_markup(game: str, blackjack_started: bool = False) -> InlineKeyboardMarkup:
    choices = {
        "slots": [("🎰 Крутить", "spin")],
        "dice": [(f"🎲 {n}", f"face_{n}") for n in range(1, 7)],
        "blackjack": [("🃏 Раздать карты", "blackjack_start")] if not blackjack_started else [("➕ Взять", "hit"), ("✋ Остановиться", "stand")],
        "football": [("⚽ Гол", "goal"), ("Мимо", "miss")],
        "bowling": [("🎳 Страйк", "strike"), ("Мимо", "miss")],
        "darts": [("🎯 Попадание", "hit_target"), ("Мимо", "miss")],
        "basketball": [("🏀 Попадание", "score"), ("Мимо", "miss")],
        "coin": [("Орёл", "heads"), ("Решка", "tails")],
        "number": [(str(n), f"number_{n}") for n in range(1, 11)],
        "crash": [("🚀 Запустить", "crash")],
    }
    buttons = [InlineKeyboardButton(text=label, callback_data=f"casino_action:{action}") for label, action in choices.get(game, [])]
    rows = [buttons[i:i + 2] for i in range(0, len(buttons), 2)]
    rows.append([InlineKeyboardButton(text="↩️ К играм", callback_data="game_cancel")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


async def _show_choice_menu(bot, chat_id, message_id, game, bet, owner_id) -> bool:
    if not message_id:
        return False
    await edit_screen(bot, chat_id, message_id, f"{GAME_INFO[game][0]} · ставка {format_coins(bet)} 🪙\nВыбери ход:", reply_markup=_choice_markup(game))
    return True


def _card_value() -> int:
    return random.choice([2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 11])


def _hand_total(cards: list[int]) -> int:
    total = sum(cards)
    aces = sum(1 for card in cards if card == 11)
    while total > 21 and aces:
        total -= 10
        aces -= 1
    return total


async def _settle_choice(call: CallbackQuery, state: FSMContext, paid: float, result_text: str) -> None:
    data = await state.get_data()
    uid, bet = data["owner_id"], float(data["bet"])
    paid = floor_coins(max(0, paid))
    if data.get("forced_loss"):
        paid = 0
        result_text += "\nСработал установленный шанс проигрыша."
    conn = get_connection()
    cur = conn.execute(
        "UPDATE users SET casino_coins=casino_coins-?+? WHERE user_id=? AND casino_coins>=?",
        (bet, paid, uid, bet),
    )
    if cur.rowcount != 1:
        conn.rollback()
        await call.answer("Недостаточно монет на балансе.", show_alert=True)
        return
    conn.commit()
    record(uid, bet, paid)
    user = get_user(uid)
    await state.clear()
    if paid > bet:
        outcome = f"✅ Выигрыш: +{format_coins(paid - bet)} 🪙 (выплата {format_coins(paid)} 🪙)"
    elif paid == bet:
        outcome = f"↩️ Ставка возвращена: {format_coins(paid)} 🪙"
    else:
        outcome = "❌ Проигрыш: 0 🪙"
    result_text += f"\n{outcome}\n💰 Баланс: {format_coins(user['casino_coins'])} 🪙"
    await edit_screen(call.bot, call.message.chat.id, call.message.message_id, result_text, reply_markup=bet_cancel_markup())
    await call.answer()

@router.callback_query(CasinoBet.playing_game, F.data.startswith("casino_action:"))
async def casino_game_action(call: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    if call.from_user.id != data.get("owner_id"):
        await call.answer("Эта игра не твоя.", show_alert=True)
        return
    game, bet, action = data["game"], float(data["bet"]), call.data.split(":", 1)[1]
    cfg = settings()
    if game == "dice" and action.startswith("face_"):
        predicted = int(action.split("_", 1)[1])
        dice = await call.message.answer_dice(emoji="🎲")
        await asyncio.sleep(5)
        value = dice.dice.value
        await _delete_message(call.bot, call.message.chat.id, dice.message_id)
        paid = bet * 1.97 if value == predicted else 0
        await _settle_choice(call, state, paid, f"🎲 Выпало {value}; ты выбрал {predicted}.")
        return
    if game == "blackjack":
        if action == "blackjack_start":
            data.update(player_cards=[_card_value(), _card_value()], dealer_cards=[_card_value(), _card_value()], blackjack_started=True)
            await state.set_data(data)
            player, dealer = _hand_total(data["player_cards"]), data["dealer_cards"][0]
            await edit_screen(call.bot, call.message.chat.id, call.message.message_id, f"🃏 Твои карты: {data['player_cards']} = {player}\nОткрытая карта дилера: {dealer}\nБрать ещё или остановиться?", reply_markup=_choice_markup(game, True))
            await call.answer()
            return
        if not data.get("blackjack_started"):
            await call.answer("Сначала раздай карты.", show_alert=True)
            return
        if action == "hit":
            data["player_cards"].append(_card_value())
            player = _hand_total(data["player_cards"])
            if player > 21:
                await state.set_data(data)
                await _settle_choice(call, state, 0, f"🃏 Твои карты: {data['player_cards']} = {player}. Перебор!")
                return
            await state.set_data(data)
            await edit_screen(call.bot, call.message.chat.id, call.message.message_id, f"🃏 Твои карты: {data['player_cards']} = {player}\nКарта дилера: {data['dealer_cards'][0]}\nБрать ещё или остановиться?", reply_markup=_choice_markup(game, True))
            await call.answer()
            return
        if action == "stand":
            dealer_cards = data["dealer_cards"]
            while _hand_total(dealer_cards) < 17:
                dealer_cards.append(_card_value())
            player_total, dealer_total = _hand_total(data["player_cards"]), _hand_total(dealer_cards)
            if dealer_total > 21 or player_total > dealer_total:
                paid, outcome = bet * 1.97, "Ты выиграл!"
            elif player_total == dealer_total:
                paid, outcome = bet, "Ничья, ставка возвращена."
            else:
                paid, outcome = 0, "Дилер выиграл."
            await _settle_choice(call, state, paid, f"🃏 Ты: {data['player_cards']} = {player_total}\nДилер: {dealer_cards} = {dealer_total}\n{outcome}")
            return
        return

    if game in TELEGRAM_DICE:
        dice = await call.message.answer_dice(emoji=TELEGRAM_DICE[game])
        await asyncio.sleep(5)
        value = dice.dice.value
        await _delete_message(call.bot, call.message.chat.id, dice.message_id)
        if game == "football":
            won = (value in (3, 4, 5)) == (action == "goal"); multiplier = 1.97
            label = "Гол" if value in (3, 4, 5) else "Мимо"
        elif game == "bowling":
            won = (value == 6) == (action == "strike"); multiplier = 1.97
            label = "Страйк" if value == 6 else "Не страйк"
        elif game == "darts":
            won = (value == 6) == (action == "hit_target"); multiplier = 1.97
            label = "Попадание" if value == 6 else "Мимо"
        else:
            won = (value in (4, 5)) == (action == "score"); multiplier = 1.97
            label = "Попадание" if value in (4, 5) else "Мимо"
        paid = bet * multiplier if won else 0
        result = f"{GAME_INFO[game][0]}\nРезультат: {label}. Выпало: {value}.\nТвой выбор: {action}."
        await _settle_choice(call, state, paid, result)
        return

    if game == "blackjack":
        return
    if game == "dice":
        roll = random.randint(2, 12); won = (roll > 7) == (action == "high"); multiplier = 2.328
        paid = bet * multiplier if won else 0; result = f"🎲 Выпало {roll}. Ты выбрал {'больше' if action == 'high' else 'меньше'} 7."
    elif game == "coin":
        landed = random.choice(["heads", "tails"]); won = landed == action; paid = bet * 1.97 if won else 0
        result = f"🪙 Выпало {'орёл' if landed == 'heads' else 'решка'}."
    elif game == "number":
        chosen = int(action.split("_", 1)[1]); landed = random.randint(1, 10); won = landed == chosen; paid = bet * 9.7 if won else 0
        result = f"🎡 Выпало {landed}; ты выбрал {chosen}."
    elif game == "crash":
        mult = random.choice([0, 1.2, 1.3, 1.5, 1.8, 2, 2.5, 3, 5]); paid = bet * mult
        result = f"🚀 Краш: x{mult:g}."
    else:
        paid, result = game_result(game, bet, action)
    await _settle_choice(call, state, paid, result)

def _mines_markup(data, finished=False):
    from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
    cells=[]
    for i in range(25):
        if finished and i in data.get("mines", []):
            label="💥"
            style="danger"
        elif finished or i in data.get("opened", []):
            label="💎"
            style="success"
        else:
            label="❓"
            style=None
        cells.append(InlineKeyboardButton(text=label, callback_data=f"mines_cell:{i}" if not finished else "game_fairness", style=style))
    rows=[cells[i:i+5] for i in range(0,25,5)]
    if not finished and data.get("opened"):
        rows.append([InlineKeyboardButton(text="Забрать выигрыш ✅", callback_data="game_cashout")])
    rows.append([InlineKeyboardButton(text="Честность 🔑", callback_data="game_fairness"), InlineKeyboardButton(text="Отменить ❌", callback_data="game_cancel" if not finished else f"casino_menu:{data['owner_id']}")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _tower_markup(data, finished=False):
    from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
    rows=[]
    level=data.get("level",0)
    for row_index in range(level):
        hit = data.get("tower_hit") if row_index==level-1 and finished else None
        rows.append([InlineKeyboardButton(text="💥" if col==hit else "💎" if col==data["tower_safe"][row_index] else "·", callback_data="game_fairness") for col in range(5)])
    if not finished and level<6:
        rows.append([InlineKeyboardButton(text="❓", callback_data=f"tower_cell:{col}") for col in range(5)])
    if not finished and level:
        rows.append([InlineKeyboardButton(text="Забрать награду ✅", callback_data="game_cashout")])
    rows.append([InlineKeyboardButton(text="Честность 🔑", callback_data="game_fairness"), InlineKeyboardButton(text="Отменить ❌", callback_data="game_cancel" if not finished else f"casino_menu:{data['owner_id']}")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


async def start_grid_game(message: Message, state: FSMContext, game: str, bet: int, data):
    user_id = message.from_user.id
    user = get_user(user_id)
    cfg = settings()
    prompt_id = data.get("prompt_message_id")
    if not user or user.get("frozen") or user.get("casino_banned"):
        await message.answer("Игра сейчас недоступна для этого аккаунта.")
        return
    mine_count = int(data.get("mine_count", 1)) if game == "mines" else 0
    if game == "mines" and not 1 <= mine_count <= 24:
        await message.answer("Количество мин должно быть от 1 до 24.")
        return
    if bet < max(1000, int(cfg["min_bet"])) or bet > int(cfg["max_bet"]):
        await message.answer(f"Ставка должна быть от {format_coins(max(1000, int(cfg['min_bet'])))} до {format_coins(cfg['max_bet'])} 🪙.")
        return
    conn = get_connection()
    cur = conn.execute(
        "UPDATE users SET casino_coins=casino_coins-? WHERE user_id=? AND casino_coins>=?",
        (bet, user_id, bet),
    )
    if cur.rowcount != 1:
        conn.rollback()
        await message.answer("Недостаточно монет на балансе.")
        return
    conn.commit()
    game_data = {
        "game": game, "owner_id": user_id, "bet": bet, "level": 0, "multiplier": 1.0,
        "opened": [], "forced_loss": random.random() * 100 < float(cfg["loss_chance"]),
    }
    if game == "mines":
        game_data["mines"] = random.sample(range(25), mine_count)
        game_data["mine_count"] = mine_count
        field = f"💣 Мин: {mine_count}\nНажимай на клетки. Ставка уже внесена."
    else:
        game_data["tower_safe"] = [random.randrange(5) for _ in range(6)]
        field = "🗼 Башня — поднимайся по этажам!\nНа каждом этаже выбери безопасную клетку."
    await state.set_data(game_data)
    await state.set_state(CasinoBet.playing_game)
    keyboard = _mines_markup(game_data) if game == "mines" else _tower_markup(game_data)
    if game == "mines":
        next_mult = 25 / (25 - game_data["mine_count"]) * 0.97
        status = f"Следующий множитель: x{next_mult:.2f}"
    else:
        status = "Следующий этаж: x1.21"
    await edit_screen(
        message.bot, message.chat.id, prompt_id,
        f"{field}\n💸 Ставка: {format_coins(bet)} 🪙\n{status}",
        reply_markup=keyboard, parse_mode="HTML",
    )
    await _delete_message(message.bot, message.chat.id, message.message_id)

async def _finish_grid(call: CallbackQuery, state: FSMContext, paid: float, text: str, reveal=False):
    data = await state.get_data()
    game, bet, uid = data["game"], float(data["bet"]), call.from_user.id
    paid = floor_coins(max(0, paid))
    if data.get("forced_loss"):
        paid = 0
        text += "\nСработал настроенный шанс проигрыша."
    conn = get_connection()
    if paid > 0:
        conn.execute("UPDATE users SET casino_coins=casino_coins+? WHERE user_id=?", (paid, uid))
        conn.commit()
    record(uid, bet, paid)
    user = get_user(uid)
    await state.clear()
    keyboard = _mines_markup(data, True) if game == "mines" else _tower_markup(data, True)
    await edit_screen(
        call.bot, call.message.chat.id, call.message.message_id,
        f"{text}\nВыплата: {format_coins(paid)} 🪙\nБаланс: {format_coins(user['casino_coins'])} 🪙",
        reply_markup=keyboard, parse_mode="HTML",
    )
    await call.answer()

@router.callback_query(CasinoBet.playing_game, F.data.startswith("mines_cell:"))
async def mines_cell(call: CallbackQuery,state:FSMContext):
    data=await state.get_data()
    if call.from_user.id!=data.get("owner_id"):
        await call.answer("Это не твоя игра.",show_alert=True); return
    cell=int(call.data.split(":",1)[1])
    if cell in data["opened"]:
        await call.answer("Эта клетка уже открыта."); return
    if cell in data["mines"]:
        data["opened"].append(cell); await state.set_data(data)
        await _finish_grid(call,state,0,"💥 Мина! Ставка проиграна.")
        return
    data["opened"].append(cell)
    safe_remaining=25-data["mine_count"]-(len(data["opened"])-1); total_remaining=25-(len(data["opened"])-1)
    data["multiplier"]*=total_remaining/safe_remaining*0.97
    await state.set_data(data)
    safe_total=25-data["mine_count"]
    if len(data["opened"])==safe_total:
        await state.set_data(data)
        await _finish_grid(call,state,data["bet"]*data["multiplier"],"💎 Все безопасные клетки найдены!")
        return
    safe_remaining=safe_total-len(data["opened"])
    total_remaining=25-len(data["opened"])
    next_mult=data["multiplier"]*total_remaining/safe_remaining*0.97
    payout = floor_coins(data["bet"] * data["multiplier"])
    text=f"💣 Мины\nОткрыто: {len(data['opened'])} из {safe_total}\nСледующий множитель: x{next_mult:.2f}\nМожно забрать: x{data['multiplier']:.2f} / {format_coins(payout)} 🪙"
    await edit_screen(call.bot,call.message.chat.id,call.message.message_id,text,reply_markup=_mines_markup(data))
    await call.answer("Алмаз! Можно продолжать или забрать выигрыш.")


@router.callback_query(CasinoBet.playing_game, F.data.startswith("tower_cell:"))
async def tower_cell(call: CallbackQuery,state:FSMContext):
    data=await state.get_data()
    if call.from_user.id!=data.get("owner_id"):
        await call.answer("Это не твоя игра.",show_alert=True); return
    if data["level"]>=6:
        await call.answer("Башня уже пройдена."); return
    col=int(call.data.split(":",1)[1]); level=data["level"]
    if col!=data["tower_safe"][level]:
        data["tower_hit"]=col; data["level"]+=1; await state.set_data(data)
        await _finish_grid(call,state,0,"💥 Башня рухнула! Ставка проиграна.")
        return
    data["level"]+=1; data["multiplier"]*=1.21; await state.set_data(data)
    if data["level"]==6:
        await _finish_grid(call,state,data["bet"]*data["multiplier"],"🏆 Башня пройдена!")
        return
    payout = floor_coins(data["bet"] * data["multiplier"])
    text=f"🗼 Башня — этаж {data['level']} из 6\nСледующий уровень: x{data['multiplier']*1.21:.2f}\nЗабрать сейчас: {format_coins(payout)} 🪙"
    await edit_screen(call.bot,call.message.chat.id,call.message.message_id,text,reply_markup=_tower_markup(data))
    await call.answer("Этаж пройден!")


@router.callback_query(CasinoBet.playing_game, F.data == "game_cashout")
async def grid_cashout(call: CallbackQuery,state:FSMContext):
    data=await state.get_data()
    if call.from_user.id!=data.get("owner_id"):
        await call.answer("Это не твоя игра.",show_alert=True); return
    if data.get("game")=="mines":
        if not data.get("opened"):
            await call.answer("Сначала открой хотя бы одну клетку.",show_alert=True); return
        label="💎 Вы забрали выигрыш из мин"
    else:
        if not data.get("level"):
            await call.answer("Сначала пройди этаж.",show_alert=True); return
        label="🗼 Вы забрали награду с башни"
    await _finish_grid(call,state,data["bet"]*data["multiplier"],label)


@router.callback_query(CasinoBet.playing_game, F.data == "game_cancel")
async def grid_cancel(call: CallbackQuery,state:FSMContext):
    data=await state.get_data()
    if call.from_user.id!=data.get("owner_id"):
        await call.answer("Это не твоя игра.",show_alert=True); return
    if data.get("game") not in {"mines", "tower"}:
        await state.clear()
        await edit_screen(call.bot,call.message.chat.id,call.message.message_id,"Игра отменена. Выбери другую игру.",reply_markup=casino_games_markup())
        await call.answer()
        return
    if data.get("opened") or data.get("level"):
        await call.answer("Раунд уже начат: забери выигрыш или продолжай.",show_alert=True); return
    get_connection().execute("UPDATE users SET casino_coins=casino_coins+? WHERE user_id=?",(data["bet"],call.from_user.id)); get_connection().commit()
    await state.clear(); await edit_screen(call.bot,call.message.chat.id,call.message.message_id,"Игра отменена, ставка возвращена.",reply_markup=bet_cancel_markup()); await call.answer()


@router.callback_query(F.data.startswith("casino_menu:"))
async def grid_back_to_games(call: CallbackQuery):
    if int(call.data.split(":",1)[1])!=call.from_user.id:
        await call.answer("Это не твоя игра.",show_alert=True); return
    await edit_screen(call.bot,call.message.chat.id,call.message.message_id,"🎰 <b>Выбери игру</b>",reply_markup=casino_games_markup(),parse_mode="HTML")
    await call.answer()


@router.callback_query(F.data == "game_fairness")
async def game_fairness(call: CallbackQuery):
    await call.answer("Поле генерируется случайно на сервере в начале раунда.",show_alert=True)


_GAME_EXTRA = {
    "dice": lambda e: f"face_{e}" if e.isdigit() and 1 <= int(e) <= 6 else None,
    "coin": lambda e: "heads" if e in {"о", "орел", "орёл", "heads"} else "tails" if e in {"р", "решка", "tails"} else None,
    "number": lambda e: f"number_{e}" if e.isdigit() and 1 <= int(e) <= 10 else None,
    "football": lambda e: "goal" if e in {"гол", "г", "goal"} else "miss" if e in {"мимо", "м", "miss"} else None,
    "bowling": lambda e: "strike" if e in {"страйк", "с", "strike"} else "miss" if e in {"мимо", "м", "miss"} else None,
    "darts": lambda e: "hit_target" if e in {"попал", "попадание", "п", "яблочко", "hit"} else "miss" if e in {"мимо", "м", "miss"} else None,
    "basketball": lambda e: "score" if e in {"попал", "попадание", "п", "гол", "score"} else "miss" if e in {"мимо", "м", "miss"} else None,
}
_GAME_AUTOSTART = {"slots": "spin", "crash": "crash", "blackjack": "blackjack_start"}


class _MsgCall:
    """Минимальная замена CallbackQuery: запуск хода прямо из текстовой команды."""

    def __init__(self, user, message, data=""):
        self.from_user = user
        self.message = message
        self.bot = message.bot
        self.data = data

    async def answer(self, *args, **kwargs):
        return None


@router.message(F.text.regexp(GAME_CMD_RE))
async def game_command(message: Message, state: FSMContext):
    match = GAME_CMD_RE.match(message.text.strip())
    key = GAME_ALIASES[match.group("game").lower()]
    uid = message.from_user.id
    user = get_user(uid)
    if not user or user.get("frozen") or user.get("casino_banned"):
        await _temporary_reply(message, "Игра недоступна для этого аккаунта. Новым игрокам: сначала /start в личке с ботом.")
        return
    cfg = settings()
    minimum = max(1000, int(cfg["min_bet"]))
    maximum = int(cfg["max_bet"])
    raw_bet = match.group("bet").lower()
    if raw_bet in {"все", "всё", "all"}:
        bet = min(floor_coins(user["casino_coins"]), maximum)
    else:
        bet = parse_amount(raw_bet)
    if not bet or bet <= 0 or bet % COIN_STEP:
        await _temporary_reply(message, f"Ставка — целое число монет, кратное {COIN_STEP}. Пример: {match.group('game')} 1000 или 1к.")
        return
    if bet < minimum or bet > maximum or user["casino_coins"] < bet:
        await _temporary_reply(message, f"Ставка: {format_coins(minimum)}–{format_coins(maximum)} 🪙. Твой баланс: {format_coins(user['casino_coins'])} 🪙.")
        return
    current = await state.get_data()
    if await state.get_state() == CasinoBet.playing_game.state and current.get("game") in {"mines", "tower"} and current.get("owner_id") == uid:
        await _temporary_reply(message, "Сначала заверши текущую игру: забери выигрыш или нажми «Отменить».")
        return
    extra = (match.group("extra") or "").lower()
    mine_count = DEFAULT_MINES
    if key == "mines" and extra:
        if not extra.isdigit() or not 1 <= int(extra) <= 24:
            await _temporary_reply(message, "Для мин укажи количество от 1 до 24: мины 1000 5")
            return
        mine_count = int(extra)
    if key in {"mines", "tower"}:
        prompt = f"{GAME_INFO[key][0]} · ставка {format_coins(bet)} 🪙"
        if key == "mines":
            prompt += f" · мин {mine_count}"
        sent = await message.answer(prompt)
        await start_grid_game(message, state, key, bet, {"prompt_message_id": sent.message_id, "mine_count": mine_count})
        await _delete_message(message.bot, message.chat.id, message.message_id)
        return
    await state.set_data({"game": key, "bet": bet, "owner_id": uid,
                          "forced_loss": random.random() * 100 < float(cfg["loss_chance"])})
    await state.set_state(CasinoBet.playing_game)
    sent = await message.answer(f"{GAME_INFO[key][0]} · ставка {format_coins(bet)} 🪙\nВыбери ход:",
                                reply_markup=_choice_markup(key))
    await state.update_data(prompt_message_id=sent.message_id)
    await _delete_message(message.bot, message.chat.id, message.message_id)
    action = _GAME_AUTOSTART.get(key) or (_GAME_EXTRA[key](extra) if key in _GAME_EXTRA and extra else None)
    if action:
        await casino_game_action(_MsgCall(message.from_user, sent, f"casino_action:{action}"), state)

@router.message(F.text.lower().in_({"б", "баланс", "balance"}))
async def balance_command(message: Message):
    user = get_user(message.from_user.id)
    if not user:
        await message.answer("Напиши /start в боте, чтобы зарегистрировать аккаунт.")
    else:
        await message.answer(f"💰 Баланс: {format_coins(user['casino_coins'])} 🪙\n⭐ К выводу: ≈ {format_stars(user['balance'])} ⭐")
    await _delete_message(message.bot, message.chat.id, message.message_id)


@router.message(F.text.lower().in_({"профиль", "проф", "profile"}))
@router.message(Command("profile"))
async def profile(message: Message):
    parts = (message.text or "").split(maxsplit=1)
    target = int(parts[1]) if len(parts) > 1 and parts[1].isdigit() else message.from_user.id
    user = get_user(target)
    if not user:
        await message.answer("Профиль не найден. Пользователь должен сначала написать /start.")
        return
    game_stats = stats(target)
    await message.answer(
        f"👤 <b>{escape(user.get('first_name') or 'Игрок')}</b>\n"
        f"🆔 <code>{user['user_id']}</code>\n"
        f"💰 Баланс: <b>{format_coins(user['casino_coins'])} 🪙</b> (≈ {format_stars(user['balance'])} ⭐)\n"
        f"🎮 Игр: {game_stats['games_played']} · Побед: {game_stats['wins']}\n"
        f"📈 Выиграно: {format_coins(game_stats['total_won'])} 🪙 · Потеряно: {format_coins(game_stats['total_lost'])} 🪙"
    )

async def _show_exchange(message: Message, user_id: int):
    user = get_user(user_id)
    if not user:
        await message.answer("Сначала запусти бота через /start.")
        return
    await message.answer(
        "💱 Обмен теперь автоматический\n"
        "Звёзды сразу зачисляются монетами по курсу 1 ⭐ = 10 000 🪙 (1 000 🪙 = 0.1 ⭐). "
        "При выводе баланс считается обратно в звёздах.\n\n"
        f"💰 Баланс: {format_coins(user['casino_coins'])} 🪙 (≈ {format_stars(user['balance'])} ⭐)"
    )


@router.callback_query(F.data == "casino_exchange")
async def exchange_callback(call: CallbackQuery):
    await _show_exchange(call.message, call.from_user.id)
    await call.answer()


@router.message(Command("exchange"))
async def exchange_command(message: Message):
    await _show_exchange(message, message.from_user.id)

@router.message(Command("withdraw"))
async def casino_withdraw_command(message: Message):
    s=stats(message.from_user.id); u=get_user(message.from_user.id)
    if not u:
        await message.answer("Сначала напиши /start.")
        return
    left=max(0,3-s["games_played"])
    if left:
        await message.answer(f"🔒 Вывод доступен после 3 игр. Сыграй ещё {left}.")
    else:
        await message.answer(f"💰 Баланс: {format_coins(u['casino_coins'])} 🪙 (≈ {format_stars(u['balance'])} ⭐). Минимум вывода 15 ⭐. Заявка: вывод 50")
@router.callback_query(F.data == "casino_withdraw")
async def casino_withdraw_menu(call: CallbackQuery):
    s=stats(call.from_user.id); u=get_user(call.from_user.id)
    if not u: await call.answer("Сначала напиши /start",show_alert=True); return
    await call.message.answer(f"💰 Баланс: {format_coins(u['casino_coins'])} 🪙 (≈ {format_stars(u['balance'])} ⭐) · игр {s['games_played']}/3. Вывод от 15 ⭐: напиши «вывод 50».")
    await call.answer()
async def _send_topup_invoice(message: Message, user_id: int, amount: int):
    await message.answer_invoice(
        title=f"Пополнение на {amount} ⭐",
        description=f"Зачисление {amount} звёзд на баланс бота",
        payload=f"casino_topup:{user_id}:{amount}", currency="XTR",
        prices=[LabeledPrice(label=f"{amount} Stars", amount=amount)],
    )


async def _ask_topup_amount(message: Message, state: FSMContext):
    await state.set_state(CasinoTopUp.amount)
    await message.answer(
        "💳 Введи число звёзд для пополнения (от 1 до 10 000).\n"
        "После оплаты звёзды сразу зачислятся монетами по курсу 1 ⭐ = 10 000 🪙.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="Отмена", callback_data="topup_cancel")]]),
    )


@router.callback_query(F.data == "casino_topup")
async def topup_callback(call: CallbackQuery, state: FSMContext):
    if call.message.chat.type != "private":
        await call.answer("Открой личный чат с ботом для пополнения", show_alert=True)
        return
    await _ask_topup_amount(call.message, state)
    await call.answer()


@router.message(Command("topup"))
async def topup(message: Message, state: FSMContext):
    if message.chat.type != "private":
        await message.answer("Пополнение Telegram Stars доступно в личном чате. Открой бота и отправь /topup.")
        return
    await _ask_topup_amount(message, state)


@router.callback_query(F.data == "topup_cancel")
async def topup_cancel(call: CallbackQuery, state: FSMContext):
    await state.clear()
    await call.answer("Пополнение отменено")
    try:
        await call.message.delete()
    except Exception:
        pass


@router.message(CasinoTopUp.amount)
async def topup_amount_input(message: Message, state: FSMContext):
    raw = (message.text or "").strip()
    if not raw.isdigit() or not 1 <= int(raw) <= 10_000:
        await message.answer("Введи целое число от 1 до 10 000 ⭐.")
        return
    amount = int(raw)
    await state.clear()
    await _send_topup_invoice(message, message.from_user.id, amount)


@router.callback_query(F.data.startswith("casino_buy:"))
async def buy(call: CallbackQuery):
    if call.message.chat.type != "private":
        await call.answer("Отправь /topup в личном чате.", show_alert=True)
        return
    try:
        amount = int(call.data.split(":", 1)[1])
    except ValueError:
        amount = 0
    if not 1 <= amount <= 10_000:
        await call.answer("Сумма пополнения должна быть от 1 до 10 000 ⭐.", show_alert=True)
        return
    await _send_topup_invoice(call.message, call.from_user.id, amount)
    await call.answer()

@router.pre_checkout_query()
async def pre_checkout(q: PreCheckoutQuery):
    parts = q.invoice_payload.split(":")
    valid = (
        len(parts) == 3 and parts[0] == "casino_topup" and parts[1].isdigit() and parts[2].isdigit()
        and int(parts[1]) == q.from_user.id and q.currency == "XTR"
        and 1 <= int(parts[2]) <= 10_000 and int(parts[2]) == q.total_amount
    )
    await q.answer(ok=valid, error_message=None if valid else "Платёж не прошёл проверку.")


@router.message(F.successful_payment)
async def payment_success(message: Message):
    payment = message.successful_payment
    parts = payment.invoice_payload.split(":")
    if (len(parts) != 3 or parts[0] != "casino_topup" or not parts[1].isdigit()
            or int(parts[1]) != message.from_user.id or payment.currency != "XTR"
            or not parts[2].isdigit() or not 1 <= int(parts[2]) <= 10_000 or int(parts[2]) != payment.total_amount):
        return
    amount = int(parts[2])
    conn = get_connection()
    try:
        conn.execute("BEGIN IMMEDIATE")
        cur = conn.execute(
            "INSERT OR IGNORE INTO star_deposits(user_id,charge_id,stars,created_at) VALUES(?,?,?,?)",
            (message.from_user.id, payment.telegram_payment_charge_id, amount, datetime.now(timezone.utc).isoformat()),
        )
        if cur.rowcount:
            conn.execute("UPDATE users SET casino_coins=casino_coins+? WHERE user_id=?", (amount * STAR_TO_COINS, message.from_user.id))
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    user = get_user(message.from_user.id)
    await message.answer(
        f"✅ Зачислено {amount} ⭐ → {format_coins(amount * STAR_TO_COINS)} 🪙\n"
        f"💰 Баланс: {format_coins(user['casino_coins'])} 🪙"
    )

_TRANSFER_RE = re.compile(r"^(?:перевод|перевести|передать|кинуть|скинуть)\s+(?P<rest>.+)$", re.I)


def _transfer_filter(message: Message):
    m = _TRANSFER_RE.match((message.text or "").strip())
    if not m:
        return False
    return extract_target_and_amount(message, m.group("rest")).amount is not None


def _mention(user: dict) -> str:
    name = escape(user.get("first_name") or "Игрок")
    return f'<a href="tg://user?id={user["user_id"]}">{name}</a>'


@router.message(Command("transfer"))
@router.message(_transfer_filter)
async def transfer(message: Message):
    text = (message.text or "").strip()
    if text.startswith("/"):
        parts = text.split(maxsplit=1)
        rest = parts[1] if len(parts) > 1 else ""
    else:
        rest = _TRANSFER_RE.match(text).group("rest")
    parsed = extract_target_and_amount(message, rest)
    usage = "Формат: перевод 100 — ответом на сообщение; перевод @ник 100; перевод ID 100. Суммы: 1000, 1к, 1кк."
    if parsed.amount is None:
        await message.answer(usage)
        return
    amount = parse_amount(parsed.amount)
    if not amount or amount <= 0 or amount % COIN_STEP:
        await message.answer(f"Сумма перевода — целое число монет, кратное {COIN_STEP}.")
        return
    if parsed.user_id is None and parsed.username is None:
        await message.answer("Не вижу получателя: ответь на его сообщение или укажи @ник / ID.\n" + usage)
        return
    recipient = resolve_user(parsed)
    sender = get_user(message.from_user.id)
    if not recipient:
        await message.answer("Получатель не найден. Он должен сначала запустить бота (/start в личке).")
        return
    if not sender:
        await message.answer("Сначала запусти бота через /start в личке.")
        return
    uid, target = message.from_user.id, recipient["user_id"]
    if target == uid:
        await message.answer("Нельзя перевести монеты самому себе.")
        return
    if sender.get("frozen") or recipient.get("frozen"):
        await message.answer("Перевод недоступен для замороженного аккаунта.")
        return
    conn = get_connection()
    try:
        conn.execute("BEGIN IMMEDIATE")
        cur = conn.execute(
            "UPDATE users SET casino_coins=casino_coins-? WHERE user_id=? AND casino_coins>=? AND frozen=0",
            (amount, uid, amount),
        )
        if cur.rowcount != 1:
            conn.rollback()
            await message.answer(f"Недостаточно монет. Баланс: {format_coins(sender['casino_coins'])} 🪙.")
            return
        conn.execute("UPDATE users SET casino_coins=casino_coins+? WHERE user_id=?", (amount, target))
        conn.execute(
            "INSERT INTO star_transfers(from_id,to_id,stars,created_at) VALUES(?,?,?,?)",
            (uid, target, amount / STAR_TO_COINS, datetime.now(timezone.utc).isoformat()),
        )
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    await message.answer(f"✅ {_mention(sender)} перевёл {format_coins(amount)} 🪙 → {_mention(recipient)}")
    if message.chat.type != "private":
        try:
            await message.bot.send_message(target, f"💸 Тебе перевели {format_coins(amount)} 🪙 от <code>{uid}</code>.")
        except Exception:
            pass


def _casino_command_target(message: Message) -> int | None:
    args = (message.text or "").split()
    if len(args) >= 2 and args[1].isdigit():
        return int(args[1])
    if message.reply_to_message and message.reply_to_message.from_user:
        return message.reply_to_message.from_user.id
    return None


@router.message(Command("casino_ban"))
async def casino_ban_command(message: Message):
    if message.chat.type == "private":
        await message.answer("Команда /casino_ban работает в группе ответом на сообщение или с ID пользователя.")
        return
    if not is_admin(message.from_user.id):
        await message.answer("Нет доступа.")
        return
    target = _casino_command_target(message)
    user = get_user(target) if target else None
    if not user:
        await message.answer("Пользователь не найден. Укажи ID или ответь на его сообщение; он должен запустить бота через /start.")
        return
    if is_admin(target):
        await message.answer("Нельзя заблокировать администратора казино.")
        return
    conn = get_connection()
    conn.execute("UPDATE users SET casino_banned=1 WHERE user_id=?", (target,))
    conn.commit()
    await message.answer(f"⛔ Пользователь <code>{target}</code> заблокирован в казино.")


@router.message(Command("casino_unban"))
async def casino_unban_command(message: Message):
    if message.chat.type == "private":
        await message.answer("Команда /casino_unban работает в группе ответом на сообщение или с ID пользователя.")
        return
    if not is_admin(message.from_user.id):
        await message.answer("Нет доступа.")
        return
    target = _casino_command_target(message)
    user = get_user(target) if target else None
    if not user:
        await message.answer("Пользователь не найден. Укажи ID или ответь на его сообщение.")
        return
    conn = get_connection()
    conn.execute("UPDATE users SET casino_banned=0 WHERE user_id=?", (target,))
    conn.commit()
    await message.answer(f"✅ Пользователю <code>{target}</code> снова разрешено играть в казино.")

@router.message(F.text.regexp(re.compile(r"^вывод\s+(?P<amount>\d+)$",re.I)))
async def casino_withdraw(message: Message):
    amount=int(re.match(r"^вывод\s+(?P<amount>\d+)$",message.text.strip(),re.I).group('amount')); uid=message.from_user.id; s=stats(uid);u=get_user(uid)
    if not u:await message.answer("Сначала напиши /start.");return
    if s['games_played']<3:await message.answer(f"🔒 Вывод доступен после 3 игр. Сыграно: {s['games_played']}/3.");return
    if amount<15 or u['balance']<amount:await message.answer(f"Минимум вывода 15 ⭐; к выводу доступно ≈ {format_stars(u['balance'])} ⭐ ({format_coins(u['casino_coins'])} 🪙).");return
    conn=get_connection()
    try:
        conn.execute("BEGIN IMMEDIATE");cur=conn.execute("UPDATE users SET casino_coins=casino_coins-? WHERE user_id=? AND casino_coins>=?",(amount*STAR_TO_COINS,uid,amount*STAR_TO_COINS))
        if cur.rowcount!=1:conn.rollback();await message.answer("Недостаточно звёзд.");return
        wid=conn.execute("INSERT INTO casino_withdrawals(user_id,stars,created_at) VALUES(?,?,?)",(uid,amount,datetime.now(timezone.utc).isoformat())).lastrowid;conn.commit()
    except Exception:conn.rollback();raise
    if not ADMIN_CHANNEL_ID:
        conn.execute("UPDATE users SET casino_coins=casino_coins+? WHERE user_id=?",(amount*STAR_TO_COINS,uid));conn.execute("UPDATE casino_withdrawals SET status='Ошибка конфигурации' WHERE id=?",(wid,));conn.commit();await message.answer("Вывод временно недоступен: админ-канал не настроен, баланс возвращён.");return
    try:sent=await message.bot.send_message(ADMIN_CHANNEL_ID,f"🆕 Заявка казино #{wid}\nИгрок: <code>{uid}</code>\nСумма: {amount} ⭐",reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="✅ Одобрить",callback_data=f"casino_wok:{wid}",),InlineKeyboardButton(text="❌ Отклонить",callback_data=f"casino_wrej:{wid}")]]))
    except Exception:
        conn.execute("UPDATE users SET casino_coins=casino_coins+? WHERE user_id=?",(amount*STAR_TO_COINS,uid));conn.execute("UPDATE casino_withdrawals SET status='Ошибка отправки' WHERE id=?",(wid,));conn.commit();await message.answer("Не удалось отправить заявку. Баланс возвращён.");return
    conn.execute("UPDATE casino_withdrawals SET admin_msg_id=? WHERE id=?",(sent.message_id,wid));conn.commit();await message.answer(f"📨 Заявка #{wid} на вывод {amount} ⭐ отправлена администратору.")
@router.callback_query(F.data.startswith("casino_wok:"))
async def approve_withdraw(call: CallbackQuery):
    if not is_admin(call.from_user.id): await call.answer("Нет доступа",show_alert=True); return
    wid=int(call.data.split(":",1)[1]); conn=get_connection(); cur=conn.execute("UPDATE casino_withdrawals SET status='Оплачено' WHERE id=? AND status='Ожидание'",(wid,)); conn.commit()
    if not cur.rowcount: await call.answer("Заявка уже обработана",show_alert=True); return
    row=conn.execute("SELECT user_id,stars FROM casino_withdrawals WHERE id=?",(wid,)).fetchone()
    try: await call.bot.send_message(row["user_id"],f"✅ Заявка на вывод #{wid} ({row['stars']} ⭐) одобрена.")
    except Exception: pass
    await call.message.edit_reply_markup(reply_markup=None); await call.answer("Одобрено")

@router.callback_query(F.data.startswith("casino_wrej:"))
async def reject_withdraw(call: CallbackQuery):
    if not is_admin(call.from_user.id): await call.answer("Нет доступа",show_alert=True); return
    wid=int(call.data.split(":",1)[1]); conn=get_connection()
    try:
        conn.execute("BEGIN IMMEDIATE"); cur=conn.execute("UPDATE casino_withdrawals SET status='Отклонено' WHERE id=? AND status='Ожидание'",(wid,))
        if not cur.rowcount: conn.rollback(); await call.answer("Заявка уже обработана",show_alert=True); return
        row=conn.execute("SELECT user_id,stars FROM casino_withdrawals WHERE id=?",(wid,)).fetchone(); conn.execute("UPDATE users SET casino_coins=casino_coins+? WHERE user_id=?",(row['stars']*STAR_TO_COINS,row['user_id'])); conn.commit()
    except Exception: conn.rollback(); raise
    try: await call.bot.send_message(row["user_id"],f"❌ Заявка на вывод #{wid} отклонена. {row['stars']} ⭐ возвращены на баланс.")
    except Exception: pass
    await call.message.edit_reply_markup(reply_markup=None); await call.answer("Отклонено, баланс возвращён")













