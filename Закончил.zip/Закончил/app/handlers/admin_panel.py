"""Команда /admin: главная панель, статистика, список пользователей и заданий."""
import logging
import re
from datetime import datetime, timedelta

from aiogram import Router, Bot, F
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import Message, CallbackQuery

from app.config import ADMIN_IDS
from app.keyboards.admin import admin_panel_markup, admin_back_markup, admin_task_stats_markup, admin_user_card_markup, admin_user_search_markup
from app.services.tasks import get_all_tasks, delete_task
from app.database import get_connection
from app.services.users import count_invited, get_all_users, get_user, get_user_by_username, update_user
from app.states import AdminUserAction
from app.services.withdrawals import get_all_withdrawals
from app.utils.currency import format_coins, format_stars

logger = logging.getLogger(__name__)
router = Router(name="admin_panel")


def _is_admin(user_id: int) -> bool:
    return user_id in ADMIN_IDS


def _user_card_text(user: dict) -> str:
    reg_date = datetime.fromisoformat(user["registration_date"]).strftime("%d.%m.%Y")
    status = "Заморожен" if user.get("frozen", False) else "Рабочий"
    casino_status = "Заблокирован в казино" if user.get("casino_banned", False) else "Допущен в казино"
    row = get_connection().execute(
        "SELECT games_played, wins, total_won, total_lost FROM casino_stats WHERE user_id=?", (user["user_id"],)
    ).fetchone()
    games, wins, won, lost = (row["games_played"], row["wins"], row["total_won"], row["total_lost"]) if row else (0, 0, 0, 0)
    uname = f"@{user['username']}" if user.get("username") and user["username"] != "NoUsername" else "—"
    return (
        f"ID: {user['user_id']}\n"
        f"Username: {uname}\n\n"
        f"Stars: {format_stars(user['balance'])} ⭐️ · казино: {format_coins(user['casino_coins'])} 🪙\n"
        f"Игр: {games} · Побед: {wins}\n"
        f"Выиграно: {format_coins(int(won))} 🪙 · Потеряно: {format_coins(int(lost))} 🪙\n"
        f"Выполнено заданий: {user.get('tasks_done', 0)}\n"
        f"Рефералов засчитано: {len(user.get('referrals', []))} · перешло по ссылке: {count_invited(user['user_id'])}\n"
        f"Пригласил: {user.get('referrer_id') or '—'}\n\n"
        f"Регистрация: {reg_date}\n"
        f"Статус: {status}\nКазино: {casino_status}"
    )


@router.message(F.text.regexp(re.compile(r"^/админ(?:@\w+)?$", re.IGNORECASE)))
@router.message(Command("admin"))
async def admin_panel_cmd(message: Message) -> None:
    if not _is_admin(message.from_user.id):
        await message.reply("❌ У вас нет доступа к админ-панели.")
        return
    try:
        await message.reply("<b>🔧 Админ-панель</b>", reply_markup=admin_panel_markup(), parse_mode="HTML")
    except Exception as e:
        logger.error(f"Error in admin_panel: {e}", exc_info=True)
        await message.reply("❌ Произошла ошибка при открытии админ-панели.")


@router.callback_query(F.data == "admin_search_user")
async def start_admin_user_search(call: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(call.from_user.id):
        await call.answer("Нет доступа", show_alert=True)
        return
    await state.set_state(AdminUserAction.search_user)
    await call.message.answer(
        "Отправьте ID пользователя или его username с @ или без @:",
        reply_markup=admin_back_markup(),
    )
    await call.answer()


@router.message(AdminUserAction.search_user, F.text)
async def admin_user_search_input(message: Message, state: FSMContext) -> None:
    if not _is_admin(message.from_user.id):
        await state.clear()
        return
    query = (message.text or "").strip()
    user = get_user(int(query)) if query.isdigit() else get_user_by_username(query)
    if not user:
        await message.reply("Пользователь не найден. Проверьте ID или username.")
        return
    await state.clear()
    await message.answer(
        _user_card_text(user),
        reply_markup=admin_user_search_markup(user["user_id"]),
    )


@router.callback_query(F.data == "admin_back")
async def admin_back_callback(call: CallbackQuery, bot: Bot, state: FSMContext) -> None:
    if not _is_admin(call.from_user.id):
        return
    await state.clear()
    await bot.edit_message_text(
        chat_id=call.message.chat.id,
        message_id=call.message.message_id,
        text="<b>Админ-панель</b>",
        reply_markup=admin_panel_markup(),
        parse_mode="HTML",
    )


@router.callback_query(F.data == "admin_cancel")
async def admin_cancel_callback(call: CallbackQuery, bot: Bot, state: FSMContext) -> None:
    if not _is_admin(call.from_user.id):
        return
    await state.clear()
    await call.answer("Действие отменено!")
    await bot.edit_message_text(
        chat_id=call.message.chat.id,
        message_id=call.message.message_id,
        text="<b>Админ-панель</b>",
        reply_markup=admin_panel_markup(),
        parse_mode="HTML",
    )


@router.callback_query(F.data == "admin_stats")
async def admin_stats_callback(call: CallbackQuery, bot: Bot) -> None:
    if not _is_admin(call.from_user.id):
        return

    now = datetime.now()
    users = get_all_users()
    withdrawals = get_all_withdrawals()

    users_day = len([u for u in users if now - datetime.fromisoformat(u["registration_date"]) <= timedelta(days=1)])
    users_week = len([u for u in users if now - datetime.fromisoformat(u["registration_date"]) <= timedelta(weeks=1)])
    users_month = len([u for u in users if now - datetime.fromisoformat(u["registration_date"]) <= timedelta(days=30)])
    users_total = len(users)

    def _stars_sum(delta: timedelta | None) -> float:
        total = 0
        for w in withdrawals:
            if w["status"] != "Звезды отправлены":
                continue
            if delta is None or now - datetime.fromisoformat(w["timestamp"]) <= delta:
                total += w["stars"]
        return total

    stats_text = (
        "<b>Статистика бота</b>\n\n"
        "<b>Пользователи:</b>\n"
        f"За сутки: {users_day}\n"
        f"За неделю: {users_week}\n"
        f"За месяц: {users_month}\n"
        f"За всё время: {users_total}\n\n"
        "<b>Выведено звезд:</b>\n"
        f"За сутки: {_stars_sum(timedelta(days=1))} ⭐️\n"
        f"За неделю: {_stars_sum(timedelta(weeks=1))} ⭐️\n"
        f"За месяц: {_stars_sum(timedelta(days=30))} ⭐️\n"
        f"За всё время: {_stars_sum(None)} ⭐️"
    )
    await bot.edit_message_text(
        chat_id=call.message.chat.id,
        message_id=call.message.message_id,
        text=stats_text,
        reply_markup=admin_back_markup(),
        parse_mode="HTML",
    )


@router.callback_query(F.data.regexp(r"^admin_task_stats_\d+$"))
async def admin_task_stats_callback(call: CallbackQuery, bot: Bot) -> None:
    if not _is_admin(call.from_user.id):
        return

    page = int(call.data.split("_")[3])
    all_tasks = get_all_tasks()
    if not all_tasks:
        await bot.edit_message_text(
            chat_id=call.message.chat.id,
            message_id=call.message.message_id,
            text="Заданий нет!",
            reply_markup=admin_back_markup(),
        )
        return

    task = all_tasks[page - 1]
    now = datetime.now()
    all_users = get_all_users()

    def _completed_count(delta: timedelta | None) -> int:
        count = 0
        for u in all_users:
            if task["id"] not in u.get("completed_tasks", []):
                continue
            if delta is None or now - datetime.fromisoformat(u["registration_date"]) <= delta:
                count += 1
        return count

    task_text = (
        f"Ссылка: {task['link']}\n"
        f"Награда: {task['reward']} ⭐️\n\n"
        "<b>Статистика</b>\n"
        f"За сегодня: {_completed_count(timedelta(days=1))}\n"
        f"За неделю: {_completed_count(timedelta(weeks=1))}\n"
        f"За месяц: {_completed_count(timedelta(days=30))}\n"
        f"За всё время: {_completed_count(None)}"
    )
    await bot.edit_message_text(
        chat_id=call.message.chat.id,
        message_id=call.message.message_id,
        text=task_text,
        reply_markup=admin_task_stats_markup(page, len(all_tasks), task["id"]),
        parse_mode="HTML",
    )


@router.callback_query(F.data.regexp(r"^admin_delete_task_\d+$"))
async def admin_delete_task_callback(call: CallbackQuery, bot: Bot) -> None:
    if not _is_admin(call.from_user.id):
        return

    task_id = int(call.data.split("_")[3])
    delete_task(task_id)
    await call.answer("Задание удалено!")

    all_tasks = get_all_tasks()
    if not all_tasks:
        await bot.edit_message_text(
            chat_id=call.message.chat.id,
            message_id=call.message.message_id,
            text="Заданий нет!",
            reply_markup=admin_back_markup(),
        )
        return

    now = datetime.now()
    all_users = get_all_users()
    task = all_tasks[0]

    def _completed_count(delta: timedelta | None) -> int:
        count = 0
        for u in all_users:
            if task["id"] not in u.get("completed_tasks", []):
                continue
            if delta is None or now - datetime.fromisoformat(u["registration_date"]) <= delta:
                count += 1
        return count

    task_text = (
        f"Ссылка: {task['link']}\n"
        f"Награда: {task['reward']} ⭐️\n\n"
        "<b>Статистика</b>\n"
        f"За сегодня: {_completed_count(timedelta(days=1))}\n"
        f"За неделю: {_completed_count(timedelta(weeks=1))}\n"
        f"За месяц: {_completed_count(timedelta(days=30))}\n"
        f"За всё время: {_completed_count(None)}"
    )
    await bot.edit_message_text(
        chat_id=call.message.chat.id,
        message_id=call.message.message_id,
        text=task_text,
        reply_markup=admin_task_stats_markup(1, len(all_tasks), task["id"]),
        parse_mode="HTML",
    )


@router.callback_query(F.data.regexp(r"^admin_users_\d+$"))
async def admin_users_callback(call: CallbackQuery, bot: Bot) -> None:
    if not _is_admin(call.from_user.id):
        return

    page = int(call.data.split("_")[2])
    all_users = get_all_users()
    if not all_users:
        await bot.edit_message_text(
            chat_id=call.message.chat.id,
            message_id=call.message.message_id,
            text="Пользователей нет!",
            reply_markup=admin_back_markup(),
        )
        return

    user = all_users[page - 1]
    user_text = _user_card_text(user)
    await bot.edit_message_text(
        chat_id=call.message.chat.id,
        message_id=call.message.message_id,
        text=user_text,
        reply_markup=admin_user_card_markup(page, len(all_users), user["user_id"]),
    )


@router.callback_query(F.data.regexp(r"^freeze_\d+$"))
async def freeze_user_callback(call: CallbackQuery) -> None:
    if not _is_admin(call.from_user.id):
        return
    target_id = int(call.data.split("_")[1])
    update_user(target_id, frozen=True)
    await call.answer(f"Пользователь {target_id} заморожен!")


@router.callback_query(F.data.regexp(r"^unfreeze_\d+$"))
async def unfreeze_user_callback(call: CallbackQuery) -> None:
    if not _is_admin(call.from_user.id):
        return
    target_id = int(call.data.split("_")[1])
    update_user(target_id, frozen=False)
    await call.answer(f"Пользователь {target_id} разморожен!")


@router.callback_query(F.data.regexp(r"^reset_\d+$"))
async def reset_user_callback(call: CallbackQuery) -> None:
    if not _is_admin(call.from_user.id):
        return
    target_id = int(call.data.split("_")[1])
    update_user(
        target_id,
        balance=0,
        casino_coins=0,
        completed_tasks=[],
        tasks_done=0,
        referrals=[],
        used_promo_codes=[],
        frozen=False,
    )
    await call.answer(f"Аккаунт пользователя {target_id} обнулен!")



