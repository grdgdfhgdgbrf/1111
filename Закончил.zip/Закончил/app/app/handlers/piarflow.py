"""Пошаговое прохождение заданий PiarFlow: одно задание — одно сообщение.

После подтверждения или пропуска старое сообщение удаляется и вместо него
сразу приходит новое — со следующим заданием, пока очередь не закончится.
"""
import logging

from aiogram import Router, Bot, F
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery

from app.handlers.common import advance_piarflow_flow
from app.services.piarflow import check_piarflow_subscriptions

logger = logging.getLogger(__name__)
router = Router(name="piarflow")


@router.callback_query(F.data == "piarflow_confirm")
async def piarflow_confirm_callback(call: CallbackQuery, bot: Bot, state: FSMContext) -> None:
    user_id = call.from_user.id
    data = await state.get_data()
    queue = data.get("piarflow_queue", [])

    if not queue:
        await call.answer()
        await advance_piarflow_flow(
            bot, call.message.chat.id, user_id, state, call.message.message_id, completed=False
        )
        return

    current_link = queue[0]
    if await check_piarflow_subscriptions(user_id, [current_link]):
        reward = data.get("piarflow_reward", 0.1)
        mode = data.get("piarflow_mode", "earn")
        toast = f"✅ +{reward} ⭐️ Задание засчитано!" if mode == "earn" else "✅ Задание засчитано!"
        await call.answer(toast)
        await advance_piarflow_flow(
            bot, call.message.chat.id, user_id, state, call.message.message_id, completed=True
        )
    else:
        await call.answer("❌ Ты ещё не подписался. Проверь и попробуй снова.", show_alert=True)


@router.callback_query(F.data == "piarflow_skip")
async def piarflow_skip_callback(call: CallbackQuery, bot: Bot, state: FSMContext) -> None:
    await call.answer()
    await advance_piarflow_flow(
        bot, call.message.chat.id, call.from_user.id, state, call.message.message_id, completed=False
    )
