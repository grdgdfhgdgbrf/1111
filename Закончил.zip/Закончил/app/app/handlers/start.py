"""Команда /start, проверка подписки и flow заданий PiarFlow."""
import asyncio
import logging

from aiogram import Router, Bot, F
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.types import Message, CallbackQuery

from app.config import PIARFLOW_API_KEY, WELCOME_STICKER_ID
from app.handlers.common import (
    check_subscription,
    show_subscription_message,
    show_main_menu,
    show_piarflow_tasks,
    should_show_piarflow,
)
from app.services.settings import get_settings
from app.services.users import get_user, create_user, update_user

logger = logging.getLogger(__name__)
router = Router(name="start")


@router.message(CommandStart())
async def send_welcome(message: Message, bot: Bot, state: FSMContext) -> None:
    user_id = message.from_user.id
    try:
        if WELCOME_STICKER_ID:
            sticker = await message.answer_sticker(WELCOME_STICKER_ID)
            async def remove_welcome_sticker():
                await asyncio.sleep(3)
                try:
                    await bot.delete_message(message.chat.id, sticker.message_id)
                except Exception:
                    pass
            asyncio.create_task(remove_welcome_sticker())
        if not await check_subscription(bot, user_id):
            await show_subscription_message(bot, message.chat.id)
            return

        args = message.text.split()
        referrer_id = args[1] if len(args) > 1 and args[1].isdigit() and int(args[1]) != user_id else None

        user = get_user(user_id)
        if not user:
            create_user(
                user_id=user_id,
                first_name=message.from_user.first_name,
                last_name=message.from_user.last_name,
                username=message.from_user.username,
                referrer_id=referrer_id,
            )

            settings = get_settings()
            if settings.get("piarflow_enabled", True) and PIARFLOW_API_KEY:
                await show_piarflow_tasks(bot, message.chat.id, user_id, state)
            else:
                update_user(user_id, piarflow_completed=True)
                await show_main_menu(bot, message.chat.id)
        else:
            update_user(
                user_id,
                username=message.from_user.username or "NoUsername",
                first_name=message.from_user.first_name,
                last_name=message.from_user.last_name or "",
            )
            if should_show_piarflow(user):
                await show_piarflow_tasks(bot, message.chat.id, user_id, state)
            else:
                await show_main_menu(bot, message.chat.id)

    except Exception as e:
        logger.error(f"Error in send_welcome: {e}", exc_info=True)
        await message.answer("❌ Произошла ошибка. Попробуйте /start позже.")


@router.message(Command("stickerid"))
async def sticker_id_command(message: Message):
    sticker = message.reply_to_message.sticker if message.reply_to_message else None
    if not sticker:
        await message.answer("Ответь командой /stickerid на стикер — я пришлю его file_id для WELCOME_STICKER_ID.")
        return
    await message.answer(f"WELCOME_STICKER_ID={sticker.file_id}")


@router.callback_query(F.data == "check_subscription")
async def check_subscription_callback(call: CallbackQuery, bot: Bot) -> None:
    from app.keyboards.user import main_menu_markup

    user_id = call.from_user.id
    if await check_subscription(bot, user_id):
        menu_text = (
            "🏠 <b>Главное меню</b>\n"
            "▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
            "Выбирай действие ниже 👇"
        )
        await bot.edit_message_text(
            menu_text,
            chat_id=call.message.chat.id,
            message_id=call.message.message_id,
            parse_mode="HTML",
            reply_markup=main_menu_markup(),
        )
        if not get_user(user_id):
            create_user(
                user_id=user_id,
                first_name=call.from_user.first_name,
                last_name=call.from_user.last_name,
                username=call.from_user.username,
                referrer_id=None,
            )
    else:
        await call.answer("Вы не подписаны на все обязательные каналы!")
