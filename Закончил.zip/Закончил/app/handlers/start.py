"""Команда /start, проверка подписки и flow заданий PiarFlow."""
import asyncio
import logging
from html import escape

from aiogram import Router, Bot, F
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.types import Message, CallbackQuery

from app.config import PIARFLOW_API_KEY, WELCOME_STICKER_ID
from app.handlers.common import (
    check_subscription,
    show_subscription_message,
    show_main_menu,
    show_piarflow_tasks,
    should_show_piarflow,
)
from app.services.settings import get_settings
from app.services.users import get_user, create_user, update_user, user_exists

logger = logging.getLogger(__name__)
router = Router(name="start")


async def _enter_bot(bot: Bot, chat_id: int, user_id: int, state: FSMContext, is_new: bool) -> None:
    """После успешной проверки подписки: обязательные задания (если нужны) или главное меню."""
    user = get_user(user_id)
    if not user:
        await show_main_menu(bot, chat_id)
        return
    if should_show_piarflow(user):
        await show_piarflow_tasks(bot, chat_id, user_id, state)
        return
    if is_new:
        update_user(user_id, piarflow_completed=True)
    await show_main_menu(bot, chat_id)


@router.message(CommandStart())
async def send_welcome(message: Message, bot: Bot, state: FSMContext) -> None:
    user_id = message.from_user.id
    try:
        # 1) Сначала запоминаем пользователя и того, кто его пригласил, — ДО проверки подписки.
        #    Раньше при неподписанном новичке ссылка терялась, и реферал не засчитывался.
        args = (message.text or "").split()
        payload = args[1] if len(args) > 1 else ""
        referrer_id = payload if payload.isdigit() and int(payload) != user_id else None

        user = get_user(user_id)
        is_new = user is None
        if is_new:
            if referrer_id and not user_exists(int(referrer_id)):
                referrer_id = None
            create_user(
                user_id=user_id,
                first_name=message.from_user.first_name,
                last_name=message.from_user.last_name,
                username=message.from_user.username,
                referrer_id=referrer_id,
            )
            if referrer_id:
                required = int(get_settings().get("referral_tasks_required", 5) or 5)
                name = escape(message.from_user.first_name or "Новый игрок")
                try:
                    await bot.send_message(
                        int(referrer_id),
                        f"👋 По твоей ссылке зашёл <b>{name}</b>.\n"
                        f"Реферал засчитается, когда он выполнит {required} заданий.",
                    )
                except Exception as e:
                    logger.warning("Не удалось уведомить реферера %s: %s", referrer_id, e)
        else:
            update_user(
                user_id,
                username=message.from_user.username or "NoUsername",
                first_name=message.from_user.first_name,
                last_name=message.from_user.last_name or "",
            )

        # 2) Стикер-приветствие.
        if WELCOME_STICKER_ID:
            sticker = await message.answer_sticker(WELCOME_STICKER_ID)

            async def remove_welcome_sticker():
                await asyncio.sleep(3)
                try:
                    await bot.delete_message(message.chat.id, sticker.message_id)
                except Exception:
                    pass

            asyncio.create_task(remove_welcome_sticker())

        # 3) Обязательные подписки.
        if not await check_subscription(bot, user_id):
            await show_subscription_message(bot, message.chat.id)
            return

        await _enter_bot(bot, message.chat.id, user_id, state, is_new)

    except Exception as e:
        logger.error(f"Error in send_welcome: {e}", exc_info=True)
        await message.answer("❌ Произошла ошибка. Попробуйте /start позже.")


@router.message(Command("stickerid"))
async def sticker_id_command(message: Message):
    sticker = message.reply_to_message.sticker if message.reply_to_message else None
    if not sticker:
        await message.answer("Ответь командой /stickerid на стикер — я пришлю его file_id для WELCOME_STICKER_ID.")
        return
    await message.answer(f"WELCOME_STICKER_ID={sticker.file_id}")


@router.callback_query(F.data == "check_subscription")
async def check_subscription_callback(call: CallbackQuery, bot: Bot, state: FSMContext) -> None:
    user_id = call.from_user.id
    if not await check_subscription(bot, user_id):
        await call.answer("Вы не подписаны на все обязательные каналы!")
        return

    is_new = not get_user(user_id)
    if is_new:
        # Запасной вариант: пользователь нажал кнопку, не пройдя /start.
        create_user(
            user_id=user_id,
            first_name=call.from_user.first_name,
            last_name=call.from_user.last_name,
            username=call.from_user.username,
            referrer_id=None,
        )
    await call.answer()
    try:
        await bot.delete_message(call.message.chat.id, call.message.message_id)
    except Exception:
        pass
    await _enter_bot(bot, call.message.chat.id, user_id, state, is_new)
