"""CRUD-операции над таблицей обязательных для подписки каналов (SQLite)."""
from datetime import datetime, timezone

from app.database import get_connection


def get_all_channels() -> list[dict]:
    conn = get_connection()
    now = datetime.now(timezone.utc).isoformat()
    rows = conn.execute("SELECT * FROM channels WHERE expires_at IS NULL OR expires_at > ? ORDER BY id", (now,)).fetchall()
    return [dict(r) for r in rows]


def add_channel(channel_id: str, link: str, expires_at: str | None = None) -> int:
    conn = get_connection()
    cur = conn.execute("INSERT INTO channels (channel_id, link, expires_at) VALUES (?, ?, ?)", (channel_id, link, expires_at))
    conn.commit()
    return cur.lastrowid


def delete_channel_by_index(index: int) -> bool:
    all_channels = get_all_channels()
    if 0 <= index < len(all_channels):
        conn = get_connection()
        conn.execute("DELETE FROM channels WHERE id = ?", (all_channels[index]["id"],))
        conn.commit()
        return True
    return False
