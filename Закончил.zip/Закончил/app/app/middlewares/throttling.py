"""Защита от 'дабл-тапа': игнорируем повторные действия одного пользователя,
если они приходят слишком быстро друг за другом (гонка состояний, спам).
"""
import time
from typing import Any, Awaitable, Callable, Dict

from aiogram import BaseMiddleware
from aiogram.types import CallbackQuery, Message, TelegramObject

THROTTLE_SECONDS = 0.6

_last_action: Dict[int, float] = {}


class ThrottlingMiddleware(BaseMiddleware):
    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any],
    ) -> Any:
        user_id = None
        if isinstance(event, CallbackQuery):
            user_id = event.from_user.id
        elif isinstance(event, Message):
            user_id = event.from_user.id

        if user_id is not None:
            now = time.monotonic()
            last = _last_action.get(user_id, 0.0)
            if now - last < THROTTLE_SECONDS:
                if isinstance(event, CallbackQuery):
                    await event.answer("Не так быстро 🙂", cache_time=1)
                return None
            _last_action[user_id] = now

        return await handler(event, data)
