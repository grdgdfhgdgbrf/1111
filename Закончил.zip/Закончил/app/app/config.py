"""Конфигурация бота. Значения берутся из переменных окружения (.env)."""
import os

from dotenv import load_dotenv

load_dotenv()


def _get_int(name: str, default: int | None = None) -> int | None:
    value = os.getenv(name)
    if value is None or value == "":
        return default
    return int(value)


def _get_channel_id(name: str) -> str | int | None:
    """ID канала может быть числовым (-100...) или строкой (@channel)."""
    value = os.getenv(name)
    if value is None or value == "":
        return None
    try:
        return int(value)
    except ValueError:
        return value


def _parse_admin_ids(raw: str) -> list[int]:
    return [int(x.strip()) for x in raw.split(",") if x.strip()]


BOT_TOKEN: str = os.getenv("BOT_TOKEN", "")

_admin_ids_raw = os.getenv("ADMIN_IDS", "").strip()
_admin_id_raw = os.getenv("ADMIN_ID", "").strip()

if _admin_ids_raw:
    ADMIN_IDS: list[int] = _parse_admin_ids(_admin_ids_raw)
elif _admin_id_raw:
    # ADMIN_ID тоже может содержать несколько ID через запятую — тогда просто
    # трактуем его так же, как ADMIN_IDS, чтобы не требовать точного названия поля.
    ADMIN_IDS = _parse_admin_ids(_admin_id_raw)
else:
    ADMIN_IDS = []

ADMIN_ID: int = ADMIN_IDS[0] if ADMIN_IDS else 0
PUBLIC_CHANNEL_ID = _get_channel_id("PUBLIC_CHANNEL_ID")
ADMIN_CHANNEL_ID = _get_channel_id("ADMIN_CHANNEL_ID")
PIARFLOW_API_KEY: str | None = os.getenv("PIARFLOW_API_KEY") or None


_ALLOWED_BUTTON_STYLES = {"primary", "success", "danger"}

def _button_style(name: str, default: str) -> str:
    value = os.getenv(name, default).strip().lower()
    return value if value in _ALLOWED_BUTTON_STYLES else default

BUTTON_STYLE_PLAY = _button_style("BUTTON_STYLE_PLAY", "success")
BUTTON_STYLE_CASINO = _button_style("BUTTON_STYLE_CASINO", "primary")
BUTTON_STYLE_ACCOUNT = _button_style("BUTTON_STYLE_ACCOUNT", "primary")
BUTTON_STYLE_EARN = _button_style("BUTTON_STYLE_EARN", "success")
BUTTON_STYLE_WITHDRAW = _button_style("BUTTON_STYLE_WITHDRAW", "success")

DB_PATH = os.getenv("DB_PATH", "base.json")

IMAGES_DIR = os.getenv("IMAGES_DIR", "images")

IMAGE_MAIN_MENU = "main_menu.png"
IMAGE_CASINO_MENU = os.getenv("IMAGE_CASINO_MENU", "casino_menu.png")
WELCOME_STICKER_ID = os.getenv("WELCOME_STICKER_ID", "").strip()
IMAGE_SUBSCRIPTION = "subscription.png"
IMAGE_PIARFLOW_TASKS = "piarflow_tasks.png"
IMAGE_PROFILE = "profile.png"
IMAGE_REFERRAL = "referral.png"
IMAGE_WITHDRAW = "withdraw.png"
IMAGE_TOP = "top.png"
IMAGE_PROMO = "promo.png"
IMAGE_TASK = "task.png"
IMAGE_ADMIN_PANEL = "admin_panel.png"

if not BOT_TOKEN:
    raise RuntimeError(
        "BOT_TOKEN не задан. Создайте файл .env на основе .env.example и укажите токен."
    )


