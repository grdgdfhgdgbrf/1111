# Star Casino Bot

## Установка

1. Установите Python 3.11 или новее и выполните `pip install -r requirements.txt`.
2. Скопируйте `.env.example` в `.env`, заполните `BOT_TOKEN`, `ADMIN_ID` (или `ADMIN_IDS`) и `ADMIN_CHANNEL_ID`.
3. Добавьте бота в группу. Для чтения обычных сообщений отключите Group Privacy у @BotFather. Чтобы бот мог удалять сообщения игроков, выдайте ему право удаления сообщений.
4. Запустите `python main.py`.

Файл `.env` с секретами не входит в архив.

## Игра

Кнопка «Казино» открывает список игр. Ставки задаются в игровых монетах: по умолчанию 1 000 🪙 = 0.1 ⭐ (1 ⭐ = 10 000 🪙); курс меняет админ: «Админ-панель → Настройки казино → 💱 Курс звёзд» (применяется сразу везде, балансы и лимиты пересчитываются, стоимость в ⭐ не меняется). Минимальная ставка — 1 000 🪙; игровые монеты хранятся отдельно, обмен доступен в обе стороны через кнопку «Обменять валюту» или `/exchange`; сумма ставки — целое число монет. В футболе, боулинге, дартсе и баскетболе бот показывает анимацию броска Telegram. В «Минах» перед ставкой выберите от 1 до 24 мин. В группе также можно писать команды вроде `дартс 1000`, `футбол 2000` и `мины 1000 5` (последнее число — количество мин).

В профиле отдельно показаны Stars и баланс казино в монетах. После пополнения или начисления открой «Обменять валюту» или отправь `/exchange`, чтобы обменять Stars на монеты; выигрыш можно обменять обратно. Вывод доступен после трёх сыгранных раундов. Для пополнения откройте личный чат, отправьте `/topup` или нажмите «Пополнить Stars» и введите целое число. Переводы Stars: `перевод ID сумма` или ответом на сообщение `перевод сумма`; также доступны `/transfer ID сумма` и `/transfer сумма` ответом. Сумма перевода допускает до трёх знаков после запятой. Оба участника должны запустить бота.

## Администратор

Админский Telegram ID задаётся в `.env`: один ID в `ADMIN_ID` или несколько через запятую в `ADMIN_IDS`. Панель `/admin` позволяет искать пользователя по ID или `@username`, выдать звёзды, настроить оплату за реферала после 5 выполненных им заданий, шанс проигрыша и лимиты ставок в монетах. В группах администратор может заблокировать или разблокировать игрока в казино командами `/casino_ban ID` и `/casino_unban ID`; команды также принимают ответ на сообщение. Общая заморозка аккаунта остаётся отдельной настройкой.

Цвета кнопок главного меню настраиваются в `.env` через `BUTTON_STYLE_PLAY`, `BUTTON_STYLE_CASINO`, `BUTTON_STYLE_ACCOUNT`, `BUTTON_STYLE_EARN` и `BUTTON_STYLE_WITHDRAW`. Допустимые значения Telegram: `primary`, `success`, `danger`.

Результаты раундов рассчитываются ботом. Выплаты по заявкам на вывод обрабатываются администратором вручную.

## Screen images

To attach a photo to a bot screen, put the image in images/ and pass its filename as image= to send_screen from app.utils.images. If the file is missing, the screen is sent as text. The casino picker uses the optional IMAGE_CASINO_MENU filename from .env; its default is casino_menu.png.

## Mines, Tower, and welcome sticker

«Мины» использует поле 5×5: количество мин от 1 до 24 выбирается перед ставкой. В командной игре укажите его третьим числом, например `мины 1000 5`. «Башня» имеет шесть этажей с пятью вариантами на каждом. В обеих играх можно забрать выплату после безопасного хода.

Set WELCOME_STICKER_ID in .env to the Telegram file ID of the greeting sticker. Reply to a sticker with /stickerid in a chat with the bot to get its file ID. The bot sends it on /start and removes it after three seconds.

## Timed required subscriptions and withdrawals

New withdrawal requests use Telegram Stars only; GMP is no longer offered to players. Existing historical GMP requests can still be reviewed by administrators.

To add a temporary mandatory channel, open `/admin` and choose **Add subscription by duration**. Enter a public channel username such as `@my_channel`; the bot must already be an administrator in that channel. Then enter a duration, for example `1 minute`, `5 days`, or `30 months` (Russian units are accepted too). A number without a unit means days. The allowed range is 1 minute through 30 months. Players must join all active required channels before using bot features; they can use the subscription check button after joining. Expired timed subscriptions stop being enforced automatically. Existing permanent required channels remain active until an admin removes them.

## Referral qualification and casino turns

A new referral is counted and the configured referral reward is paid only after that invited player completes five distinct bot tasks. Required onboarding sponsor checks do not count as these five tasks.

Casino rounds now offer inline choices in the game message. Blackjack deals cards, lets the player hit or stand, and then draws for the dealer until 17 or more; a player bust loses, and the higher hand wins (ties return the stake). Balances round down to 0.001 ⭐. Casino bets start at 0.1 ⭐ and are entered in coins at the displayed exchange rate. Guessing outcomes show the selected prediction and payout in the same game message; exact dice-face guesses and football goal/miss guesses pay 1.97x when correct. Other outcomes use their game-specific multipliers.



## Текстовые команды без слэша (группы и личка)

Единый кошелёк — монеты 🪙. Звёзды (пополнение, задания, промокоды, рефералы, выдача админом) сразу зачисляются монетами по текущему курсу (по умолчанию 1 ⭐ = 10 000 🪙; настраивается в админке). При выводе баланс считается обратно в ⭐ (`вывод 50` списывает 50 ⭐ = 500 000 🪙). Суммы можно писать как `1000`, `1к`, `2.5к`, `1кк`; в играх вместо суммы работает `все`.

**Игры** (`слово ставка [параметр]`):
- `мины 10000 6` — ставка и количество мин (1–24); без числа — 3 мины (`DEFAULT_MINES` в `casino.py`)
- `башня 10000`
- `21 10000` (или `очко`, `блэкджек`, `бж`)
- `слоты 1000`, `краш 1000` — запускаются сразу
- `кости 1000 3` (грань 1–6), `монетка 1000 о`/`р`, `число 1000 7` (1–10)
- `футбол 1000 гол|мимо`, `боулинг 1000 страйк|мимо`, `дартс 1000 попал|мимо`, `баскетбол 1000 попал|мимо`
Если параметр не указан, бот покажет кнопки выбора хода.

**Переводы** (в монетах): `перевод 100` ответом на сообщение · `перевод @ник 100` · `перевод 123456789 100` · можно упомянуть игрока без @ник (по имени из подсказки Telegram). Получатель должен хотя бы раз запустить бота.

**Админ-слова** (только для ID из `.env`): `выдать 100000` (ответом) · `выдать @ник 1к` · `выдать ID 5⭐`; `инфо` (себя) / `инфо @ник` / `инфо ID` / ответом; `бан` и `разбан` (бан в казино).

Прочие слова: `баланс`/`б`, `профиль`, `игры`, `вывод 50`.

## Бонус, топ богачей и дуэли

- `бонус` (или `/bonus`, кнопка «🎁 Бонус» в меню) — ежедневный бонус раз в 24 часа. За каждый день подряд бонус растёт: `BONUS_BASE` + `BONUS_STEP` за день серии, максимум на `BONUS_MAX_STREAK`-й день (по умолчанию 1000 → 2200 🪙). Если пропустить больше 48 часов, серия сбрасывается. Настройки в начале `app/handlers/engagement.py`. Помни: 10 000 🪙 = 1 реальная ⭐, бонусы стоят денег.
- `топ` / `топ богачей` / `богачи` (или `/top`, кнопка в меню) — топ-10 по монетам и твоё место. Админы из `.env` в топе не участвуют.
- `дуэль @ник 1000`, `дуэль ID 1000` или ответом `дуэль 1000` (только в группах). Ставка вызвавшего сразу блокируется, соперник нажимает «✅ Принять» или «❌ Отказаться» (120 секунд). Решают два броска 🎲: у кого больше — забирает банк (при ничьей перебрасывают). Шанс проигрыша из админки в дуэлях не применяется, это честная игра между людьми. Комиссия бота — `DUEL_FEE_PERCENT` (по умолчанию 0). Если бот перезапустится во время ожидания, все ставки возвращаются.
