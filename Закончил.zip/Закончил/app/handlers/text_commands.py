"""Админские слова без слэша: выдать, инфо, бан, разбан (работают в группах и в личке)."""
import re
from datetime import datetime
from html import escape

from aiogram import Router
from aiogram.types import Message

from app.database import get_connection
from app.handlers.casino import stats
from app.services.exclusive import is_admin
from app.services.users import get_user, add_coins
from app.utils.currency import format_coins, format_stars
from app.utils.textcmd import extract_target_and_amount, extract_target_only, parse_amount, resolve_user

router = Router(name="text_commands")


def _admin_word(pattern: str):
    rx = re.compile(pattern, re.I)

    def check(message: Message):
        if not message.from_user or not is_admin(message.from_user.id):
            return False
        m = rx.match((message.text or "").strip())
        return {"rest": (m.group("rest") or "").strip()} if m else False

    return check


def _mention(user: dict) -> str:
    return f'<a href="tg://user?id={user["user_id"]}">{escape(user.get("first_name") or "Игрок")}</a>'


@router.message(_admin_word(r"^(?:выдать|выдай|начислить)(?:\s+(?P<rest>.+))?$"))
async def give_command(message: Message, rest: str):
    parsed = extract_target_and_amount(message, rest)
    if parsed.amount is None:
        await message.answer("Формат: выдать 100000 (ответом) · выдать @ник 1к · выдать ID 5⭐")
        return
    amount = parse_amount(parsed.amount)
    if not amount or amount <= 0:
        await message.answer("Сумма — целое число монет (можно 1к, 1кк или 5⭐).")
        return
    if parsed.user_id is None and parsed.username is None:
        await message.answer("Не вижу получателя: ответь на сообщение, укажи @ник или ID.")
        return
    user = resolve_user(parsed)
    if not user:
        await message.answer("Пользователь не найден. Он должен сначала запустить бота (/start).")
        return
    add_coins(user["user_id"], amount)
    updated = get_user(user["user_id"])
    await message.answer(
        f"✅ Выдано {format_coins(amount)} 🪙 → {_mention(user)}\n"
        f"💰 Баланс: {format_coins(updated['casino_coins'])} 🪙 (≈ {format_stars(updated['balance'])} ⭐)"
    )
    try:
        await message.bot.send_message(user["user_id"], f"🎁 Администратор начислил тебе {format_coins(amount)} 🪙.")
    except Exception:
        pass


@router.message(_admin_word(r"^(?:инфо|инфа|info)(?:\s+(?P<rest>.+))?$"))
async def info_command(message: Message, rest: str):
    parsed = extract_target_only(message, rest)
    if parsed.user_id is None and parsed.username is None:
        parsed.user_id = message.from_user.id
    user = resolve_user(parsed)
    if not user:
        await message.answer("Пользователь не найден (он должен был запустить бота).")
        return
    s = stats(user["user_id"])
    status = "⛔ бан в казино" if user["casino_banned"] else "❄️ заморожен" if user["frozen"] else "✅ активен"
    try:
        reg = datetime.fromisoformat(user["registration_date"]).strftime("%d.%m.%Y")
    except Exception:
        reg = "—"
    uname = f"@{escape(user['username'])}" if user.get("username") and user["username"] != "NoUsername" else "—"
    await message.answer(
        f"ℹ️ <b>Инфо</b>\n"
        f"👤 {_mention(user)} · {uname}\n"
        f"🆔 <code>{user['user_id']}</code>\n"
        f"💰 Баланс: <b>{format_coins(user['casino_coins'])} 🪙</b> (≈ {format_stars(user['balance'])} ⭐)\n"
        f"🎮 Игр: {s['games_played']} · Побед: {s['wins']}\n"
        f"📈 Выиграно: {format_coins(s['total_won'])} 🪙 · Потеряно: {format_coins(s['total_lost'])} 🪙\n"
        f"👥 Рефералов: {len(user['referrals'])} · Заданий: {len(user['completed_tasks'])}\n"
        f"📅 Регистрация: {reg}\n"
        f"Статус: {status}"
    )


@router.message(_admin_word(r"^(?P<cmd>разбан|бан)(?:\s+(?P<rest>.+))?$"))
async def ban_words(message: Message, rest: str):
    is_unban = (message.text or "").strip().lower().startswith("разбан")
    parsed = extract_target_only(message, rest)
    user = resolve_user(parsed)
    if not user:
        await message.answer("Укажи игрока: ответом на сообщение, @ник или ID (он должен был запустить бота).")
        return
    if is_admin(user["user_id"]):
        await message.answer("Администратора блокировать нельзя.")
        return
    conn = get_connection()
    conn.execute("UPDATE users SET casino_banned=? WHERE user_id=?", (0 if is_unban else 1, user["user_id"]))
    conn.commit()
    await message.answer(
        f"✅ {_mention(user)} снова может играть в казино." if is_unban else f"⛔ {_mention(user)} заблокирован в казино."
    )
