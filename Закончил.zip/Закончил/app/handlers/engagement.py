"""Бонус, топ богачей и дуэли — всё доступно и словами без слэша."""
import asyncio
import random
import re
from datetime import datetime, timedelta, timezone
from html import escape

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from app.database import get_connection
from app.handlers.casino import _delete_message, record, settings
from app.handlers.menu import _build_top_text
from app.services.exclusive import is_admin
from app.services.settings import get_settings as get_bot_settings
from app.services.users import add_coins, get_user
from app.utils.currency import COIN_STEP, floor_coins, format_coins, min_bet_floor
from app.utils.textcmd import extract_target_and_amount, parse_amount, resolve_user

router = Router(name="engagement")

# ---------- настройки (всё в монетах; курс задаёт админ: «Настройки казино → Курс звёзд») ----------
# Бонус, комиссия дуэли и т.п. меняются в /admin → «🎁 Бонус, дуэли, рефералы».
# Ниже — значения по умолчанию, если в базе ещё ничего не задано.
_DEFAULTS = {"bonus_base": 1000, "bonus_step": 200, "bonus_max_streak": 7, "duel_fee_percent": 0}
DUEL_TIMEOUT = 120        # секунд на ответ соперника


def _cfg(key: str):
    value = get_bot_settings().get(key)
    return _DEFAULTS[key] if value is None else value

# ---------- помощь ----------
HELP_TEXT = (
    "📖 <b>Команды бота</b>\n"
    "Все команды работают и словами без слэша — в личке и в группах.\n\n"
    "🎮 <b>Игры</b> (слово + ставка + ход)\n"
    "• <code>мины 10000 6</code> — ставка и число мин (1–24)\n"
    "• <code>башня 10000 2</code> — ставка и бомб на этаже (1–4)\n"
    "• <code>21 10000</code> — блэкджек (ещё: очко, бж)\n"
    "• <code>слоты 1000</code>\n"
    "• <code>кости 1000 3</code> или <code>кости 1000 чет</code>\n"
    "• <code>краш 1000 2</code> — цель x2\n"
    "• <code>монетка 1000 о</code> / <code>р</code>\n"
    "• <code>число 1000 7</code> (1–10)\n"
    "• <code>футбол 1000 гол</code> / <code>мимо</code>\n"
    "• <code>баскетбол 1000 попал</code> / <code>мимо</code>\n"
    "• <code>боулинг 1000 страйк</code> / <code>сбил</code> / <code>мимо</code>\n"
    "• <code>дартс 1000 яблочко</code> / <code>попал</code> / <code>мимо</code>\n"
    "Ход можно не писать — тогда появятся кнопки. Вместо суммы: <code>1к</code>, <code>1кк</code>, <code>все</code>.\n\n"
    "💸 <b>Деньги</b>\n"
    "• <code>перевод 100</code> — ответом на сообщение игрока\n"
    "• <code>перевод @ник 100</code> или <code>перевод ID 100</code>\n"
    "• <code>баланс</code> · <code>профиль</code> · <code>вывод 50</code>\n\n"
    "⚔️ <b>Дуэль</b> (в группах)\n"
    "• <code>дуэль @ник 1000</code> или ответом: <code>дуэль 1000</code>\n\n"
    "🎁 <b>Прочее</b>\n"
    "• <code>бонус</code> — ежедневный бонус\n"
    "• <code>топ</code> — топ богачей\n"
    "• <code>игры</code> — меню казино\n"
    "• <code>помощь</code> — это сообщение"
)
ADMIN_HELP = (
    "\n\n🛠 <b>Для админов</b>\n"
    "Всё управление — только в панели <code>/admin</code>: выдача монет, инфо об игроке, бан/разбан в казино, "
    "награды за задания, бонус, дуэли, рефералы, промокоды, каналы, рассылка."
)


@router.message(F.text.lower().in_({"помощь", "хелп", "команды", "help"}))
@router.message(Command("help"))
async def help_command(message: Message):
    text = HELP_TEXT
    if message.from_user and is_admin(message.from_user.id):
        text += ADMIN_HELP
    await message.answer(text, parse_mode="HTML")


# ---------- топ ----------
@router.message(F.text.lower().in_({"топ", "топ богачей", "богачи", "top"}))
async def top_word(message: Message):
    await message.answer(
        _build_top_text("day", message.from_user.id),
        parse_mode="HTML",
    )


# ---------- ежедневный бонус ----------
def _fmt_wait(delta: timedelta) -> str:
    minutes = max(1, int(delta.total_seconds() // 60))
    return f"{minutes // 60} ч {minutes % 60} мин"


def claim_bonus(uid: int) -> tuple[bool, str]:
    conn = get_connection()
    row = conn.execute("SELECT last_bonus_at, bonus_streak FROM users WHERE user_id=?", (uid,)).fetchone()
    if row is None:
        return False, "Сначала запусти бота через /start в личке."
    now = datetime.now(timezone.utc)
    prev = row["last_bonus_at"]
    last = datetime.fromisoformat(prev) if prev else None
    if last and now - last < timedelta(hours=24):
        wait = _fmt_wait(timedelta(hours=24) - (now - last))
        return False, f"⏳ Бонус уже получен. Следующий через {wait} (серия: {row['bonus_streak']} дн.)."
    streak = (row["bonus_streak"] or 0) + 1 if last and now - last < timedelta(hours=48) else 1
    max_streak = int(_cfg("bonus_max_streak"))
    amount = int(_cfg("bonus_base")) + int(_cfg("bonus_step")) * (min(streak, max_streak) - 1)
    cur = conn.execute(
        "UPDATE users SET casino_coins=casino_coins+?, last_bonus_at=?, bonus_streak=? "
        "WHERE user_id=? AND last_bonus_at IS ? AND frozen=0",
        (amount, now.isoformat(), streak, uid, prev),
    )
    conn.commit()
    if cur.rowcount != 1:
        return False, "Бонус сейчас недоступен для этого аккаунта."
    balance = get_user(uid)["casino_coins"]
    return True, (
        f"🎁 Ежедневный бонус: +{format_coins(amount)} 🪙\n"
        f"🔥 Серия: {streak} дн. (заходи каждый день — бонус растёт до {int(_cfg("bonus_max_streak"))}-го дня)\n"
        f"💰 Баланс: {format_coins(balance)} 🪙"
    )


@router.message(F.text.lower().in_({"бонус", "bonus", "ежедневка", "daily"}))
@router.message(Command("bonus"))
async def bonus_word(message: Message):
    _, text = claim_bonus(message.from_user.id)
    await message.answer(text)


@router.callback_query(F.data == "daily_bonus")
async def bonus_button(call: CallbackQuery):
    _, text = claim_bonus(call.from_user.id)
    await call.message.answer(text)
    await call.answer()


# ---------- дуэли ----------
_DUEL_RE = re.compile(r"^(?:дуэль|дуэли|duel|вызвать)\s+(?P<rest>.+)$", re.I)


def _duel_filter(message: Message):
    m = _DUEL_RE.match((message.text or "").strip())
    if not m:
        return False
    return extract_target_and_amount(message, m.group("rest")).amount is not None


def _mention(user: dict) -> str:
    return f'<a href="tg://user?id={user["user_id"]}">{escape(user.get("first_name") or "Игрок")}</a>'


def _duel_markup(duel_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="✅ Принять", callback_data=f"duel_yes:{duel_id}"),
        InlineKeyboardButton(text="❌ Отказаться", callback_data=f"duel_no:{duel_id}"),
    ]])


def _get_duel(duel_id: int):
    return get_connection().execute("SELECT * FROM duels WHERE id=?", (duel_id,)).fetchone()


@router.message(Command("duel"))
@router.message(_duel_filter)
async def duel_command(message: Message):
    text = (message.text or "").strip()
    if text.startswith("/"):
        parts = text.split(maxsplit=1)
        rest = parts[1] if len(parts) > 1 else ""
    else:
        rest = _DUEL_RE.match(text).group("rest")
    usage = "Формат: дуэль @ник 1000 · дуэль ID 1000 · или ответом на сообщение: дуэль 1000"
    if message.chat.type == "private":
        await message.answer("⚔️ Дуэли проходят в группах: напиши команду в чате, где есть соперник.")
        return
    parsed = extract_target_and_amount(message, rest)
    bet = parse_amount(parsed.amount) if parsed.amount else None
    if not bet or bet <= 0 or bet % COIN_STEP:
        await message.answer(f"Ставка — целое число монет, кратное {COIN_STEP}.\n{usage}")
        return
    if parsed.user_id is None and parsed.username is None:
        await message.answer("Кого вызываем? Ответь на его сообщение или укажи @ник / ID.\n" + usage)
        return
    opponent = resolve_user(parsed)
    challenger = get_user(message.from_user.id)
    if not challenger:
        await message.answer("Сначала запусти бота через /start в личке.")
        return
    if not opponent:
        await message.answer("Соперник не найден: он должен сначала запустить бота (/start в личке).")
        return
    uid, oid = challenger["user_id"], opponent["user_id"]
    if uid == oid:
        await message.answer("Сам с собой дуэль не получится 🙂")
        return
    for u in (challenger, opponent):
        if u.get("frozen") or u.get("casino_banned"):
            await message.answer("Дуэль недоступна: у одного из игроков ограничен аккаунт.")
            return
    cfg = settings()
    minimum, maximum = max(min_bet_floor(), int(cfg["min_bet"])), int(cfg["max_bet"])
    if bet < minimum or bet > maximum:
        await message.answer(f"Ставка дуэли: {format_coins(minimum)}–{format_coins(maximum)} 🪙.")
        return
    if challenger["casino_coins"] < bet:
        await message.answer(f"Недостаточно монет. Баланс: {format_coins(challenger['casino_coins'])} 🪙.")
        return
    if opponent["casino_coins"] < bet:
        await message.answer(f"У {_mention(opponent)} не хватает монет на такую ставку.")
        return
    conn = get_connection()
    if conn.execute("SELECT 1 FROM duels WHERE challenger_id=? AND status='pending'", (uid,)).fetchone():
        await message.answer("У тебя уже есть активный вызов. Дождись ответа или отмени его.")
        return
    cur = conn.execute(
        "UPDATE users SET casino_coins=casino_coins-? WHERE user_id=? AND casino_coins>=? AND frozen=0",
        (bet, uid, bet),
    )
    if cur.rowcount != 1:
        conn.rollback()
        await message.answer("Недостаточно монет.")
        return
    duel_id = conn.execute(
        "INSERT INTO duels(chat_id, challenger_id, opponent_id, bet, created_at) VALUES(?,?,?,?,?)",
        (message.chat.id, uid, oid, bet, datetime.now(timezone.utc).isoformat()),
    ).lastrowid
    conn.commit()
    sent = await message.answer(
        f"⚔️ <b>Дуэль #{duel_id}</b>\n"
        f"{_mention(challenger)} вызывает {_mention(opponent)} на {format_coins(bet)} 🪙\n"
        f"Банк: {format_coins(bet * 2)} 🪙 · решает бросок 🎲 (у кого больше — тот победил)\n\n"
        f"{_mention(opponent)}, принимаешь? ({DUEL_TIMEOUT} сек.)",
        reply_markup=_duel_markup(duel_id),
        parse_mode="HTML",
    )
    conn.execute("UPDATE duels SET message_id=? WHERE id=?", (sent.message_id, duel_id))
    conn.commit()
    asyncio.create_task(_expire_duel(message.bot, duel_id))


async def _cancel_duel(bot, duel_id: int, text: str) -> bool:
    """Отменяет ожидающую дуэль и возвращает ставку вызвавшему."""
    conn = get_connection()
    duel = _get_duel(duel_id)
    if not duel:
        return False
    cur = conn.execute("UPDATE duels SET status='cancelled' WHERE id=? AND status='pending'", (duel_id,))
    if cur.rowcount != 1:
        return False
    conn.execute("UPDATE users SET casino_coins=casino_coins+? WHERE user_id=?", (duel["bet"], duel["challenger_id"]))
    conn.commit()
    if duel["message_id"]:
        try:
            await bot.edit_message_text(text, chat_id=duel["chat_id"], message_id=duel["message_id"], parse_mode="HTML")
        except Exception:
            pass
    return True


async def _expire_duel(bot, duel_id: int) -> None:
    await asyncio.sleep(DUEL_TIMEOUT)
    await _cancel_duel(bot, duel_id, f"⌛ Дуэль #{duel_id}: соперник не ответил, вызов отменён, ставка возвращена.")


async def _roll(bot, chat_id: int) -> tuple[int, int]:
    for _ in range(3):
        d1 = await bot.send_dice(chat_id, emoji="🎲")
        d2 = await bot.send_dice(chat_id, emoji="🎲")
        await asyncio.sleep(4)
        v1, v2 = d1.dice.value, d2.dice.value
        await _delete_message(bot, chat_id, d1.message_id)
        await _delete_message(bot, chat_id, d2.message_id)
        if v1 != v2:
            return v1, v2
    v1 = random.randint(2, 6)
    v2 = random.randint(1, v1 - 1)
    return (v1, v2) if random.random() < 0.5 else (v2, v1)


@router.callback_query(F.data.startswith("duel_no:"))
async def duel_decline(call: CallbackQuery):
    duel_id = int(call.data.split(":", 1)[1])
    duel = _get_duel(duel_id)
    if not duel or duel["status"] != "pending":
        await call.answer("Дуэль уже завершена.", show_alert=True)
        return
    if call.from_user.id not in (duel["challenger_id"], duel["opponent_id"]):
        await call.answer("Это не твоя дуэль.", show_alert=True)
        return
    if call.from_user.id == duel["challenger_id"]:
        text = f"🚫 Дуэль #{duel_id}: вызов отменён, ставка возвращена."
    else:
        text = f"❌ Дуэль #{duel_id}: соперник отказался, ставка возвращена."
    if await _cancel_duel(call.bot, duel_id, text):
        await call.answer("Готово")
    else:
        await call.answer("Дуэль уже завершена.", show_alert=True)


@router.callback_query(F.data.startswith("duel_yes:"))
async def duel_accept(call: CallbackQuery):
    duel_id = int(call.data.split(":", 1)[1])
    duel = _get_duel(duel_id)
    if not duel or duel["status"] != "pending":
        await call.answer("Дуэль уже завершена.", show_alert=True)
        return
    if call.from_user.id != duel["opponent_id"]:
        await call.answer("Этот вызов адресован не тебе.", show_alert=True)
        return
    opponent = get_user(duel["opponent_id"])
    if not opponent or opponent.get("frozen") or opponent.get("casino_banned"):
        await call.answer("Игра недоступна для этого аккаунта.", show_alert=True)
        return
    bet, cid, oid = int(duel["bet"]), duel["challenger_id"], duel["opponent_id"]
    conn = get_connection()
    # Всё в одной транзакции без await: либо дуэль начата и обе ставки списаны, либо ничего.
    claimed = conn.execute("UPDATE duels SET status='playing' WHERE id=? AND status='pending'", (duel_id,))
    if claimed.rowcount != 1:
        conn.rollback()
        await call.answer("Дуэль уже завершена.", show_alert=True)
        return
    paid = conn.execute(
        "UPDATE users SET casino_coins=casino_coins-? WHERE user_id=? AND casino_coins>=? AND frozen=0 AND casino_banned=0",
        (bet, oid, bet),
    )
    if paid.rowcount != 1:
        conn.execute("UPDATE duels SET status='cancelled' WHERE id=?", (duel_id,))
        conn.execute("UPDATE users SET casino_coins=casino_coins+? WHERE user_id=?", (bet, cid))
        conn.commit()
        await call.answer("Не хватает монет на ставку.", show_alert=True)
        try:
            await call.message.edit_text(f"❌ Дуэль #{duel_id} отменена: у соперника не хватает монет. Ставка возвращена.")
        except Exception:
            pass
        return
    conn.commit()
    await call.answer("Дуэль началась!")
    challenger = get_user(cid)
    try:
        await call.message.edit_text(
            f"⚔️ <b>Дуэль #{duel_id}</b>\n{_mention(challenger)} 🆚 {_mention(opponent)}\nСтавка: {format_coins(bet)} 🪙 · бросаем кости 🎲",
            parse_mode="HTML",
        )
    except Exception:
        pass
    try:
        v1, v2 = await _roll(call.bot, call.message.chat.id)
    except Exception:
        v1 = random.randint(2, 6)
        v2 = random.randint(1, v1 - 1)
        if random.random() < 0.5:
            v1, v2 = v2, v1
    winner, loser = (challenger, opponent) if v1 > v2 else (opponent, challenger)
    pot = bet * 2
    payout = pot - floor_coins(pot * float(_cfg("duel_fee_percent")) / 100)
    add_coins(winner["user_id"], payout)
    record(winner["user_id"], bet, payout)
    record(loser["user_id"], bet, 0)
    conn.execute("UPDATE duels SET status='finished' WHERE id=?", (duel_id,))
    conn.commit()
    try:
        await call.message.edit_text(
            f"⚔️ <b>Дуэль #{duel_id}</b>\n"
            f"{_mention(challenger)}: 🎲 {v1}\n"
            f"{_mention(opponent)}: 🎲 {v2}\n\n"
            f"🏆 Победитель: {_mention(winner)} · +{format_coins(payout - bet)} 🪙 (выплата {format_coins(payout)} 🪙)",
            parse_mode="HTML",
        )
    except Exception:
        pass


def refund_stale_duels() -> None:
    """При старте бота возвращает ставки по дуэлям, которые не успели завершиться."""
    conn = get_connection()
    for d in conn.execute("SELECT * FROM duels WHERE status IN ('pending','playing')").fetchall():
        conn.execute("UPDATE users SET casino_coins=casino_coins+? WHERE user_id=?", (d["bet"], d["challenger_id"]))
        if d["status"] == "playing":
            conn.execute("UPDATE users SET casino_coins=casino_coins+? WHERE user_id=?", (d["bet"], d["opponent_id"]))
        conn.execute("UPDATE duels SET status='cancelled' WHERE id=?", (d["id"],))
    conn.commit()
