"""CRUD-операции над таблицей заявок на вывод (SQLite)."""
from datetime import datetime
from typing import Optional

from app.database import get_connection


def create_withdrawal(
    user_id: int,
    stars: int,
    username: str,
    method: str = "stars",
    gmp_amount: Optional[int] = None,
) -> int:
    conn = get_connection()
    cur = conn.execute(
        "INSERT INTO withdrawals (user_id, stars, method, gmp_amount, status, username, timestamp) "
        "VALUES (?, ?, ?, ?, 'Ожидание', ?, ?)",
        (user_id, stars, method, gmp_amount, username, datetime.now().isoformat()),
    )
    conn.commit()
    return cur.lastrowid


def get_withdrawal(withdrawal_id: int) -> Optional[dict]:
    conn = get_connection()
    row = conn.execute("SELECT * FROM withdrawals WHERE id = ?", (withdrawal_id,)).fetchone()
    return dict(row) if row else None


def update_withdrawal(withdrawal_id: int, **fields) -> None:
    if not fields:
        return
    conn = get_connection()
    set_parts = [f"{k} = ?" for k in fields]
    values = list(fields.values()) + [withdrawal_id]
    conn.execute(f"UPDATE withdrawals SET {', '.join(set_parts)} WHERE id = ?", values)
    conn.commit()


def get_all_withdrawals() -> list[dict]:
    conn = get_connection()
    rows = conn.execute("SELECT * FROM withdrawals ORDER BY id").fetchall()
    return [dict(r) for r in rows]


def get_user_withdrawals(user_id: int) -> list[dict]:
    conn = get_connection()
    rows = conn.execute("SELECT * FROM withdrawals WHERE user_id = ?", (user_id,)).fetchall()
    return [dict(r) for r in rows]
