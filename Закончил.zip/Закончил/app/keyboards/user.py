"""User and casino inline keyboards."""
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder
from app.config import BUTTON_STYLE_PLAY, BUTTON_STYLE_CASINO, BUTTON_STYLE_ACCOUNT, BUTTON_STYLE_EARN, BUTTON_STYLE_WITHDRAW, BUTTON_STYLE_PROMO


def main_menu_markup() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="💰 Заработать звёзды", callback_data="earn_stars", style=BUTTON_STYLE_EARN)
    builder.button(text="🎰 Казино", callback_data="casino_open", style=BUTTON_STYLE_CASINO)
    builder.button(text="👥 Реферальная программа", callback_data="referral", style=BUTTON_STYLE_ACCOUNT)
    builder.button(text="👤 Профиль", callback_data="profile", style=BUTTON_STYLE_ACCOUNT)
    builder.button(text="⭐ Вывести звёзды", callback_data="withdraw", style=BUTTON_STYLE_WITHDRAW)
    builder.button(text="💳 Пополнить Stars", callback_data="casino_topup", style=BUTTON_STYLE_EARN)
    builder.button(text="🎁 Бонус", callback_data="daily_bonus", style=BUTTON_STYLE_EARN)
    builder.button(text="🎁 Промокод", callback_data="promo", style=BUTTON_STYLE_PROMO)
    builder.button(text="🏆 Топ богачей", callback_data="top_day", style=BUTTON_STYLE_ACCOUNT)
    builder.button(text="📢 Наш канал", url="https://t.me/getstarts_news")
    builder.adjust(1, 1, 2, 2, 2, 1)
    return builder.as_markup()


def casino_games_markup() -> InlineKeyboardMarkup:
    games = [
        ("slots", "🎰 Слоты"), ("dice", "🎲 Кости"),
        ("blackjack", "🃏 Блэкджек"), ("football", "⚽ Футбол"),
        ("bowling", "🎳 Боулинг"), ("darts", "🎯 Дартс"),
        ("basketball", "🏀 Баскетбол"), ("coin", "🪙 Монетка"),
        ("number", "🎡 Число 1–10"), ("crash", "🚀 Краш"),
        ("mines", "💣 Мины"), ("tower", "🗼 Башня"),
    ]
    builder = InlineKeyboardBuilder()
    for key, label in games:
        builder.button(text=label, callback_data=f"casino_pick:{key}", style=BUTTON_STYLE_PLAY)
    builder.adjust(2)
    builder.row(InlineKeyboardButton(text="↩️ Назад", callback_data="cancel"))
    return builder.as_markup()


def bet_cancel_markup() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="↩️ К играм", callback_data="casino_menu")]])


def back_markup(callback_data: str = "cancel") -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="Назад", callback_data=callback_data)]])


def subscription_markup(channels: list[dict]) -> InlineKeyboardMarkup:
    rows = [[InlineKeyboardButton(text="Подписаться", url=channel["link"])] for channel in channels]
    rows.append([InlineKeyboardButton(text="Проверить подписку", callback_data="check_subscription")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def piarflow_task_card_markup(link: str, allow_skip: bool) -> InlineKeyboardMarkup:
    rows = [[InlineKeyboardButton(text="🔍 Перейти", url=link), InlineKeyboardButton(text="✅ Подтвердить", callback_data="piarflow_confirm")]]
    if allow_skip:
        rows.append([InlineKeyboardButton(text="⏭ Пропустить", callback_data="piarflow_skip")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def task_page_markup(page: int, total: int, task_doc_id: int) -> InlineKeyboardMarkup:
    nav_row = [
        InlineKeyboardButton(text="<", callback_data=f"tasks_{page - 1}" if page > 1 else "none"),
        InlineKeyboardButton(text=f"{page}/{total}", callback_data="none"),
        InlineKeyboardButton(text=">", callback_data=f"tasks_{page + 1}" if page < total else "none"),
    ]
    return InlineKeyboardMarkup(inline_keyboard=[nav_row, [InlineKeyboardButton(text="Проверить", callback_data=f"check_{task_doc_id}")], [InlineKeyboardButton(text="Назад", callback_data="cancel")]])


def no_tasks_markup() -> InlineKeyboardMarkup:
    return back_markup("cancel")


def withdraw_method_markup() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="⭐ Вывести звёзды", callback_data="withdraw_method_stars")], [InlineKeyboardButton(text="Назад", callback_data="cancel")]])


WITHDRAW_AMOUNTS = (15, 25, 50, 100, 150, 350, 500)


def withdraw_amounts_markup(fee_percent: float = 0) -> InlineKeyboardMarkup:
    """Кнопки сумм вывода. При комиссии на кнопке видно, сколько будет списано всего."""
    from app.utils.currency import get_rate, format_stars, withdraw_fee_coins

    rows = []
    row: list[InlineKeyboardButton] = []
    for i, amount in enumerate(WITHDRAW_AMOUNTS, 1):
        fee = withdraw_fee_coins(amount, fee_percent)
        if fee:
            total = format_stars((amount * get_rate() + fee) / get_rate())
            text = f"{amount} ⭐ (спишется {total})"
        else:
            text = f"{amount} звёзд"
        row.append(InlineKeyboardButton(text=text, callback_data=f"wstars_{amount}"))
        if i % 2 == 0:
            rows.append(row)
            row = []
    if row:
        rows.append(row)
    rows.append([InlineKeyboardButton(text="Назад", callback_data="withdraw")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def top_period_markup(current: str = "day") -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="Назад", callback_data="cancel")]])


def cancel_input_markup() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="❌ Отмена", callback_data="admin_cancel")]])


def cancel_promo_input_markup() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="❌ Отмена", callback_data="cancel_promo_input")]])

