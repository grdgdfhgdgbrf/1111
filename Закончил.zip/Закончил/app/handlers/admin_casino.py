"""Inline admin controls for casino odds and bet limits."""
from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message, InlineKeyboardButton, InlineKeyboardMarkup
from app.config import ADMIN_IDS
from app.database import get_connection
from app.keyboards.admin import admin_back_markup
from app.services.exclusive import set_loss_chance, set_bet_limits
from app.states import CasinoAdmin
from app.utils.currency import COIN_STEP, MAX_RATE, MIN_RATE, format_coins, get_rate, min_bet_floor, rate_star_text, rate_tenth_text, set_rate

router = Router(name="admin_casino")


def _admin(uid: int) -> bool:
    return uid in ADMIN_IDS


def _settings() -> dict:
    return dict(get_connection().execute("SELECT * FROM casino_settings WHERE id=1").fetchone())


def _markup() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🎲 Изменить шанс проигрыша", callback_data="admin_casino_chance")],
        [InlineKeyboardButton(text="🪙 Изменить лимиты ставок", callback_data="admin_casino_bets")],
        [InlineKeyboardButton(text="💱 Курс звёзд", callback_data="admin_casino_rate")],
        [InlineKeyboardButton(text="↩️ В админ-панель", callback_data="admin_back")],
    ])


def _text() -> str:
    s = _settings()
    return (
        "🎰 <b>Настройки казино</b>\n\n"
        f"Принудительный проигрыш: <b>{s['loss_chance']:g}%</b>\n"
        f"Ставка: <b>{format_coins(s['min_bet'])}–{format_coins(s['max_bet'])} 🪙</b>\n"
        f"Курс обмена: <b>{rate_tenth_text()}</b> ({rate_star_text()}). Изменения применяются сразу везде."
    )


@router.callback_query(F.data == "admin_casino_settings")
async def open_settings(call: CallbackQuery):
    if not _admin(call.from_user.id):
        await call.answer("Нет доступа", show_alert=True)
        return
    await call.message.edit_text(_text(), reply_markup=_markup(), parse_mode="HTML")
    await call.answer()


@router.callback_query(F.data == "admin_casino_chance")
async def prompt_chance(call: CallbackQuery, state: FSMContext):
    if not _admin(call.from_user.id):
        await call.answer("Нет доступа", show_alert=True)
        return
    await state.set_state(CasinoAdmin.chance)
    await call.message.edit_text("Введи шанс принудительного проигрыша от 0 до 95%:", reply_markup=admin_back_markup())
    await call.answer()


@router.message(CasinoAdmin.chance)
async def save_chance(message: Message, state: FSMContext):
    if not _admin(message.from_user.id):
        await state.clear()
        return
    try:
        value = float(message.text.replace(",", "."))
        if not 0 <= value <= 95:
            raise ValueError
        set_loss_chance(value)
    except (ValueError, AttributeError):
        await message.answer("Введи число от 0 до 95.")
        return
    await state.clear()
    await message.answer(f"✅ Шанс проигрыша установлен: {value:g}%", reply_markup=_markup())


@router.callback_query(F.data == "admin_casino_bets")
async def prompt_minimum(call: CallbackQuery, state: FSMContext):
    if not _admin(call.from_user.id):
        await call.answer("Нет доступа", show_alert=True)
        return
    await state.set_state(CasinoAdmin.minimum_bet)
    await call.message.edit_text(
        f"Введи минимальную ставку в монетах (не меньше {format_coins(min_bet_floor())})::",
        reply_markup=admin_back_markup(),
    )
    await call.answer()


@router.message(CasinoAdmin.minimum_bet)
async def save_minimum(message: Message, state: FSMContext):
    if not _admin(message.from_user.id):
        await state.clear()
        return
    raw = (message.text or "").strip()
    if not raw.isdigit():
        await message.answer(f"Введи целое число монет, кратное {COIN_STEP}.")
        return
    minimum = int(raw)
    if minimum < min_bet_floor():
        await message.answer(f"Минимальная ставка должна быть не меньше {format_coins(min_bet_floor())} монет (0.1 ⭐ по текущему курсу).")
        return
    await state.update_data(minimum_bet=minimum)
    await state.set_state(CasinoAdmin.maximum_bet)
    await message.answer(
        f"Введи максимальную ставку в монетах, не меньше {format_coins(minimum)}:",
        reply_markup=admin_back_markup(),
    )


@router.message(CasinoAdmin.maximum_bet)
async def save_maximum(message: Message, state: FSMContext):
    if not _admin(message.from_user.id):
        await state.clear()
        return
    data = await state.get_data()
    raw = (message.text or "").strip()
    if not raw.isdigit():
        await message.answer(f"Введи целое число монет, кратное {COIN_STEP}.")
        return
    maximum = int(raw)
    minimum = int(data.get("minimum_bet", 0))
    if maximum < minimum:
        await message.answer("Максимум должен быть целым числом монет, не меньше минимума.")
        return
    set_bet_limits(minimum, maximum)
    await state.clear()
    await message.answer(
        f"✅ Лимиты ставок: {format_coins(minimum)}–{format_coins(maximum)} 🪙",
        reply_markup=_markup(),
    )


@router.callback_query(F.data == "admin_casino_rate")
async def prompt_rate(call: CallbackQuery, state: FSMContext):
    if not _admin(call.from_user.id):
        await call.answer("Нет доступа", show_alert=True)
        return
    await state.set_state(CasinoAdmin.rate)
    await call.message.edit_text(
        f"💱 <b>Курс звёзд</b>\n\nСейчас: <b>{rate_star_text()}</b> ({rate_tenth_text()}).\n\n"
        "Введи, сколько монет 🪙 должно стоить <b>1 ⭐</b> (целое число, кратное 10, "
        f"от {format_coins(MIN_RATE)} до {format_coins(MAX_RATE)}). Например: <code>1000</code> → 100 🪙 = 0.1 ⭐; "
        "<code>10000</code> → 1 000 🪙 = 0.1 ⭐.\n\n"
        "Стоимость в ⭐ не меняется: балансы игроков, лимиты ставок, бонус и ожидающие заявки на вывод "
        "автоматически пересчитываются в монеты по новому курсу.",
        reply_markup=admin_back_markup(),
        parse_mode="HTML",
    )
    await call.answer()


@router.message(CasinoAdmin.rate)
async def save_rate(message: Message, state: FSMContext):
    if not _admin(message.from_user.id):
        await state.clear()
        return
    raw = (message.text or "").strip().replace(" ", "")
    try:
        value = set_rate(int(raw))
    except ValueError:
        await message.answer(f"Введи целое число от {MIN_RATE} до {MAX_RATE}, кратное 10 (монет за 1 ⭐).")
        return
    await state.clear()
    await message.answer(f"✅ Курс обновлён: {rate_star_text()} ({rate_tenth_text()}). Балансы и лимиты пересчитаны, стоимость в ⭐ не изменилась.", reply_markup=_markup())
