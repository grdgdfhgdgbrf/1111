"""Активация промокодов пользователем (через FSM)."""
import logging

from aiogram import Router, Bot, F
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from app.handlers.common import show_main_menu
from app.keyboards.user import cancel_promo_input_markup, main_menu_markup
from app.services.promo import get_promo, mark_promo_used
from app.services.users import get_user, update_user, add_stars
from app.states import PromoStates
from app.utils.currency import floor_stars, format_stars

logger = logging.getLogger(__name__)
router = Router(name="promo")

PROMO_PROMPT_TEXT = (
    "🟡 <b>Активация промокода</b>\n"
    "▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
    "📝 Введи промокод сообщением:"
)


@router.callback_query(F.data == "promo")
async def promo_callback(call: CallbackQuery, state: FSMContext) -> None:
    await state.set_state(PromoStates.waiting_code)
    await call.message.edit_text(
        PROMO_PROMPT_TEXT,
        reply_markup=cancel_promo_input_markup(),
        parse_mode="HTML",
    )


@router.message(Command("promo"))
async def promo_command(message: Message, state: FSMContext) -> None:
    """Ввести и активировать промокод."""
    await state.set_state(PromoStates.waiting_code)
    await message.answer(
        PROMO_PROMPT_TEXT,
        reply_markup=cancel_promo_input_markup(),
        parse_mode="HTML",
    )


@router.callback_query(F.data == "cancel_promo_input")
async def cancel_promo_input_callback(call: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    await call.answer("Ввод промокода отменен.")
    await call.message.edit_text(
        "🏠 <b>Главное меню</b>\n"
        "▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        "Выбирай действие ниже 👇",
        reply_markup=main_menu_markup(),
        parse_mode="HTML",
    )


@router.message(PromoStates.waiting_code, F.text)
async def handle_promo_input(message: Message, state: FSMContext, bot: Bot) -> None:
    user_id = message.from_user.id
    user = get_user(user_id)

    if not user:
        await message.reply("❌ Пользователь не найден. Используйте /start для регистрации.")
        await state.clear()
        return

    try:
        promo_code = message.text.strip()
        promo = get_promo(promo_code)

        if not promo:
            await message.reply("❌ Промокод не найден! Проверьте правильность ввода.")
            return

        used_by = promo.get("used_by", [])

        if user_id in used_by:
            await message.reply("❌ Ты уже активировал этот промокод!")
            await state.clear()
            await show_main_menu(bot, message.chat.id)
            return

        if len(used_by) >= promo["limit"]:
            await message.reply("❌ Лимит активаций промокода исчерпан!")
            await state.clear()
            await show_main_menu(bot, message.chat.id)
            return

        if user.get("frozen", False):
            await message.reply("❌ Твой аккаунт заморожен, активация невозможна!")
            await state.clear()
            await show_main_menu(bot, message.chat.id)
            return

        used_promo_codes = user.get("used_promo_codes", []) + [promo_code]
        add_stars(user_id, promo["reward"])
        update_user(user_id, used_promo_codes=used_promo_codes)
        new_balance = get_user(user_id)["balance"]
        mark_promo_used(promo_code, user_id, used_by)

        await message.reply(
            f"✅ Промокод активирован! Ты получил {promo['reward']} звезд ⭐️\n"
            f"Твой баланс: {format_stars(new_balance)} звезд ⭐️"
        )

        await state.clear()
        await show_main_menu(bot, message.chat.id)

    except Exception as e:
        logger.error(f"Error in handle_promo_input: {e}", exc_info=True)
        await message.reply("❌ Произошла ошибка при активации промокода. Попробуйте позже.")
        await state.clear()

