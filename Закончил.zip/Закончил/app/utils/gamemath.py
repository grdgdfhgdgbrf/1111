"""Честная математика игр: выплата = 0.97 / шанс (перевес казино 3%)."""
import random

HOUSE = 0.97  # доля ставки, которая возвращается игрокам «в среднем»

# Бросок Telegram: (сколько значений у анимации, {выбор: (значения, подпись)}).
# Значения анимаций (как их выдаёт Telegram): ⚽ 1-5 (3,4,5 — гол), 🏀 1-5 (4,5 — попадание),
# 🎳 1-6 (6 — страйк, 1 — мимо), 🎯 1-6 (6 — яблочко, 1 — мимо).
TG_OUTCOMES = {
    "football": (5, {"goal": ((3, 4, 5), "⚽ Гол"), "miss": ((1, 2), "Мимо")}),
    "basketball": (5, {"score": ((4, 5), "🏀 Попадание"), "miss": ((1, 2, 3), "Мимо")}),
    "bowling": (6, {"strike": ((6,), "🎳 Страйк"), "pins": ((2, 3, 4, 5), "Сбил кегли"), "miss": ((1,), "Мимо")}),
    "darts": (6, {"bullseye": ((6,), "🎯 Яблочко"), "hit_target": ((2, 3, 4, 5), "Попал в мишень"), "miss": ((1,), "Мимо")}),
}


def tg_mult(game: str, action: str) -> float:
    total, outcomes = TG_OUTCOMES[game]
    return round(HOUSE * total / len(outcomes[action][0]), 2)


def tg_label(game: str, value: int) -> str:
    for values, label in TG_OUTCOMES[game][1].values():
        if value in values:
            return label
    return "Мимо"


def tg_won(game: str, action: str, value: int) -> bool:
    return value in TG_OUTCOMES[game][1][action][0]


# 🎲 кубик: точная грань (1 из 6) и чёт/нечёт (3 из 6)
DICE_FACE_MULT = round(HOUSE * 6, 2)   # 5.82
DICE_PARITY_MULT = round(HOUSE * 2, 2)  # 1.94

# 🚀 краш: игрок выбирает множитель, шанс его достичь = 0.97 / множитель
CRASH_TARGETS = (1.5, 2, 3, 5, 10)
CRASH_MIN, CRASH_MAX = 1.1, 100


def crash_point() -> float:
    return max(1.0, HOUSE / (1.0 - random.random()))


# 🎰 слоты (возврат ≈ 96.7%)
SLOT_SYMBOLS = ["🍒", "🍋", "🍇", "⭐", "💎", "7️⃣"]
SLOT_WEIGHTS = [30, 26, 20, 14, 7, 3]
SLOT_TRIPLE = {"7️⃣": 50, "💎": 20, "⭐": 8}  # остальные тройки — x3.5
SLOT_TRIPLE_DEFAULT = 3.5
SLOT_PAIR = 1.5


def slots_spin() -> tuple[list[str], float]:
    reels = random.choices(SLOT_SYMBOLS, weights=SLOT_WEIGHTS, k=3)
    if reels[0] == reels[1] == reels[2]:
        return reels, SLOT_TRIPLE.get(reels[0], SLOT_TRIPLE_DEFAULT)
    if len(set(reels)) < 3:
        return reels, SLOT_PAIR
    return reels, 0.0


# 🗼 башня: 6 этажей по 5 клеток, на каждом этаже от 1 до 4 бомб
TOWER_FLOORS = 6
TOWER_CELLS = 5
TOWER_MAX_BOMBS = 4
TOWER_START_MULT = HOUSE  # перевес казино закладывается один раз


def tower_factor(bombs: int) -> float:
    return TOWER_CELLS / (TOWER_CELLS - bombs)


# Максимальный множитель выплаты в мины/башне (защита от гигантских выплат)
MAX_GRID_MULTIPLIER = 100
