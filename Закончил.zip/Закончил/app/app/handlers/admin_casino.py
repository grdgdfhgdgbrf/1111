"""Inline admin controls for casino odds and bet limits."""
from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message, InlineKeyboardButton, InlineKeyboardMarkup
from app.config import ADMIN_IDS
from app.database import get_connection
from app.keyboards.admin import admin_back_markup
from app.services.exclusive import set_loss_chance, set_bet_limits
from app.states import CasinoAdmin
from app.utils.currency import COIN_STEP, format_coins

router = Router(name="admin_casino")


def _admin(uid: int) -> bool:
    return uid in ADMIN_IDS


def _settings() -> dict:
    return dict(get_connection().execute("SELECT * FROM casino_settings WHERE id=1").fetchone())


def _markup() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🎲 Изменить шанс проигрыша", callback_data="admin_casino_chance")],
        [InlineKeyboardButton(text="🪙 Изменить лимиты ставок", callback_data="admin_casino_bets")],
        [InlineKeyboardButton(text="↩️ В админ-панель", callback_data="admin_back")],
    ])


def _text() -> str:
    s = _settings()
    return (
        "🎰 <b>Настройки казино</b>\n\n"
        f"Принудительный проигрыш: <b>{s['loss_chance']:g}%</b>\n"
        f"Ставка: <b>{format_coins(s['min_bet'])}–{format_coins(s['max_bet'])} 🪙</b>\n"
        "Курс обмена: 1 000 🪙 = 0.1 ⭐. Изменения применяются сразу ко всем играм."
    )


@router.callback_query(F.data == "admin_casino_settings")
async def open_settings(call: CallbackQuery):
    if not _admin(call.from_user.id):
        await call.answer("Нет доступа", show_alert=True)
        return
    await call.message.edit_text(_text(), reply_markup=_markup(), parse_mode="HTML")
    await call.answer()


@router.callback_query(F.data == "admin_casino_chance")
async def prompt_chance(call: CallbackQuery, state: FSMContext):
    if not _admin(call.from_user.id):
        await call.answer("Нет доступа", show_alert=True)
        return
    await state.set_state(CasinoAdmin.chance)
    await call.message.edit_text("Введи шанс принудительного проигрыша от 0 до 95%:", reply_markup=admin_back_markup())
    await call.answer()


@router.message(CasinoAdmin.chance)
async def save_chance(message: Message, state: FSMContext):
    if not _admin(message.from_user.id):
        await state.clear()
        return
    try:
        value = float(message.text.replace(",", "."))
        if not 0 <= value <= 95:
            raise ValueError
        set_loss_chance(value)
    except (ValueError, AttributeError):
        await message.answer("Введи число от 0 до 95.")
        return
    await state.clear()
    await message.answer(f"✅ Шанс проигрыша установлен: {value:g}%", reply_markup=_markup())


@router.callback_query(F.data == "admin_casino_bets")
async def prompt_minimum(call: CallbackQuery, state: FSMContext):
    if not _admin(call.from_user.id):
        await call.answer("Нет доступа", show_alert=True)
        return
    await state.set_state(CasinoAdmin.minimum_bet)
    await call.message.edit_text(
        f"Введи минимальную ставку в монетах (не меньше 1 000, шаг {COIN_STEP}):",
        reply_markup=admin_back_markup(),
    )
    await call.answer()


@router.message(CasinoAdmin.minimum_bet)
async def save_minimum(message: Message, state: FSMContext):
    if not _admin(message.from_user.id):
        await state.clear()
        return
    raw = (message.text or "").strip()
    if not raw.isdigit():
        await message.answer(f"Введи целое число монет, кратное {COIN_STEP}.")
        return
    minimum = int(raw)
    if minimum < 1000 or minimum % COIN_STEP:
        await message.answer("Минимальная ставка должна быть не меньше 1 000 монет и кратна 10.")
        return
    await state.update_data(minimum_bet=minimum)
    await state.set_state(CasinoAdmin.maximum_bet)
    await message.answer(
        f"Введи максимальную ставку в монетах, не меньше {format_coins(minimum)}:",
        reply_markup=admin_back_markup(),
    )


@router.message(CasinoAdmin.maximum_bet)
async def save_maximum(message: Message, state: FSMContext):
    if not _admin(message.from_user.id):
        await state.clear()
        return
    data = await state.get_data()
    raw = (message.text or "").strip()
    if not raw.isdigit():
        await message.answer(f"Введи целое число монет, кратное {COIN_STEP}.")
        return
    maximum = int(raw)
    minimum = int(data.get("minimum_bet", 0))
    if maximum < minimum or maximum % COIN_STEP:
        await message.answer("Максимум должен быть числом монет, кратным 10, не меньше минимума.")
        return
    set_bet_limits(minimum, maximum)
    await state.clear()
    await message.answer(
        f"✅ Лимиты ставок: {format_coins(minimum)}–{format_coins(maximum)} 🪙",
        reply_markup=_markup(),
    )
