"""Состояния FSM для многошаговых диалогов."""
from aiogram.fsm.state import State, StatesGroup


class PromoStates(StatesGroup):
    waiting_code = State()


class AdminAddChannel(StatesGroup):
    channel_id = State()
    link = State()


class AdminAddRequiredSub(StatesGroup):
    channel = State()
    duration = State()


class AdminDeleteChannel(StatesGroup):
    number = State()


class AdminAddTask(StatesGroup):
    channel_id = State()
    link = State()
    reward = State()


class AdminDeleteTask(StatesGroup):
    number = State()


class AdminSettings(StatesGroup):
    min_referrals = State()
    min_tasks = State()
    referral_reward = State()
    task_reward = State()


class AdminPromo(StatesGroup):
    code = State()
    reward = State()
    limit = State()


class AdminDeletePromo(StatesGroup):
    number = State()


class AdminUserAction(StatesGroup):
    freeze = State()
    unfreeze = State()
    reset = State()
    star_target = State()
    star_amount = State()
    search_user = State()
from aiogram.fsm.state import State, StatesGroup


class CasinoAdmin(StatesGroup):
    chance = State()
    minimum_bet = State()
    maximum_bet = State()

class CasinoTopUp(StatesGroup):
    amount = State()


class CasinoExchange(StatesGroup):
    amount = State()


class CasinoBet(StatesGroup):
    waiting_mine_count = State()
    waiting_stake = State()
    waiting_guess = State()
    playing_game = State()



