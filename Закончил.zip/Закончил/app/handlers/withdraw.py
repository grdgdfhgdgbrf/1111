"""Вывод звёзд. Заявка уходит администратору в группу.

Комиссия на вывод (настраивается в /admin → «Бонус, дуэли, рефералы, вывод»):
игрок заказывает N ⭐ к получению, а списывается N + комиссия.
Пример: вывод 15 ⭐ при комиссии 10% → списывается 16.5 ⭐, админ отправляет 15 ⭐.
"""
import logging
from decimal import Decimal

from aiogram import Router, Bot, F
from aiogram.filters import Command
from aiogram.types import CallbackQuery, Message, InlineKeyboardMarkup, InlineKeyboardButton

from app.config import ADMIN_IDS, PUBLIC_CHANNEL_ID, ADMIN_CHANNEL_ID
from app.handlers.common import check_subscription, show_subscription_message
from app.keyboards.user import withdraw_method_markup, withdraw_amounts_markup, back_markup, WITHDRAW_AMOUNTS
from app.services.settings import get_settings
from app.services.users import get_user
from app.services.withdrawals import (
    create_withdrawal_charged, get_withdrawal, resolve_withdrawal,
    update_withdrawal, STATUS_SENT, STATUS_DENIED,
)
from app.utils.images import edit_screen
from app.utils.currency import format_coins, format_stars, get_rate, withdraw_fee_coins, withdrawal_total_coins

logger = logging.getLogger(__name__)
GMP_RATE = 3  # Legacy rate for already pending historical requests only.
router = Router(name="withdraw")


def _coins_to_stars_text(coins: int) -> str:
    return format_stars(Decimal(int(coins)) / get_rate())


def _fee_percent() -> float:
    try:
        return float(get_settings().get("withdraw_fee_percent", 0) or 0)
    except (TypeError, ValueError):
        return 0.0


def _fee_line(percent: float) -> str:
    if percent <= 0:
        return ""
    return (
        f"💸 Комиссия на вывод: <b>{percent:g}%</b> — она добавляется сверху к сумме вывода "
        f"(например, вывод 15 ⭐ спишет {_coins_to_stars_text(15 * get_rate() + withdraw_fee_coins(15, percent))} ⭐)\n"
    )


async def _safe_edit(bot: Bot, call: CallbackQuery, text: str, markup=None) -> None:
    """Редактирует экран (текст или подпись фото) и не падает, если Telegram отказал."""
    try:
        await edit_screen(bot, call.message.chat.id, call.message.message_id, text, reply_markup=markup, parse_mode="HTML")
    except Exception as exc:  # например «message is not modified»
        logger.debug("edit_screen failed: %s", exc)


def _build_withdraw_text(user: dict) -> str:
    settings = get_settings()
    min_referrals = settings.get("min_referrals", 5)
    min_tasks = settings.get("min_tasks", 3)
    referrals_count = len(user.get("referrals", []))
    tasks_count = user.get("tasks_done", 0)
    return (
        "🟣 <b>Вывод</b>\n"
        "▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        f"⭐️ Доступно к выводу: <b>{format_stars(user['balance'])}</b> (баланс {format_coins(user['casino_coins'])} 🪙)\n\n"
        f"📋 Условия: {min_referrals} друзей и {min_tasks} заданий\n"
        f"📊 У тебя: {referrals_count} друзей и {tasks_count} заданий\n"
        f"{_fee_line(_fee_percent())}\n"
        "Выбери сумму вывода 👇"
    )


def _request_text(withdrawal: dict, status: str) -> str:
    """Текст заявки для канала и админов (по данным из БД, поэтому одинаков при повторной отрисовке)."""
    wid = withdrawal["id"]
    stars = withdrawal["stars"]
    fee_coins = int(withdrawal.get("fee_coins") or 0)
    head = (
        f"Заявка №{wid}\n"
        f"Пользователь: @{withdrawal['username']} | ID: {withdrawal['user_id']}\n"
    )
    if withdrawal.get("method", "stars") == "gmp":
        return (
            head + "Метод: 💎 GMP\n"
            f"Количество: {withdrawal.get('gmp_amount')} GMP (списано {stars} ⭐️)\n"
            f"Курс: 1 ⭐️ = {GMP_RATE} GMP\n"
            f"Статус: {status}"
        )
    text = head + "Метод: ⭐ Звёзды\n" + f"К выплате: {stars} звёзд ⭐️\n"
    if fee_coins:
        total = _coins_to_stars_text(stars * get_rate() + fee_coins)
        text += f"Комиссия: {_coins_to_stars_text(fee_coins)} ⭐️ (с игрока списано {total} ⭐️)\n"
    return text + f"Статус: {status}"


@router.callback_query(F.data == "withdraw")
async def withdraw_menu_callback(call: CallbackQuery, bot: Bot) -> None:
    user_id = call.from_user.id
    if not await check_subscription(bot, user_id):
        await show_subscription_message(bot, call.message.chat.id)
        return

    user = get_user(user_id)
    if not user:
        await call.answer("Пользователь не найден. Используйте /start.")
        return

    await edit_screen(
        bot, call.message.chat.id, call.message.message_id,
        _build_withdraw_text(user), reply_markup=withdraw_method_markup(), parse_mode="HTML",
    )


@router.message(Command("withdraw"))
async def withdraw_command(message: Message, bot: Bot) -> None:
    """Открыть меню вывода."""
    user_id = message.from_user.id
    if not await check_subscription(bot, user_id):
        await show_subscription_message(bot, message.chat.id)
        return

    user = get_user(user_id)
    if not user:
        await message.reply("Пользователь не найден. Используйте /start.")
        return

    await message.answer(
        _build_withdraw_text(user),
        reply_markup=withdraw_method_markup(),
        parse_mode="HTML",
    )


@router.callback_query(F.data == "withdraw_method_stars")
async def withdraw_method_stars_callback(call: CallbackQuery) -> None:
    percent = _fee_percent()
    text = (
        "⭐ <b>Вывод звёзд</b>\n"
        "▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        f"{_fee_line(percent)}"
        "Выбери сумму для вывода 👇"
    )
    await edit_screen(call.bot, call.message.chat.id, call.message.message_id, text, reply_markup=withdraw_amounts_markup(percent), parse_mode="HTML")


async def _process_withdrawal(call: CallbackQuery, bot: Bot, amount: int) -> None:
    user_id = call.from_user.id
    await call.answer()
    if not await check_subscription(bot, user_id):
        await show_subscription_message(bot, call.message.chat.id)
        return

    user = get_user(user_id)
    if not user:
        await call.answer("Пользователь не найден. Используйте /start.")
        return

    settings = get_settings()
    min_referrals = settings.get("min_referrals", 5)
    min_tasks = settings.get("min_tasks", 3)
    referrals_count = len(user.get("referrals", []))
    # tasks_done считает ВСЕ задания (локальные + «Заработать звёзды»), как и в профиле.
    tasks_count = user.get("tasks_done", 0)

    back_target = "withdraw_method_stars"

    if user.get("frozen", False):
        await _safe_edit(bot, call, "Твой аккаунт заморожен, вывод невозможен!", back_markup("cancel"))
        return

    fee_coins = withdraw_fee_coins(amount, _fee_percent())
    total_coins = amount * get_rate() + fee_coins

    if user["casino_coins"] < total_coins:
        if fee_coins:
            text = (
                f"Недостаточно звёзд!\nДля вывода {amount} ⭐ нужно {_coins_to_stars_text(total_coins)} ⭐ "
                f"(вывод + комиссия {_coins_to_stars_text(fee_coins)} ⭐).\n"
                f"Твой баланс: {format_stars(user['balance'])} ⭐️"
            )
        else:
            text = f"Недостаточно звезд!\nТвой баланс: {format_stars(user['balance'])} звезд ⭐️"
        await _safe_edit(bot, call, text, back_markup(back_target))
        return

    if referrals_count < min_referrals or tasks_count < min_tasks:
        await _safe_edit(
            bot, call,
            f"Не хватает условий!\nНужно: {min_referrals} друзей и {min_tasks} заданий\n"
            f"У тебя: {referrals_count} друзей и {tasks_count} заданий",
            back_markup(back_target),
        )
        return

    # Списание и создание заявки — одной транзакцией.
    withdrawal_id = create_withdrawal_charged(user_id, amount, fee_coins, user["username"])
    if withdrawal_id is None:
        await _safe_edit(bot, call, "Недостаточно средств для вывода.", back_markup(back_target))
        return

    withdrawal = get_withdrawal(withdrawal_id)
    public_text = _request_text(withdrawal, "Ожидание")
    public_msg = None
    try:
        if not ADMIN_CHANNEL_ID:
            raise RuntimeError("ADMIN_CHANNEL_ID не задан")
        if PUBLIC_CHANNEL_ID:
            public_msg = await bot.send_message(PUBLIC_CHANNEL_ID, public_text)
        public_msg_id = public_msg.message_id if public_msg else 0
        markup = InlineKeyboardMarkup(
            inline_keyboard=[[
                InlineKeyboardButton(text="Отправлено", callback_data=f"withdraw_sent_{withdrawal_id}_{public_msg_id}"),
                InlineKeyboardButton(text="Отказано", callback_data=f"withdraw_denied_{withdrawal_id}_{public_msg_id}"),
            ]]
        )
        admin_msg = await bot.send_message(ADMIN_CHANNEL_ID, public_text, reply_markup=markup)
        update_withdrawal(withdrawal_id, admin_msg_id=admin_msg.message_id)
    except Exception as exc:
        # Заявка не дошла до админов — возвращаем всё списанное, чтобы деньги не пропали.
        logger.error("Не удалось отправить заявку №%s: %s", withdrawal_id, exc, exc_info=True)
        resolve_withdrawal(withdrawal_id, STATUS_DENIED)
        if public_msg:
            try:
                await bot.delete_message(PUBLIC_CHANNEL_ID, public_msg.message_id)
            except Exception:
                pass
        await _safe_edit(bot, call, "Не удалось отправить заявку администратору. Баланс возвращён, попробуй позже.", back_markup("cancel"))
        return

    confirm = f"✅ Заявка №{withdrawal_id} на {amount} звёзд ⭐️ создана!"
    if fee_coins:
        confirm += (
            f"\nКомиссия: {_coins_to_stars_text(fee_coins)} ⭐️"
            f"\nСписано с баланса: {_coins_to_stars_text(total_coins)} ⭐️"
        )
    await _safe_edit(bot, call, confirm, back_markup("cancel"))


@router.callback_query(F.data.regexp(r"^wstars_\d+$"))
async def withdraw_stars_amount_callback(call: CallbackQuery, bot: Bot) -> None:
    amount = int(call.data.split("_")[1])
    if amount not in WITHDRAW_AMOUNTS:
        await call.answer()
        return
    await _process_withdrawal(call, bot, amount=amount)


@router.callback_query(F.data.startswith("withdraw_sent_") | F.data.startswith("withdraw_denied_"))
async def withdraw_admin_decision_callback(call: CallbackQuery, bot: Bot) -> None:
    if call.from_user.id not in ADMIN_IDS:
        return

    parts = call.data.split("_")
    action = parts[1]
    withdrawal_id = int(parts[2])
    public_msg_id = int(parts[3])

    status = STATUS_SENT if action == "sent" else STATUS_DENIED
    # Атомарно: заявка закрывается один раз, при отказе деньги возвращаются в той же транзакции.
    withdrawal = resolve_withdrawal(withdrawal_id, status)
    if withdrawal is None:
        await call.answer("Заявка не найдена или уже обработана.", show_alert=True)
        try:
            await call.message.edit_reply_markup(reply_markup=None)
        except Exception:
            pass
        return

    text = _request_text(withdrawal, status)
    if public_msg_id and PUBLIC_CHANNEL_ID:
        try:
            await bot.edit_message_text(chat_id=PUBLIC_CHANNEL_ID, message_id=public_msg_id, text=text)
        except Exception as exc:
            logger.warning("Не удалось обновить публичное сообщение заявки №%s: %s", withdrawal_id, exc)
    try:
        await bot.edit_message_text(chat_id=ADMIN_CHANNEL_ID, message_id=call.message.message_id, text=text)
    except Exception as exc:
        logger.warning("Не удалось обновить админское сообщение заявки №%s: %s", withdrawal_id, exc)

    target_user_id = withdrawal["user_id"]
    try:
        if action == "sent":
            await bot.send_message(target_user_id, f"✅ Заявка №{withdrawal_id} выполнена!")
        else:
            refunded = _coins_to_stars_text(withdrawal_total_coins(withdrawal["stars"], withdrawal.get("fee_coins"), withdrawal.get("rate")))
            await bot.send_message(target_user_id, f"❌ Заявка №{withdrawal_id} отклонена. {refunded} ⭐ возвращены на баланс.")
    except Exception as exc:
        logger.warning("Не удалось уведомить пользователя %s: %s", target_user_id, exc)
    await call.answer("Готово")
