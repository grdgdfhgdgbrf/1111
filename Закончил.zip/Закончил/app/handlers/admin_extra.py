"""Всё остальное, что раньше жило в чате словами/командами, теперь только в /admin:
бан и разбан в казино, настройки бонуса/дуэлей/рефералов, награда за конкретное задание."""
import logging
from html import escape

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from app.config import ADMIN_IDS
from app.database import get_connection
from app.keyboards.admin import admin_back_markup
from app.keyboards.user import cancel_input_markup
from app.services.settings import get_settings, update_settings
from app.services.tasks import get_task, update_task_reward
from app.services.users import get_user, get_user_by_username
from app.states import AdminSettings, AdminUserAction
from app.utils.currency import format_coins, format_stars, parse_stars

logger = logging.getLogger(__name__)
router = Router(name="admin_extra")


def _is_admin(user_id: int) -> bool:
    return user_id in ADMIN_IDS


def _find_user(raw: str) -> dict | None:
    raw = (raw or "").strip()
    return get_user(int(raw)) if raw.isdigit() else get_user_by_username(raw)


def _set_casino_ban(user_id: int, banned: bool) -> None:
    conn = get_connection()
    conn.execute("UPDATE users SET casino_banned=? WHERE user_id=?", (1 if banned else 0, user_id))
    conn.commit()


# ---------------------------------------------------------------- бан / разбан в казино
async def _prompt(call: CallbackQuery, state: FSMContext, st, text: str) -> None:
    if not _is_admin(call.from_user.id):
        await call.answer("Нет доступа", show_alert=True)
        return
    await state.set_state(st)
    await call.message.answer(text, reply_markup=cancel_input_markup())
    await call.answer()


@router.callback_query(F.data == "admin_casino_ban")
async def prompt_casino_ban(call: CallbackQuery, state: FSMContext) -> None:
    await _prompt(call, state, AdminUserAction.casino_ban, "Введите ID или @username игрока, которого заблокировать в казино:")


@router.callback_query(F.data == "admin_casino_unban")
async def prompt_casino_unban(call: CallbackQuery, state: FSMContext) -> None:
    await _prompt(call, state, AdminUserAction.casino_unban, "Введите ID или @username игрока, которого разблокировать в казино:")


async def _apply_ban(message: Message, state: FSMContext, banned: bool) -> None:
    if not _is_admin(message.from_user.id):
        await state.clear()
        return
    user = _find_user(message.text or "")
    if not user:
        await message.reply("Пользователь не найден. Он должен был запустить бота. Проверьте ID/username.")
        return
    if banned and _is_admin(user["user_id"]):
        await message.reply("Администратора блокировать нельзя.")
        return
    _set_casino_ban(user["user_id"], banned)
    await state.clear()
    await message.reply(
        f"{'⛔ Заблокирован в казино' if banned else '✅ Снова допущен в казино'}: <code>{user['user_id']}</code>",
        reply_markup=admin_back_markup(),
        parse_mode="HTML",
    )


@router.message(AdminUserAction.casino_ban, F.text)
async def casino_ban_input(message: Message, state: FSMContext) -> None:
    await _apply_ban(message, state, True)


@router.message(AdminUserAction.casino_unban, F.text)
async def casino_unban_input(message: Message, state: FSMContext) -> None:
    await _apply_ban(message, state, False)


@router.callback_query(F.data.regexp(r"^c(un)?ban_\d+$"))
async def casino_ban_from_card(call: CallbackQuery) -> None:
    if not _is_admin(call.from_user.id):
        await call.answer("Нет доступа", show_alert=True)
        return
    action, raw_id = call.data.split("_", 1)
    target = int(raw_id)
    if not get_user(target):
        await call.answer("Пользователь не найден", show_alert=True)
        return
    if action == "cban" and _is_admin(target):
        await call.answer("Администратора блокировать нельзя", show_alert=True)
        return
    _set_casino_ban(target, action == "cban")
    await call.answer(f"{target}: {'бан в казино' if action == 'cban' else 'разбан в казино'}", show_alert=True)


# ---------------------------------------------------------------- бонус / дуэли / рефералы
# ключ -> (название, подсказка, тип, минимум, максимум)
_CFG = {
    "bonus_base": ("Бонус за 1-й день серии", "в монетах 🪙", int, 10, 10_000_000),
    "bonus_step": ("Прибавка за каждый день серии", "в монетах 🪙 (0 — без роста)", int, 0, 10_000_000),
    "bonus_max_streak": ("Макс. день серии бонуса", "число дней от 1 до 365", int, 1, 365),
    "duel_fee_percent": ("Комиссия бота в дуэлях", "в процентах от 0 до 50", float, 0, 50),
    "referral_tasks_required": ("Заданий до засчёта реферала", "целое число от 1 до 100", int, 1, 100),
    "withdraw_fee_percent": ("Комиссия на вывод", "в процентах от 0 до 50, например 10 или 2.5; 0 — без комиссии. Вывод 15 ⭐ при 10% спишет 16.5 ⭐", float, 0, 50),
}
_DEFAULTS = {"bonus_base": 1000, "bonus_step": 200, "bonus_max_streak": 7, "duel_fee_percent": 0, "referral_tasks_required": 5, "withdraw_fee_percent": 0}


def _cfg_value(key: str):
    value = get_settings().get(key)
    return _DEFAULTS[key] if value is None else value


def _engage_text() -> str:
    s = get_settings()
    lines = ["🎁 <b>Бонус, дуэли, рефералы, вывод</b>\n"]
    for key, (title, _hint, _t, _mn, _mx) in _CFG.items():
        value = _cfg_value(key)
        shown = f"{format_coins(value)} 🪙" if key in ("bonus_base", "bonus_step") else (f"{value:g}%" if key in ("duel_fee_percent", "withdraw_fee_percent") else f"{value}")
        lines.append(f"• {title}: <b>{shown}</b>")
    lines.append(f"• Оплата за реферала: <b>{format_stars(s.get('referral_reward', 1))} ⭐</b> (меняется отдельной кнопкой)")
    lines.append("\nВыбери, что изменить:")
    return "\n".join(lines)


def _engage_markup() -> InlineKeyboardMarkup:
    rows = [[InlineKeyboardButton(text=f"✏️ {title}", callback_data=f"admin_cfg:{key}")] for key, (title, *_rest) in _CFG.items()]
    rows.append([InlineKeyboardButton(text="↩️ В админ-панель", callback_data="admin_back")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


@router.callback_query(F.data == "admin_engage_settings")
async def open_engage(call: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(call.from_user.id):
        await call.answer("Нет доступа", show_alert=True)
        return
    await state.clear()
    await call.message.edit_text(_engage_text(), reply_markup=_engage_markup(), parse_mode="HTML")
    await call.answer()


@router.callback_query(F.data.startswith("admin_cfg:"))
async def prompt_cfg(call: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(call.from_user.id):
        await call.answer("Нет доступа", show_alert=True)
        return
    key = call.data.split(":", 1)[1]
    if key not in _CFG:
        await call.answer()
        return
    title, hint, *_ = _CFG[key]
    await state.set_state(AdminSettings.generic)
    await state.update_data(cfg_key=key)
    await call.message.answer(f"{title}\nСейчас: {_cfg_value(key)}\nВведи новое значение ({hint}):", reply_markup=cancel_input_markup())
    await call.answer()


@router.message(AdminSettings.generic, F.text)
async def save_cfg(message: Message, state: FSMContext) -> None:
    if not _is_admin(message.from_user.id):
        await state.clear()
        return
    data = await state.get_data()
    key = data.get("cfg_key")
    if key not in _CFG:
        await state.clear()
        return
    title, hint, kind, lo, hi = _CFG[key]
    try:
        value = kind((message.text or "").strip().replace(",", "."))
        if not lo <= value <= hi:
            raise ValueError
    except ValueError:
        await message.reply(f"Некорректное значение. Нужно: {hint}.", reply_markup=cancel_input_markup())
        return
    update_settings(**{key: value})
    await state.clear()
    await message.reply(f"✅ {title}: {value:g}" if isinstance(value, float) else f"✅ {title}: {value}", reply_markup=_engage_markup())


# ---------------------------------------------------------------- награда за конкретное задание
@router.callback_query(F.data.regexp(r"^admin_task_reward_\d+$"))
async def prompt_task_reward(call: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(call.from_user.id):
        await call.answer("Нет доступа", show_alert=True)
        return
    task_id = int(call.data.rsplit("_", 1)[1])
    task = get_task(task_id)
    if not task:
        await call.answer("Задание не найдено", show_alert=True)
        return
    await state.set_state(AdminSettings.one_task_reward)
    await state.update_data(task_id=task_id)
    await call.message.answer(
        f"Задание: {escape(str(task['link']))}\nСейчас награда: {task['reward']} ⭐\nВведи новую награду в звёздах (до 3 знаков, например 0.5):",
        reply_markup=cancel_input_markup(),
        parse_mode="HTML",
        disable_web_page_preview=True,
    )
    await call.answer()


@router.message(AdminSettings.one_task_reward, F.text)
async def save_task_reward(message: Message, state: FSMContext) -> None:
    if not _is_admin(message.from_user.id):
        await state.clear()
        return
    try:
        value = float(parse_stars(message.text or ""))
        if value <= 0:
            raise ValueError
    except ValueError:
        await message.reply("Введи положительное число звёзд, например 0.5.", reply_markup=cancel_input_markup())
        return
    data = await state.get_data()
    ok = update_task_reward(int(data.get("task_id", 0)), value)
    await state.clear()
    await message.reply(
        f"✅ Награда за задание теперь {format_stars(value)} ⭐" if ok else "Задание уже удалено.",
        reply_markup=admin_back_markup(),
    )
