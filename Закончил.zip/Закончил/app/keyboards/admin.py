"""Инлайн-клавиатуры админ-панели."""
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton


def admin_panel_markup() -> InlineKeyboardMarkup:
    rows = [
        [
            InlineKeyboardButton(text="📊 Статистика", callback_data="admin_stats"),
            InlineKeyboardButton(text="📈 Статистика заданий", callback_data="admin_task_stats_1"),
        ],
        [InlineKeyboardButton(text="👥 Пользователи", callback_data="admin_users_1")],
        [InlineKeyboardButton(text="🔎 Найти пользователя", callback_data="admin_search_user")],
        [InlineKeyboardButton(text="⭐ Выдать звёзды", callback_data="admin_issue_stars")],
        [InlineKeyboardButton(text="🎰 Настройки казино", callback_data="admin_casino_settings")],
        [
            InlineKeyboardButton(text="⛔ Бан в казино", callback_data="admin_casino_ban"),
            InlineKeyboardButton(text="✅ Разбан в казино", callback_data="admin_casino_unban"),
        ],
        [InlineKeyboardButton(text="🎁 Бонус, дуэли, рефералы, вывод", callback_data="admin_engage_settings")],
        [InlineKeyboardButton(text="📢 Рассылка", callback_data="admin_broadcast")],
        [
            InlineKeyboardButton(text="➕ Добавить задание", callback_data="admin_add"),
            InlineKeyboardButton(text="➖ Удалить задание", callback_data="admin_delete"),
        ],
        [
            InlineKeyboardButton(text="➕ Добавить канал", callback_data="admin_add_channel"),
            InlineKeyboardButton(text="➖ Удалить канал", callback_data="admin_delete_channel"),
        ],
        [InlineKeyboardButton(text="➕ Добавить подписку по сроку", callback_data="admin_add_required_sub")],
        [
            InlineKeyboardButton(text="➕ Создать промокод", callback_data="admin_add_promo"),
            InlineKeyboardButton(text="➖ Удалить промокод", callback_data="admin_delete_promo"),
        ],
        [
            InlineKeyboardButton(text="⚙️ Мин. рефералов", callback_data="admin_set_min_refs"),
            InlineKeyboardButton(text="⚙️ Мин. заданий", callback_data="admin_set_min_tasks"),
        ],
        [InlineKeyboardButton(text="💰 Оплата за реферала", callback_data="admin_set_ref_reward")],
        [InlineKeyboardButton(text="⭐ Награда за задание («Заработать»)", callback_data="admin_set_task_reward")],
        [InlineKeyboardButton(text="🔄 Вкл/Выкл PiarFlow", callback_data="admin_toggle_piarflow")],
        [
            InlineKeyboardButton(text="❄️ Заморозить", callback_data="admin_freeze"),
            InlineKeyboardButton(text="🔥 Разморозить", callback_data="admin_unfreeze"),
        ],
        [InlineKeyboardButton(text="🔄 Обнулить аккаунт", callback_data="admin_reset")],
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)


def admin_user_search_markup(target_user_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Заморозить аккаунт", callback_data=f"freeze_{target_user_id}")],
        [InlineKeyboardButton(text="Разморозить аккаунт", callback_data=f"unfreeze_{target_user_id}")],
        [InlineKeyboardButton(text="Обнулить аккаунт", callback_data=f"reset_{target_user_id}")],
        [
            InlineKeyboardButton(text="⛔ Бан в казино", callback_data=f"cban_{target_user_id}"),
            InlineKeyboardButton(text="✅ Разбан", callback_data=f"cunban_{target_user_id}"),
        ],
        [InlineKeyboardButton(text="Назад", callback_data="admin_back")],
    ])


def admin_back_markup() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="Назад", callback_data="admin_back")]]
    )


def admin_task_stats_markup(page: int, total: int, task_doc_id: int) -> InlineKeyboardMarkup:
    nav_row = [
        InlineKeyboardButton(text="⬅️", callback_data=f"admin_task_stats_{page - 1}" if page > 1 else "none"),
        InlineKeyboardButton(text=f"{page}/{total}", callback_data="none"),
        InlineKeyboardButton(text="➡️", callback_data=f"admin_task_stats_{page + 1}" if page < total else "none"),
    ]
    return InlineKeyboardMarkup(
        inline_keyboard=[
            nav_row,
            [InlineKeyboardButton(text="✏️ Изменить награду", callback_data=f"admin_task_reward_{task_doc_id}")],
            [InlineKeyboardButton(text="Удалить задание", callback_data=f"admin_delete_task_{task_doc_id}")],
            [InlineKeyboardButton(text="Назад", callback_data="admin_back")],
        ]
    )


def admin_user_card_markup(page: int, total: int, target_user_id: int) -> InlineKeyboardMarkup:
    nav_row = [
        InlineKeyboardButton(text="⬅️", callback_data=f"admin_users_{page - 1}" if page > 1 else "none"),
        InlineKeyboardButton(text=f"{page}/{total}", callback_data="none"),
        InlineKeyboardButton(text="➡️", callback_data=f"admin_users_{page + 1}" if page < total else "none"),
    ]
    return InlineKeyboardMarkup(
        inline_keyboard=[
            nav_row,
            [InlineKeyboardButton(text="Заморозить аккаунт", callback_data=f"freeze_{target_user_id}")],
            [InlineKeyboardButton(text="Разморозить аккаунт", callback_data=f"unfreeze_{target_user_id}")],
            [InlineKeyboardButton(text="Обнулить аккаунт", callback_data=f"reset_{target_user_id}")],
            [
                InlineKeyboardButton(text="⛔ Бан в казино", callback_data=f"cban_{target_user_id}"),
                InlineKeyboardButton(text="✅ Разбан", callback_data=f"cunban_{target_user_id}"),
            ],
            [InlineKeyboardButton(text="Назад", callback_data="admin_back")],
        ]
    )

