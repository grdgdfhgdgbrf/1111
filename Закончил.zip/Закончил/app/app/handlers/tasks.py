"""Локальные (не PiarFlow) спонсорские задания: список и проверка выполнения."""
import logging

from aiogram import Router, Bot, F
from aiogram.types import CallbackQuery

from app.handlers.common import check_subscription, show_subscription_message
from app.keyboards.user import task_page_markup, no_tasks_markup, back_markup
from app.services.tasks import get_available_tasks, get_task
from app.services.users import get_user, update_user, add_referral, add_stars
from app.services.settings import get_settings
from app.utils.currency import floor_stars, format_stars

logger = logging.getLogger(__name__)
router = Router(name="tasks")

NO_TASKS_TEXT = "❗ Заданий пока нету.\n\n📅 Проверяй эту вкладку каждый час на наличие новых заданий!"


@router.callback_query(F.data.regexp(r"^tasks_\d+$"))
async def tasks_page_callback(call: CallbackQuery, bot: Bot) -> None:
    user_id = call.from_user.id
    if not await check_subscription(bot, user_id):
        await show_subscription_message(bot, call.message.chat.id)
        return

    user = get_user(user_id)
    if not user:
        await call.answer("Пользователь не найден. Используйте /start.")
        return

    page = int(call.data.split("_")[1])
    completed_tasks = user.get("completed_tasks", [])
    available_tasks = get_available_tasks(completed_tasks)

    if not available_tasks:
        await bot.edit_message_text(
            chat_id=call.message.chat.id,
            message_id=call.message.message_id,
            text=NO_TASKS_TEXT,
            reply_markup=no_tasks_markup(),
        )
        return

    task = available_tasks[page - 1]
    task_text = f"<b>Новое задание</b>\n\nСсылка: {task['link']}\nНаграда: {task['reward']} ⭐️"
    await bot.edit_message_text(
        chat_id=call.message.chat.id,
        message_id=call.message.message_id,
        text=task_text,
        reply_markup=task_page_markup(page, len(available_tasks), task["id"]),
        parse_mode="HTML",
    )


@router.callback_query(F.data.regexp(r"^check_\d+$"))
async def check_task_callback(call: CallbackQuery, bot: Bot) -> None:
    user_id = call.from_user.id
    if not await check_subscription(bot, user_id):
        await show_subscription_message(bot, call.message.chat.id)
        return

    user = get_user(user_id)
    if not user:
        await call.answer("Пользователь не найден. Используйте /start.")
        return

    task_id = int(call.data.split("_")[1])
    task = get_task(task_id)
    completed_tasks = user.get("completed_tasks", [])

    if task_id in completed_tasks:
        await bot.edit_message_text(
            chat_id=call.message.chat.id,
            message_id=call.message.message_id,
            text="Ты уже выполнил это задание!",
            reply_markup=back_markup("cancel"),
        )
        return

    if user.get("frozen", False):
        await bot.edit_message_text(
            chat_id=call.message.chat.id,
            message_id=call.message.message_id,
            text="Твой аккаунт заморожен, выполнение заданий невозможно!",
            reply_markup=back_markup("cancel"),
        )
        return

    if not task:
        await call.answer("Задание не найдено.")
        return

    chat_member = await bot.get_chat_member(task["channel_id"], user_id)
    if chat_member.status in ("member", "administrator", "creator"):
        add_stars(user_id, task["reward"])
        completed_tasks = completed_tasks + [task_id]
        update_user(user_id, completed_tasks=completed_tasks)
        new_balance = get_user(user_id)["balance"]

        # A referral is counted and rewarded only after five distinct task completions.
        if len(completed_tasks) >= 5 and user.get("referrer_id") and str(user.get("referrer_id")) != str(user_id):
            referrer = get_user(int(user["referrer_id"]))
            if referrer and user_id not in referrer.get("referrals", []) and not referrer.get("frozen", False):
                reward = get_settings().get("referral_reward", 1)
                add_referral(int(user["referrer_id"]), user_id, reward)
                await bot.send_message(
                    int(user["referrer_id"]),
                    f"Друг выполнил 5 заданий — реферал засчитан! +{reward:g} ⭐️",
                )
        await bot.send_message(
            chat_id=call.message.chat.id,
            text=(
                f"Задание выполнено!\nТы получил: {task['reward']} звезд ⭐️ (сразу в монеты 🪙)\n"
                f"Новый баланс: {format_stars(new_balance)} звезд ⭐️"
            ),
        )

        available_tasks = get_available_tasks(completed_tasks)
        if available_tasks:
            next_task = available_tasks[0]
            next_task_text = (
                f"<b>Новое задание</b>\n\nСсылка: {next_task['link']}\nНаграда: {next_task['reward']} ⭐️"
            )
            await bot.edit_message_text(
                chat_id=call.message.chat.id,
                message_id=call.message.message_id,
                text=next_task_text,
                reply_markup=task_page_markup(1, len(available_tasks), next_task["id"]),
                parse_mode="HTML",
            )
        else:
            await bot.edit_message_text(
                chat_id=call.message.chat.id,
                message_id=call.message.message_id,
                text=NO_TASKS_TEXT,
                reply_markup=no_tasks_markup(),
            )
    else:
        await bot.edit_message_text(
            chat_id=call.message.chat.id,
            message_id=call.message.message_id,
            text="Ты не подписан на канал!\nПодпишись и попробуй снова.",
            reply_markup=task_page_markup(1, 1, task_id),
        )

