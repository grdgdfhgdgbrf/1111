"""Общие вспомогательные функции, используемые в разных хендлерах."""
import logging

from aiogram import Bot
from aiogram.fsm.context import FSMContext

from app.config import IMAGE_MAIN_MENU, IMAGE_SUBSCRIPTION, IMAGE_PIARFLOW_TASKS
from app.keyboards.user import main_menu_markup, subscription_markup, piarflow_task_card_markup
from app.services.channels import get_all_channels
from app.services.piarflow import get_piarflow_sponsors
from app.services.settings import get_settings
from app.services.users import get_user, update_user, add_stars, add_referral, increment_tasks_done
from app.utils.currency import format_stars
from app.utils.images import send_screen

logger = logging.getLogger(__name__)

_bot_username: str | None = None


async def get_bot_username(bot: Bot) -> str:
    global _bot_username
    if not _bot_username:
        me = await bot.get_me()
        _bot_username = me.username
    return _bot_username


async def check_subscription(bot: Bot, user_id: int) -> bool:
    """Проверяет подписку пользователя на все обязательные каналы."""
    channels = get_all_channels()
    if not channels:
        return True
    for channel in channels:
        try:
            member = await bot.get_chat_member(channel["channel_id"], user_id)
            if member.status not in ("member", "administrator", "creator") and not (
                member.status == "restricted" and getattr(member, "is_member", False)
            ):
                return False
        except Exception as e:
            logger.error(f"Error in check_subscription: {e}")
            return False
    return True


async def show_subscription_message(bot: Bot, chat_id: int) -> None:
    channels = get_all_channels()
    try:
        await send_screen(
            bot,
            chat_id,
            "Перед использованием бота подпишитесь на каналы:",
            image=IMAGE_SUBSCRIPTION,
            reply_markup=subscription_markup(channels),
        )
    except Exception as e:
        logger.error(f"Error in show_subscription_message: {e}")


async def show_main_menu(bot: Bot, chat_id: int) -> None:
    try:
        menu_text = (
            "🏠 <b>Главное меню</b>\n"
            "▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
            "Выбирай действие ниже 👇"
        )
        await send_screen(
            bot,
            chat_id,
            menu_text,
            image=IMAGE_MAIN_MENU,
            reply_markup=main_menu_markup(),
        )
    except Exception as e:
        logger.error(f"Error in show_main_menu: {e}")


async def show_piarflow_tasks(bot: Bot, chat_id: int, user_id: int, state: FSMContext) -> None:
    """Запускает обязательный показ заданий PiarFlow при первом /start (без пропуска)."""
    user = get_user(user_id)
    if not user or user.get("piarflow_completed", False):
        await show_main_menu(bot, chat_id)
        return
    await start_piarflow_flow(bot, chat_id, user_id, state, mode="onboarding")


async def show_earn_tasks(bot: Bot, chat_id: int, user_id: int, state: FSMContext) -> bool:
    """Запускает показ заданий PiarFlow по кнопке «Заработать звёзды» (можно пропускать).

    Возвращает False, если сейчас нет доступных заданий (для тоста в вызывающем коде).
    """
    return await start_piarflow_flow(bot, chat_id, user_id, state, mode="earn")


async def start_piarflow_flow(bot: Bot, chat_id: int, user_id: int, state: FSMContext, mode: str) -> bool:
    """Общая логика запуска очереди заданий PiarFlow.

    mode == "onboarding": обязательные задания, без пропуска, награда себе не начисляется
    (награда достаётся рефереру, если он есть).
    mode == "earn": задания по кнопке меню, можно пропускать, награда начисляется самому пользователю.
    """
    try:
        sponsors = await get_piarflow_sponsors(user_id, chat_id, max_sponsors=8)

        if not sponsors:
            if mode == "onboarding":
                update_user(user_id, piarflow_completed=True)
            await show_main_menu(bot, chat_id)
            return False

        links = [s["link"] for s in sponsors]
        settings = get_settings()
        reward = settings.get("referral_task_reward", 0.1)

        await state.update_data(
            piarflow_queue=links, piarflow_mode=mode, piarflow_reward=reward, piarflow_ref_earned=0.0
        )
        await _send_task_card(bot, chat_id, mode, links[0], reward)
        return True
    except Exception as e:
        logger.error(f"Error in start_piarflow_flow: {e}")
        await show_main_menu(bot, chat_id)
        return False


async def _send_task_card(bot: Bot, chat_id: int, mode: str, link: str, reward: float) -> None:
    if mode == "earn":
        text = (
            "⚡ <b>Получай звёзды за простые задания!</b>\n\n"
            "🟢 Подпишись на канал и нажми «Подтвердить»\n\n"
            f"Вознаграждение: +{reward} ⭐️"
        )
    else:
        text = (
            "⚡ <b>Обязательные задания</b>\n\n"
            "🟢 Подпишись на канал и нажми «Подтвердить», чтобы получить доступ к боту"
        )
    await send_screen(
        bot,
        chat_id,
        text,
        image=IMAGE_PIARFLOW_TASKS,
        reply_markup=piarflow_task_card_markup(link, allow_skip=(mode == "earn")),
    )


async def advance_piarflow_flow(
    bot: Bot, chat_id: int, user_id: int, state: FSMContext, message_id: int, completed: bool
) -> None:
    """Убирает текущее задание из очереди и показывает следующее (старое сообщение удаляется)."""
    data = await state.get_data()
    queue: list[str] = list(data.get("piarflow_queue", []))
    mode: str = data.get("piarflow_mode", "earn")
    reward: float = data.get("piarflow_reward", 0.1)
    ref_earned: float = data.get("piarflow_ref_earned", 0.0)

    if queue:
        queue.pop(0)

    if completed and mode == "earn":
        user = get_user(user_id)
        if user and not user.get("frozen", False):
            add_stars(user_id, reward)
            await register_task_done(bot, user_id)

    if completed and mode == "onboarding":
        ref_earned += reward

    try:
        await bot.delete_message(chat_id, message_id)
    except Exception:
        pass

    if queue:
        await state.update_data(piarflow_queue=queue, piarflow_ref_earned=ref_earned)
        await _send_task_card(bot, chat_id, mode, queue[0], reward)
        return

    await state.update_data(piarflow_queue=[], piarflow_mode=None, piarflow_ref_earned=0.0)

    if mode == "onboarding":
        update_user(user_id, piarflow_completed=True)
    await show_main_menu(bot, chat_id)


async def register_task_done(bot: Bot, user_id: int) -> None:
    """Считает выполненное задание и засчитывает реферала, когда набралось нужное число.

    Вызывается и для локальных заданий, и для заданий «Заработать звёзды» (PiarFlow).
    Обязательные задания при первом входе (onboarding) в счётчик не идут.
    """
    increment_tasks_done(user_id)
    user = get_user(user_id)
    if not user:
        return
    settings = get_settings()
    required = int(settings.get("referral_tasks_required", 5) or 5)
    if user.get("tasks_done", 0) < required or not user.get("referrer_id"):
        return
    try:
        referrer_id = int(user["referrer_id"])
    except (TypeError, ValueError):
        return
    if referrer_id == user_id:
        return
    referrer = get_user(referrer_id)
    if not referrer or referrer.get("frozen", False) or user_id in referrer.get("referrals", []):
        return
    reward = settings.get("referral_reward", 1)
    if add_referral(referrer_id, user_id, reward) is None:
        return
    try:
        await bot.send_message(
            referrer_id,
            f"✅ Твой друг выполнил {required} заданий — реферал засчитан! +{format_stars(reward)} ⭐",
        )
    except Exception as e:
        logger.warning("Не удалось уведомить реферера %s: %s", referrer_id, e)


def should_show_piarflow(user: dict) -> bool:
    from app.config import PIARFLOW_API_KEY

    settings = get_settings()
    return (
        not user.get("piarflow_completed", False)
        and settings.get("piarflow_enabled", True)
        and bool(PIARFLOW_API_KEY)
    )
