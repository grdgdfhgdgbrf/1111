"""CRUD-операции над таблицей заявок на вывод (SQLite)."""
from datetime import datetime
from typing import Optional

from app.database import get_connection
from app.utils.currency import get_rate, withdrawal_total_coins

STATUS_PENDING = "Ожидание"
STATUS_SENT = "Звезды отправлены"
STATUS_DENIED = "Отказано"


def create_withdrawal(
    user_id: int,
    stars: int,
    username: str,
    method: str = "stars",
    gmp_amount: Optional[int] = None,
    fee_coins: int = 0,
) -> int:
    conn = get_connection()
    cur = conn.execute(
        "INSERT INTO withdrawals (user_id, stars, method, gmp_amount, status, username, timestamp, fee_coins, rate) "
        "VALUES (?, ?, ?, ?, 'Ожидание', ?, ?, ?, ?)",
        (user_id, stars, method, gmp_amount, username, datetime.now().isoformat(), fee_coins, get_rate()),
    )
    conn.commit()
    return cur.lastrowid


def create_withdrawal_charged(user_id: int, stars: int, fee_coins: int, username: str) -> Optional[int]:
    """Одной транзакцией списывает stars + комиссию с кошелька и создаёт заявку.

    Возвращает id заявки или None, если монет не хватило (тогда ничего не списано).
    """
    rate = get_rate()
    total_coins = stars * rate + fee_coins
    conn = get_connection()
    try:
        conn.execute("BEGIN IMMEDIATE")
        cur = conn.execute(
            "UPDATE users SET casino_coins = casino_coins - ? WHERE user_id = ? AND casino_coins >= ?",
            (total_coins, user_id, total_coins),
        )
        if cur.rowcount != 1:
            conn.rollback()
            return None
        cur = conn.execute(
            "INSERT INTO withdrawals (user_id, stars, method, gmp_amount, status, username, timestamp, fee_coins, rate) "
            "VALUES (?, ?, 'stars', NULL, 'Ожидание', ?, ?, ?, ?)",
            (user_id, stars, username, datetime.now().isoformat(), fee_coins, rate),
        )
        conn.commit()
        return cur.lastrowid
    except Exception:
        conn.rollback()
        raise


def resolve_withdrawal(withdrawal_id: int, new_status: str) -> Optional[dict]:
    """Атомарно закрывает заявку, которая ещё в ожидании.

    При отказе в той же транзакции возвращает игроку всё списанное (сумма + комиссия).
    Возвращает заявку или None, если она не найдена / уже обработана
    (защита от повторного нажатия кнопки и двойного возврата).
    """
    conn = get_connection()
    try:
        conn.execute("BEGIN IMMEDIATE")
        cur = conn.execute(
            "UPDATE withdrawals SET status = ? WHERE id = ? AND status = 'Ожидание'",
            (new_status, withdrawal_id),
        )
        if cur.rowcount != 1:
            conn.rollback()
            return None
        row = conn.execute("SELECT * FROM withdrawals WHERE id = ?", (withdrawal_id,)).fetchone()
        if new_status == STATUS_DENIED:
            refund = withdrawal_total_coins(row["stars"], row["fee_coins"], row["rate"])
            conn.execute(
                "UPDATE users SET casino_coins = casino_coins + ? WHERE user_id = ?",
                (refund, row["user_id"]),
            )
        conn.commit()
        return dict(row)
    except Exception:
        conn.rollback()
        raise


def get_withdrawal(withdrawal_id: int) -> Optional[dict]:
    conn = get_connection()
    row = conn.execute("SELECT * FROM withdrawals WHERE id = ?", (withdrawal_id,)).fetchone()
    return dict(row) if row else None


def update_withdrawal(withdrawal_id: int, **fields) -> None:
    if not fields:
        return
    conn = get_connection()
    set_parts = [f"{k} = ?" for k in fields]
    values = list(fields.values()) + [withdrawal_id]
    conn.execute(f"UPDATE withdrawals SET {', '.join(set_parts)} WHERE id = ?", values)
    conn.commit()


def get_all_withdrawals() -> list[dict]:
    conn = get_connection()
    rows = conn.execute("SELECT * FROM withdrawals ORDER BY id").fetchall()
    return [dict(r) for r in rows]


def get_user_withdrawals(user_id: int) -> list[dict]:
    conn = get_connection()
    rows = conn.execute("SELECT * FROM withdrawals WHERE user_id = ?", (user_id,)).fetchall()
    return [dict(r) for r in rows]
