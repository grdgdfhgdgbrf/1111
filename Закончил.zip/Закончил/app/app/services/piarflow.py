"""Асинхронный клиент для интеграции со спонсорской сетью PiarFlow."""
import logging

import aiohttp

from app.config import PIARFLOW_API_KEY

logger = logging.getLogger(__name__)

PIARFLOW_API_URL = "https://piarflow.com/v1"
_TIMEOUT = aiohttp.ClientTimeout(total=15)


async def get_piarflow_sponsors(user_id: int, chat_id: int, max_sponsors: int = 8) -> list[dict]:
    """Получает список спонсорских заданий от PiarFlow API."""
    if not PIARFLOW_API_KEY:
        return []

    headers = {
        "Authorization": f"Bearer {PIARFLOW_API_KEY}",
        "Content-Type": "application/json",
    }
    payload = {"user_id": user_id, "chat_id": chat_id, "max_sponsors": max_sponsors}

    try:
        async with aiohttp.ClientSession(timeout=_TIMEOUT) as session:
            async with session.post(
                f"{PIARFLOW_API_URL}/sponsors", headers=headers, json=payload
            ) as response:
                text = await response.text()
                if not text:
                    return []
                response.raise_for_status()
                data = await response.json()
                return data.get("sponsors", [])
    except Exception as e:
        logger.error(f"Error getting sponsors from PiarFlow: {e}")
        return []


async def check_piarflow_subscriptions(user_id: int, links: list[str]) -> bool:
    """Проверяет выполнение заданий через PiarFlow API."""
    if not links:
        return True
    if not PIARFLOW_API_KEY:
        return False

    headers = {
        "Authorization": f"Bearer {PIARFLOW_API_KEY}",
        "Content-Type": "application/json",
    }
    payload = {"user_id": user_id, "links": links}

    try:
        async with aiohttp.ClientSession(timeout=_TIMEOUT) as session:
            async with session.post(
                f"{PIARFLOW_API_URL}/sponsors/check", headers=headers, json=payload
            ) as response:
                text = await response.text()
                if not text:
                    return False
                response.raise_for_status()
                data = await response.json()
                sponsors = data.get("sponsors", [])
                return all(sponsor.get("status") == "subscribed" for sponsor in sponsors)
    except Exception as e:
        logger.error(f"Error checking sponsors from PiarFlow: {e}")
        return False
