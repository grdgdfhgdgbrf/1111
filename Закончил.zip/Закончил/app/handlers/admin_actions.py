"""FSM-флоу админ-действий: каналы, задания, промокоды, настройки, заморозка/сброс."""
import logging
import re
from datetime import datetime, timedelta, timezone

from aiogram import Router, Bot, F
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from app.config import ADMIN_IDS
from app.keyboards.admin import admin_panel_markup, admin_back_markup
from app.keyboards.user import cancel_input_markup
from app.services.channels import get_all_channels, add_channel, delete_channel_by_index
from app.services.promo import get_all_promo_codes, create_promo, delete_promo_by_index
from app.services.settings import get_settings, update_settings
from app.services.tasks import get_all_tasks, add_task, delete_task
from app.services.users import get_user, get_user_by_username, update_user, add_stars
from app.utils.currency import floor_stars, format_coins, format_stars, parse_stars
from app.states import (
    AdminAddChannel,
    AdminAddRequiredSub,
    AdminDeleteChannel,
    AdminAddTask,
    AdminDeleteTask,
    AdminSettings,
    AdminPromo,
    AdminDeletePromo,
    AdminUserAction,
)

logger = logging.getLogger(__name__)
router = Router(name="admin_actions")

_DURATION_RE = re.compile(r"^\s*(\d+)\s*([a-zа-яё]*)\s*$", re.IGNORECASE)


def _parse_subscription_duration(raw: str) -> timedelta | None:
    match = re.fullmatch(r"\s*(\d+)\s*([a-z\u0430-\u044f\u0451]*)\s*", raw.lower().replace("\u0451", "\u0435"), re.IGNORECASE)
    if not match:
        return None
    amount = int(match.group(1))
    unit = match.group(2)
    if not unit or unit in {"\u0434", "\u0434\u0435\u043d\u044c", "\u0434\u043d\u044f", "\u0434\u043d\u0435\u0439", "\u0434\u043d\u0438", "day", "days", "d"}:
        duration = timedelta(days=amount)
    elif unit in {"\u043c", "\u043c\u0438\u043d", "\u043c\u0438\u043d\u0443\u0442\u0430", "\u043c\u0438\u043d\u0443\u0442\u0443", "\u043c\u0438\u043d\u0443\u0442\u044b", "\u043c\u0438\u043d\u0443\u0442", "minute", "minutes", "min", "m"}:
        duration = timedelta(minutes=amount)
    elif unit in {"\u0447", "\u0447\u0430\u0441", "\u0447\u0430\u0441\u0430", "\u0447\u0430\u0441\u043e\u0432", "hour", "hours", "h"}:
        duration = timedelta(hours=amount)
    elif unit in {"\u043c\u0435\u0441", "\u043c\u0435\u0441\u044f\u0446", "\u043c\u0435\u0441\u044f\u0446\u0430", "\u043c\u0435\u0441\u044f\u0446\u0435\u0432", "month", "months", "mo"}:
        if amount > 30:
            return None
        duration = timedelta(days=30 * amount)
    else:
        return None
    if duration < timedelta(minutes=1) or duration > timedelta(days=900):
        return None
    return duration

def _is_admin(user_id: int) -> bool:
    return user_id in ADMIN_IDS


async def _invalid_value(message: Message) -> None:
    await message.reply("Ошибка! Введи корректное значение.", reply_markup=cancel_input_markup())



@router.callback_query(F.data == "admin_add")
async def start_add_task(call: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(call.from_user.id):
        return
    await state.set_state(AdminAddTask.channel_id)
    await call.message.answer(
        "Введите ID канала (например, @ChannelName или -100123456789):",
        reply_markup=cancel_input_markup(),
    )


@router.callback_query(F.data == "admin_delete")
async def start_delete_task(call: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(call.from_user.id):
        return
    all_tasks = get_all_tasks()
    if not all_tasks:
        await call.message.answer("Заданий нет!")
        return
    tasks_list = "\n".join(f"{i + 1}. {t['link']} - {t['reward']} звезд ⭐️" for i, t in enumerate(all_tasks))
    await state.set_state(AdminDeleteTask.number)
    await call.message.answer(
        f"Список заданий:\n{tasks_list}\n\nВведи номер задания для удаления:",
        reply_markup=cancel_input_markup(),
    )


@router.callback_query(F.data == "admin_add_channel")
async def start_add_channel(call: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(call.from_user.id):
        return
    await state.set_state(AdminAddChannel.channel_id)
    await call.message.answer(
        "Введите ID канала (например, @ChannelName или -100123456789):",
        reply_markup=cancel_input_markup(),
    )


@router.callback_query(F.data == "admin_add_required_sub")
async def start_add_required_subscription(call: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(call.from_user.id):
        await call.answer("Нет доступа", show_alert=True)
        return
    await state.set_state(AdminAddRequiredSub.channel)
    await call.message.answer(
        "Отправь публичный username канала, например @my_channel. Бот должен быть администратором этого канала.",
        reply_markup=cancel_input_markup(),
    )
    await call.answer()


@router.message(AdminAddRequiredSub.channel, F.text)
async def required_subscription_channel_input(message: Message, state: FSMContext) -> None:
    if not _is_admin(message.from_user.id):
        await state.clear()
        return
    username = message.text.strip()
    if not username.startswith("@"):
        username = "@" + username
    if not re.fullmatch(r"@[A-Za-z0-9_]{5,32}", username):
        await message.reply("Нужен публичный username вида @my_channel.")
        return
    try:
        chat = await message.bot.get_chat(username)
        me = await message.bot.get_me()
        bot_member = await message.bot.get_chat_member(chat.id, me.id)
    except Exception:
        await message.reply("Не нашёл канал. Проверь username и добавь бота администратором.")
        return
    if bot_member.status not in {"administrator", "creator"}:
        await message.reply("Сначала добавь бота администратором в канал, затем отправь username ещё раз.")
        return
    if any(str(item["channel_id"]) == str(chat.id) for item in get_all_channels()):
        await message.reply("Этот канал уже есть в обязательных подписках.")
        return
    await state.update_data(channel_id=str(chat.id), link=f"https://t.me/{username[1:]}")
    await state.set_state(AdminAddRequiredSub.duration)
    await message.reply(
        "На сколько оставить обязательную подписку? Введи, например: 1 минута, 5 дней или 30 месяцев. "
        "Можно отправить только число — оно считается днями. Максимум 30 месяцев.",
        reply_markup=cancel_input_markup(),
    )


@router.message(AdminAddRequiredSub.duration, F.text)
async def required_subscription_duration_input(message: Message, state: FSMContext) -> None:
    if not _is_admin(message.from_user.id):
        await state.clear()
        return
    duration = _parse_subscription_duration(message.text)
    if duration is None:
        await message.reply("Срок должен быть от 1 минуты до 30 месяцев. Примеры: 1 минута, 5 дней, 30 месяцев.")
        return
    data = await state.get_data()
    expires_at = (datetime.now(timezone.utc) + duration).isoformat()
    add_channel(data["channel_id"], data["link"], expires_at=expires_at)
    await state.clear()
    await message.reply(
        f"Обязательная подписка на {data['link']} добавлена до {expires_at[:16].replace('T', ' ')} UTC.",
        reply_markup=admin_panel_markup(),
    )


@router.callback_query(F.data == "admin_delete_channel")
async def start_delete_channel(call: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(call.from_user.id):
        return
    all_channels = get_all_channels()
    if not all_channels:
        await call.message.answer("Каналов нет!")
        return
    channels_list = "\n".join(f"{i + 1}. {c['link']}" for i, c in enumerate(all_channels))
    await state.set_state(AdminDeleteChannel.number)
    await call.message.answer(
        f"Список каналов:\n{channels_list}\n\nВведи номер канала для удаления:",
        reply_markup=cancel_input_markup(),
    )


@router.callback_query(F.data == "admin_set_min_refs")
async def start_set_min_refs(call: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(call.from_user.id):
        return
    await state.set_state(AdminSettings.min_referrals)
    await call.message.answer("Введите минимальное количество рефералов:", reply_markup=cancel_input_markup())


@router.callback_query(F.data == "admin_set_min_tasks")
async def start_set_min_tasks(call: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(call.from_user.id):
        return
    await state.set_state(AdminSettings.min_tasks)
    await call.message.answer("Введите минимальное количество заданий:", reply_markup=cancel_input_markup())


@router.callback_query(F.data == "admin_set_ref_reward")
async def start_set_ref_reward(call: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(call.from_user.id):
        return
    await state.set_state(AdminSettings.referral_reward)
    await call.message.answer(
        "Введите оплату за реферала в звёздах. Она начисляется, когда приглашённый выполнит 5 заданий:",
        reply_markup=cancel_input_markup(),
    )


@router.callback_query(F.data == "admin_set_task_reward")
async def start_set_task_reward(call: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(call.from_user.id):
        return
    await state.set_state(AdminSettings.task_reward)
    await call.message.answer(
        "Введите, сколько звёзд платить за каждое задание в разделе «Заработать звёзды» (например, 0.1).\nНаграда за отдельные локальные задания меняется в «Статистика заданий» → «Изменить награду»:",
        reply_markup=cancel_input_markup(),
    )


@router.callback_query(F.data == "admin_toggle_piarflow")
async def toggle_piarflow(call: CallbackQuery, bot: Bot) -> None:
    if not _is_admin(call.from_user.id):
        return
    settings = get_settings()
    new_status = not settings.get("piarflow_enabled", True)
    update_settings(piarflow_enabled=new_status)
    status_text = "включены" if new_status else "выключены"
    await call.answer(f"Задания PiarFlow {status_text}!")
    await bot.edit_message_text(
        f"Задания PiarFlow теперь {status_text}.",
        chat_id=call.message.chat.id,
        message_id=call.message.message_id,
        reply_markup=admin_back_markup(),
    )


@router.callback_query(F.data == "admin_add_promo")
async def start_add_promo(call: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(call.from_user.id):
        return
    await state.set_state(AdminPromo.code)
    await call.message.answer("Введите промокод что нужно будет вводить:", reply_markup=cancel_input_markup())


@router.callback_query(F.data == "admin_delete_promo")
async def start_delete_promo(call: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(call.from_user.id):
        return
    all_promos = get_all_promo_codes()
    if not all_promos:
        await call.message.answer("Промокодов нет!")
        return
    promo_list = "\n".join(
        f"{i + 1}. {p['code']} - {p['reward']} звезд ⭐️ "
        f"(Лимит: {p['limit']}, Использовано: {len(p.get('used_by', []))})"
        for i, p in enumerate(all_promos)
    )
    await state.set_state(AdminDeletePromo.number)
    await call.message.answer(
        f"Список промокодов:\n{promo_list}\n\nВведите номер промокода который хотите удалить:",
        reply_markup=cancel_input_markup(),
    )


@router.callback_query(F.data == "admin_freeze")
async def start_freeze(call: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(call.from_user.id):
        return
    await state.set_state(AdminUserAction.freeze)
    await call.message.answer("Введите ID пользователя которого хотите заморозить:", reply_markup=cancel_input_markup())


@router.callback_query(F.data == "admin_unfreeze")
async def start_unfreeze(call: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(call.from_user.id):
        return
    await state.set_state(AdminUserAction.unfreeze)
    await call.message.answer("Введите ID пользователя которого хотите разморозить:", reply_markup=cancel_input_markup())


@router.callback_query(F.data == "admin_issue_stars")
async def start_issue_stars(call: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(call.from_user.id):
        await call.answer("Нет доступа", show_alert=True)
        return
    await state.set_state(AdminUserAction.star_target)
    await call.message.answer("Введите ID или @username пользователя, которому выдать звёзды:", reply_markup=cancel_input_markup())
    await call.answer()

@router.callback_query(F.data == "admin_reset")
async def start_reset(call: CallbackQuery, state: FSMContext) -> None:
    if not _is_admin(call.from_user.id):
        return
    await state.set_state(AdminUserAction.reset)
    await call.message.answer(
        "Введите ID пользователя которого хотите обнулить аккаунт:", reply_markup=cancel_input_markup()
    )



@router.message(AdminAddChannel.channel_id, F.text)
async def add_channel_id_input(message: Message, state: FSMContext) -> None:
    await state.update_data(channel_id=message.text)
    await state.set_state(AdminAddChannel.link)
    await message.reply("Введите ссылку на канал:", reply_markup=cancel_input_markup())


@router.message(AdminAddChannel.link, F.text)
async def add_channel_link_input(message: Message, state: FSMContext) -> None:
    data = await state.get_data()
    add_channel(data["channel_id"], message.text)
    await message.reply("Канал добавлен в обязательные подписки!", reply_markup=admin_back_markup())
    await state.clear()


@router.message(AdminDeleteChannel.number, F.text)
async def delete_channel_input(message: Message, state: FSMContext) -> None:
    try:
        index = int(message.text) - 1
        if delete_channel_by_index(index):
            await message.reply("Канал удален!", reply_markup=admin_back_markup())
            await state.clear()
        else:
            await message.reply("Ошибка! Нет такого номера канала.")
    except ValueError:
        await _invalid_value(message)


@router.message(AdminAddTask.channel_id, F.text)
async def add_task_channel_input(message: Message, state: FSMContext) -> None:
    await state.update_data(channel_id=message.text)
    await state.set_state(AdminAddTask.link)
    await message.reply("Введите ссылку на канал:", reply_markup=cancel_input_markup())


@router.message(AdminAddTask.link, F.text)
async def add_task_link_input(message: Message, state: FSMContext) -> None:
    await state.update_data(link=message.text)
    await state.set_state(AdminAddTask.reward)
    await message.reply("Сколько звезд давать за задание?", reply_markup=cancel_input_markup())


@router.message(AdminAddTask.reward, F.text)
async def add_task_reward_input(message: Message, state: FSMContext) -> None:
    try:
        reward = int(message.text)
        data = await state.get_data()
        add_task(data["channel_id"], data["link"], reward)
        await message.reply("Задание добавлено!", reply_markup=admin_back_markup())
        await state.clear()
    except ValueError:
        await _invalid_value(message)


@router.message(AdminDeleteTask.number, F.text)
async def delete_task_input(message: Message, state: FSMContext) -> None:
    try:
        index = int(message.text) - 1
        all_tasks = get_all_tasks()
        if 0 <= index < len(all_tasks):
            delete_task(all_tasks[index]["id"])
            await message.reply("Задание удалено!", reply_markup=admin_back_markup())
            await state.clear()
        else:
            await message.reply("Ошибка! Нет такого номера задания.")
    except ValueError:
        await _invalid_value(message)


@router.message(AdminSettings.min_referrals, F.text)
async def set_min_refs_input(message: Message, state: FSMContext) -> None:
    try:
        value = int(message.text)
        if value < 0:
            raise ValueError
        update_settings(min_referrals=value)
        await message.reply(f"Минимальное количество рефералов теперь: {value}", reply_markup=admin_back_markup())
        await state.clear()
    except ValueError:
        await _invalid_value(message)


@router.message(AdminSettings.min_tasks, F.text)
async def set_min_tasks_input(message: Message, state: FSMContext) -> None:
    try:
        value = int(message.text)
        if value < 0:
            raise ValueError
        update_settings(min_tasks=value)
        await message.reply(f"Минимальное количество заданий теперь: {value}", reply_markup=admin_back_markup())
        await state.clear()
    except ValueError:
        await _invalid_value(message)


@router.message(AdminSettings.referral_reward, F.text)
async def set_ref_reward_input(message: Message, state: FSMContext) -> None:
    try:
        value = parse_stars(message.text or "")
        if value <= 0:
            raise ValueError
        update_settings(referral_reward=value)
        await message.reply(
            f"Оплата за реферала установлена: {format_stars(value)} ⭐ (после 5 выполненных заданий).",
            reply_markup=admin_back_markup(),
        )
        await state.clear()
    except ValueError:
        await message.reply(
            "Введите положительную сумму до 3 знаков после запятой, например 1 или 0.5 ⭐.",
            reply_markup=cancel_input_markup(),
        )


@router.message(AdminSettings.task_reward, F.text)
async def set_task_reward_input(message: Message, state: FSMContext) -> None:
    try:
        value = float(message.text)
        if value < 0:
            raise ValueError
        update_settings(referral_task_reward=value)
        await message.reply(f"Награда за задание в «Заработать звёзды» теперь: {value:g} ⭐", reply_markup=admin_back_markup())
        await state.clear()
    except ValueError:
        await _invalid_value(message)


@router.message(AdminPromo.code, F.text)
async def add_promo_code_input(message: Message, state: FSMContext) -> None:
    await state.update_data(code=message.text)
    await state.set_state(AdminPromo.reward)
    await message.reply(
        "Введите сколько будет даваться звезд за активацию промокода:", reply_markup=cancel_input_markup()
    )


@router.message(AdminPromo.reward, F.text)
async def add_promo_reward_input(message: Message, state: FSMContext) -> None:
    try:
        reward = int(message.text)
        await state.update_data(reward=reward)
        await state.set_state(AdminPromo.limit)
        await message.reply(
            "Сколько пользователей могут активировать промокод:", reply_markup=cancel_input_markup()
        )
    except ValueError:
        await _invalid_value(message)


@router.message(AdminPromo.limit, F.text)
async def add_promo_limit_input(message: Message, state: FSMContext) -> None:
    try:
        limit = int(message.text)
        data = await state.get_data()
        create_promo(data["code"], data["reward"], limit)
        await message.reply(f"Промокод {data['code']} создан!", reply_markup=admin_back_markup())
        await state.clear()
    except ValueError:
        await _invalid_value(message)


@router.message(AdminDeletePromo.number, F.text)
async def delete_promo_input(message: Message, state: FSMContext) -> None:
    try:
        index = int(message.text) - 1
        if delete_promo_by_index(index):
            await message.reply("Промокод удален!", reply_markup=admin_back_markup())
            await state.clear()
        else:
            await message.reply("Ошибка! Нет такого номера промокода.")
    except ValueError:
        await _invalid_value(message)


@router.message(AdminUserAction.freeze, F.text)
async def freeze_input(message: Message, state: FSMContext) -> None:
    try:
        target_id = int(message.text)
        if get_user(target_id):
            update_user(target_id, frozen=True)
            await message.reply(f"Пользователь {target_id} заморожен!", reply_markup=admin_back_markup())
            await state.clear()
        else:
            await message.reply("Ошибка! Пользователь не найден.")
    except ValueError:
        await _invalid_value(message)


@router.message(AdminUserAction.unfreeze, F.text)
async def unfreeze_input(message: Message, state: FSMContext) -> None:
    try:
        target_id = int(message.text)
        if get_user(target_id):
            update_user(target_id, frozen=False)
            await message.reply(f"Пользователь {target_id} разморожен!", reply_markup=admin_back_markup())
            await state.clear()
        else:
            await message.reply("Ошибка! Пользователь не найден.")
    except ValueError:
        await _invalid_value(message)


@router.message(AdminUserAction.star_target, F.text)
async def issue_stars_target_input(message: Message, state: FSMContext) -> None:
    if not _is_admin(message.from_user.id):
        await state.clear()
        return
    raw = (message.text or "").strip()
    target = get_user(int(raw)) if raw.isdigit() else get_user_by_username(raw)
    if not target:
        await message.reply("Пользователь не найден. Введите ID или @username; он должен был запустить бота через /start.")
        return
    target_id = target["user_id"]
    await state.update_data(target_user_id=target_id)
    await state.set_state(AdminUserAction.star_amount)
    await message.reply("Введите сумму выдачи в звёздах (до трёх знаков после запятой):", reply_markup=cancel_input_markup())


@router.message(AdminUserAction.star_amount, F.text)
async def issue_stars_amount_input(message: Message, state: FSMContext, bot: Bot) -> None:
    if not _is_admin(message.from_user.id):
        await state.clear()
        return
    try:
        amount = parse_stars(message.text or "")
        if amount <= 0:
            raise ValueError
    except ValueError:
        await message.reply("Введите положительную сумму с точностью до 0.001 ⭐.", reply_markup=cancel_input_markup())
        return
    data = await state.get_data()
    target_id = int(data["target_user_id"])
    user = get_user(target_id)
    if not user:
        await state.clear()
        await message.reply("Пользователь не найден.", reply_markup=admin_panel_markup())
        return
    gained = add_stars(target_id, amount)
    updated = get_user(target_id)
    await state.clear()
    await message.reply(
        f"✅ Выдано {format_stars(amount)} ⭐ ({format_coins(gained)} 🪙) пользователю {target_id}. "
        f"Баланс: {format_coins(updated['casino_coins'])} 🪙 (≈ {format_stars(updated['balance'])} ⭐).",
        reply_markup=admin_panel_markup(),
    )
    try:
        await bot.send_message(
            target_id,
            f"🎁 Администратор начислил тебе {format_coins(gained)} 🪙 ({format_stars(amount)} ⭐). "
            f"Баланс: {format_coins(updated['casino_coins'])} 🪙.",
        )
    except Exception:
        pass

@router.message(AdminUserAction.reset, F.text)
async def reset_input(message: Message, state: FSMContext) -> None:
    try:
        target_id = int(message.text)
        if get_user(target_id):
            update_user(
                target_id,
                balance=0,
                casino_coins=0,
                completed_tasks=[],
                referrals=[],
                used_promo_codes=[],
                frozen=False,
            )
            await message.reply(f"Аккаунт пользователя {target_id} обнулен!", reply_markup=admin_back_markup())
            await state.clear()
        else:
            await message.reply("Ошибка! Пользователь не найден.")
    except ValueError:
        await _invalid_value(message)



