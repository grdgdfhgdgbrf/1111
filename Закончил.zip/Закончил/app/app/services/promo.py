"""CRUD-операции над таблицей промокодов (SQLite)."""
import json
from typing import Optional

from app.database import get_connection


def _row_to_promo(row) -> Optional[dict]:
    if row is None:
        return None
    d = dict(row)
    d["used_by"] = json.loads(d["used_by"])
    return d


def get_all_promo_codes() -> list[dict]:
    conn = get_connection()
    rows = conn.execute("SELECT * FROM promo_codes ORDER BY id").fetchall()
    return [_row_to_promo(r) for r in rows]


def get_promo(code: str) -> Optional[dict]:
    conn = get_connection()
    row = conn.execute("SELECT * FROM promo_codes WHERE code = ?", (code,)).fetchone()
    return _row_to_promo(row)


def create_promo(code: str, reward: float, limit: int) -> int:
    conn = get_connection()
    cur = conn.execute(
        'INSERT INTO promo_codes (code, reward, "limit", used_by) VALUES (?, ?, ?, \'[]\')',
        (code, reward, limit),
    )
    conn.commit()
    return cur.lastrowid


def mark_promo_used(code: str, user_id: int, used_by: list[int]) -> None:
    used_by.append(user_id)
    conn = get_connection()
    conn.execute("UPDATE promo_codes SET used_by = ? WHERE code = ?", (json.dumps(used_by), code))
    conn.commit()


def delete_promo_by_index(index: int) -> bool:
    all_promos = get_all_promo_codes()
    if 0 <= index < len(all_promos):
        conn = get_connection()
        conn.execute("DELETE FROM promo_codes WHERE id = ?", (all_promos[index]["id"],))
        conn.commit()
        return True
    return False
