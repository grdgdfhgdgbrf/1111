"""Инициализация SQLite, схема таблиц и автоматическая миграция из старой TinyDB (JSON)."""
import json
import sqlite3
from pathlib import Path

from app.config import DB_PATH, PROJECT_ROOT
from app.utils.currency import floor_stars

_configured_path = Path(DB_PATH)
if not _configured_path.is_absolute():
    _configured_path = PROJECT_ROOT / _configured_path
if _configured_path.suffix == ".json":
    _SQLITE_PATH = _configured_path.with_suffix(".sqlite3")
elif _configured_path.suffix not in (".sqlite3", ".db", ".sqlite"):
    _SQLITE_PATH = Path(str(_configured_path) + ".sqlite3")
else:
    _SQLITE_PATH = _configured_path

_SQLITE_PATH.parent.mkdir(parents=True, exist_ok=True)

_connection = sqlite3.connect(str(_SQLITE_PATH), check_same_thread=False)
_connection.row_factory = sqlite3.Row
_connection.execute("PRAGMA journal_mode=WAL")
_connection.execute("PRAGMA foreign_keys=ON")


def get_connection() -> sqlite3.Connection:
    return _connection


_SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    user_id INTEGER PRIMARY KEY,
    balance REAL NOT NULL DEFAULT 0,
    first_name TEXT,
    last_name TEXT,
    referrer_id TEXT,
    completed_tasks TEXT NOT NULL DEFAULT '[]',
    registration_date TEXT NOT NULL,
    referrals TEXT NOT NULL DEFAULT '[]',
    username TEXT,
    frozen INTEGER NOT NULL DEFAULT 0,
    casino_banned INTEGER NOT NULL DEFAULT 0,
    casino_coins INTEGER NOT NULL DEFAULT 0,
    used_promo_codes TEXT NOT NULL DEFAULT '[]',
    piarflow_completed INTEGER NOT NULL DEFAULT 0,
    piarflow_links TEXT NOT NULL DEFAULT '[]'
);

CREATE TABLE IF NOT EXISTS tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    channel_id TEXT NOT NULL,
    link TEXT NOT NULL,
    reward REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS withdrawals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    stars INTEGER NOT NULL,
    method TEXT NOT NULL DEFAULT 'stars',
    gmp_amount INTEGER,
    status TEXT NOT NULL DEFAULT 'Ожидание',
    username TEXT,
    timestamp TEXT NOT NULL,
    admin_msg_id INTEGER
);

CREATE TABLE IF NOT EXISTS settings (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    min_referrals INTEGER NOT NULL DEFAULT 5,
    min_tasks INTEGER NOT NULL DEFAULT 3,
    referral_reward REAL NOT NULL DEFAULT 2,
    piarflow_enabled INTEGER NOT NULL DEFAULT 1,
    referral_task_reward REAL NOT NULL DEFAULT 0.1
);

CREATE TABLE IF NOT EXISTS channels (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    channel_id TEXT NOT NULL,
    link TEXT NOT NULL,
    expires_at TEXT
);

CREATE TABLE IF NOT EXISTS promo_codes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT NOT NULL UNIQUE,
    reward REAL NOT NULL,
    "limit" INTEGER NOT NULL,
    used_by TEXT NOT NULL DEFAULT '[]'
);

CREATE INDEX IF NOT EXISTS idx_withdrawals_user_id ON withdrawals(user_id);CREATE TABLE IF NOT EXISTS casino_stats (user_id INTEGER PRIMARY KEY, games_played INTEGER NOT NULL DEFAULT 0, wins INTEGER NOT NULL DEFAULT 0, total_won REAL NOT NULL DEFAULT 0, total_lost REAL NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS casino_settings (id INTEGER PRIMARY KEY CHECK(id=1), loss_chance REAL NOT NULL DEFAULT 25, min_bet INTEGER NOT NULL DEFAULT 1000, max_bet INTEGER NOT NULL DEFAULT 50000000);
INSERT OR IGNORE INTO casino_settings (id, loss_chance, min_bet, max_bet) VALUES (1, 25, 1000, 50000000);
CREATE TABLE IF NOT EXISTS star_deposits (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, charge_id TEXT NOT NULL UNIQUE, stars INTEGER NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS star_transfers (id INTEGER PRIMARY KEY AUTOINCREMENT, from_id INTEGER NOT NULL, to_id INTEGER NOT NULL, stars INTEGER NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS casino_withdrawals (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, stars INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'Ожидание', created_at TEXT NOT NULL, admin_msg_id INTEGER);
CREATE INDEX IF NOT EXISTS idx_users_referrer_id ON users(referrer_id);
CREATE TABLE IF NOT EXISTS currency_exchanges (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, direction TEXT NOT NULL, stars REAL NOT NULL, coins INTEGER NOT NULL, created_at TEXT NOT NULL);
"""


def _migrate_from_tinydb_json(json_path: Path, conn: sqlite3.Connection) -> int:
    try:
        raw = json.loads(json_path.read_text(encoding="utf-8"))
    except Exception:
        return 0
    if not isinstance(raw, dict):
        return 0

    migrated = 0

    for old_id, u in sorted(raw.get("users", {}).items(), key=lambda kv: int(kv[0])):
        conn.execute(
            "INSERT OR IGNORE INTO users (user_id, balance, first_name, last_name, referrer_id, "
            "completed_tasks, registration_date, referrals, username, frozen, used_promo_codes, "
            "piarflow_completed, piarflow_links) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (
                u.get("user_id"),
                u.get("balance", 0),
                u.get("first_name"),
                u.get("last_name", ""),
                u.get("referrer_id"),
                json.dumps(u.get("completed_tasks", [])),
                u.get("registration_date"),
                json.dumps(u.get("referrals", [])),
                u.get("username"),
                int(bool(u.get("frozen", False))),
                json.dumps(u.get("used_promo_codes", [])),
                int(bool(u.get("piarflow_completed", False))),
                json.dumps(u.get("piarflow_links", [])),
            ),
        )
        migrated += 1

    for old_id, t in sorted(raw.get("tasks", {}).items(), key=lambda kv: int(kv[0])):
        conn.execute(
            "INSERT OR IGNORE INTO tasks (id, channel_id, link, reward) VALUES (?,?,?,?)",
            (int(old_id), t.get("channel_id"), t.get("link"), t.get("reward")),
        )

    for old_id, w in sorted(raw.get("withdrawals", {}).items(), key=lambda kv: int(kv[0])):
        conn.execute(
            "INSERT OR IGNORE INTO withdrawals (id, user_id, stars, method, gmp_amount, status, "
            "username, timestamp, admin_msg_id) VALUES (?,?,?,?,?,?,?,?,?)",
            (
                w.get("id", int(old_id)),
                w.get("user_id"),
                w.get("stars"),
                w.get("method", "stars"),
                w.get("gmp_amount"),
                w.get("status", "Ожидание"),
                w.get("username"),
                w.get("timestamp"),
                w.get("admin_msg_id"),
            ),
        )

    for old_id, c in sorted(raw.get("channels", {}).items(), key=lambda kv: int(kv[0])):
        conn.execute(
            "INSERT OR IGNORE INTO channels (id, channel_id, link) VALUES (?,?,?)",
            (int(old_id), c.get("channel_id"), c.get("link")),
        )

    for old_id, p in sorted(raw.get("promo_codes", {}).items(), key=lambda kv: int(kv[0])):
        conn.execute(
            'INSERT OR IGNORE INTO promo_codes (id, code, reward, "limit", used_by) VALUES (?,?,?,?,?)',
            (int(old_id), p.get("code"), p.get("reward"), p.get("limit"), json.dumps(p.get("used_by", []))),
        )

    settings_rows = raw.get("settings", {})
    if settings_rows:
        s = list(settings_rows.values())[0]
        conn.execute(
            "INSERT OR REPLACE INTO settings (id, min_referrals, min_tasks, referral_reward, "
            "piarflow_enabled, referral_task_reward) VALUES (1, ?, ?, ?, ?, ?)",
            (
                s.get("min_referrals", 5),
                s.get("min_tasks", 3),
                s.get("referral_reward", 2),
                int(bool(s.get("piarflow_enabled", True))),
                s.get("referral_task_reward", 0.1),
            ),
        )

    conn.commit()
    return migrated


def init_settings() -> None:
    conn = get_connection()
    had_casino_settings = conn.execute(
        "SELECT 1 FROM sqlite_master WHERE type=? AND name=?", ("table", "casino_settings")
    ).fetchone() is not None
    conn.executescript(_SCHEMA)
    conn.execute("CREATE TABLE IF NOT EXISTS app_migrations (name TEXT PRIMARY KEY)")
    if not conn.execute("SELECT 1 FROM app_migrations WHERE name='casino_fractional_min_bet'").fetchone():
        conn.execute("UPDATE casino_settings SET min_bet=0.2 WHERE min_bet=1")
        conn.execute("INSERT INTO app_migrations(name) VALUES('casino_fractional_min_bet')")
    channel_columns = {row["name"] for row in conn.execute("PRAGMA table_info(channels)").fetchall()}
    if "expires_at" not in channel_columns:
        conn.execute("ALTER TABLE channels ADD COLUMN expires_at TEXT")
    user_columns = {row["name"] for row in conn.execute("PRAGMA table_info(users)").fetchall()}
    if "casino_banned" not in user_columns:
        conn.execute("ALTER TABLE users ADD COLUMN casino_banned INTEGER NOT NULL DEFAULT 0")
    if "casino_coins" not in user_columns:
        conn.execute("ALTER TABLE users ADD COLUMN casino_coins INTEGER NOT NULL DEFAULT 0")
    if "last_bonus_at" not in user_columns:
        conn.execute("ALTER TABLE users ADD COLUMN last_bonus_at TEXT")
    if "bonus_streak" not in user_columns:
        conn.execute("ALTER TABLE users ADD COLUMN bonus_streak INTEGER NOT NULL DEFAULT 0")
    if "tasks_done" not in user_columns:
        # Счётчик ВСЕХ выполненных заданий (локальные + «Заработать звёзды»).
        conn.execute("ALTER TABLE users ADD COLUMN tasks_done INTEGER NOT NULL DEFAULT 0")
        for r in conn.execute("SELECT user_id, completed_tasks FROM users").fetchall():
            try:
                done = len(json.loads(r["completed_tasks"] or "[]"))
            except Exception:
                done = 0
            if done:
                conn.execute("UPDATE users SET tasks_done=? WHERE user_id=?", (done, r["user_id"]))
    settings_columns = {row["name"] for row in conn.execute("PRAGMA table_info(settings)").fetchall()}
    for column, ddl in (
        ("bonus_base", "INTEGER NOT NULL DEFAULT 1000"),
        ("bonus_step", "INTEGER NOT NULL DEFAULT 200"),
        ("bonus_max_streak", "INTEGER NOT NULL DEFAULT 7"),
        ("duel_fee_percent", "REAL NOT NULL DEFAULT 0"),
        ("referral_tasks_required", "INTEGER NOT NULL DEFAULT 5"),
        ("withdraw_fee_percent", "REAL NOT NULL DEFAULT 0"),
        ("star_rate", "INTEGER NOT NULL DEFAULT 10000"),
    ):
        if column not in settings_columns:
            conn.execute(f"ALTER TABLE settings ADD COLUMN {column} {ddl}")
    # Комиссия на вывод: сколько монет сверх суммы заявки списано с игрока (нужно для точного возврата).
    for table in ("withdrawals", "casino_withdrawals"):
        cols = {row["name"] for row in conn.execute(f"PRAGMA table_info({table})").fetchall()}
        if "fee_coins" not in cols:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN fee_coins INTEGER NOT NULL DEFAULT 0")
        if "rate" not in cols:
            # Курс (🪙 за 1 ⭐) на момент заявки: возврат при отказе идёт по нему, а не по текущему курсу.
            conn.execute(f"ALTER TABLE {table} ADD COLUMN rate INTEGER")
    conn.execute(
        "CREATE TABLE IF NOT EXISTS duels (id INTEGER PRIMARY KEY AUTOINCREMENT, chat_id INTEGER NOT NULL, "
        "message_id INTEGER, challenger_id INTEGER NOT NULL, opponent_id INTEGER NOT NULL, bet INTEGER NOT NULL, "
        "status TEXT NOT NULL DEFAULT 'pending', created_at TEXT NOT NULL)"
    )
    if not conn.execute("SELECT 1 FROM app_migrations WHERE name='casino_min_bet_point_one'").fetchone():
        conn.execute("UPDATE casino_settings SET min_bet=0.1 WHERE min_bet=0.2")
        conn.execute("INSERT INTO app_migrations(name) VALUES('casino_min_bet_point_one')")
    if not conn.execute("SELECT 1 FROM app_migrations WHERE name='balance_thousandths'").fetchone():
        conn.execute("INSERT INTO app_migrations(name) VALUES('balance_thousandths')")
    if not conn.execute("SELECT 1 FROM app_migrations WHERE name='casino_coins_wallet'").fetchone():
        if had_casino_settings:
            conn.execute("UPDATE casino_settings SET min_bet=MAX(1000, ROUND(min_bet * 10000)), max_bet=MAX(ROUND(max_bet * 10000), MAX(1000, ROUND(min_bet * 10000))) WHERE id=1")
            conn.execute("UPDATE casino_stats SET total_won=ROUND(total_won * 10000), total_lost=ROUND(total_lost * 10000)")
        conn.execute("INSERT INTO app_migrations(name) VALUES('casino_coins_wallet')")
    if not conn.execute("SELECT 1 FROM app_migrations WHERE name='stars_auto_to_coins'").fetchone():
        conn.execute("UPDATE users SET casino_coins = casino_coins + CAST(ROUND(balance * 10000) AS INTEGER), balance = 0 WHERE balance > 0")
        conn.execute("INSERT INTO app_migrations(name) VALUES('stars_auto_to_coins')")
    # Страховка: любое начисление в колонку balance сразу уходит в монеты.
    conn.execute("DROP TRIGGER IF EXISTS trg_sweep_stars")
    conn.execute(
        "CREATE TRIGGER trg_sweep_stars AFTER UPDATE OF balance ON users WHEN NEW.balance > 0 BEGIN "
        "UPDATE users SET casino_coins = casino_coins + CAST(ROUND(NEW.balance * (SELECT star_rate FROM settings WHERE id = 1)) AS INTEGER), balance = 0 "
        "WHERE user_id = NEW.user_id; END"
    )
    conn.commit()

    row = conn.execute("SELECT COUNT(*) AS c FROM users").fetchone()
    users_count = row["c"] if row else 0

    if users_count == 0 and _configured_path.exists() and _configured_path.suffix == ".json":
        migrated = _migrate_from_tinydb_json(_configured_path, conn)
        if migrated:
            print(
                f"[migration] Импортировано {migrated} пользователей из "
                f"{_configured_path} в {_SQLITE_PATH}"
            )

    for balance_row in conn.execute("SELECT user_id, balance FROM users").fetchall():
        rounded_balance = floor_stars(balance_row["balance"])
        if rounded_balance != balance_row["balance"]:
            conn.execute("UPDATE users SET balance=? WHERE user_id=?", (rounded_balance, balance_row["user_id"]))

    conn.execute(
        "INSERT OR IGNORE INTO settings (id, min_referrals, min_tasks, referral_reward, "
        "piarflow_enabled, referral_task_reward) VALUES (1, 5, 3, 2, 1, 0.1)"
    )
    conn.commit()








