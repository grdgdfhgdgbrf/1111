"""Вывод звёзд. Заявка уходит администратору в группу."""
import logging

from aiogram import Router, Bot, F
from aiogram.filters import Command
from aiogram.types import CallbackQuery, Message, InlineKeyboardMarkup, InlineKeyboardButton

from app.config import ADMIN_IDS, PUBLIC_CHANNEL_ID, ADMIN_CHANNEL_ID
from app.handlers.common import check_subscription, show_subscription_message
from app.keyboards.user import withdraw_method_markup, withdraw_amounts_markup, back_markup
from app.services.settings import get_settings
from app.services.users import get_user, update_user, add_stars, spend_stars
from app.services.withdrawals import create_withdrawal, get_withdrawal, update_withdrawal
from app.utils.images import edit_screen
from app.utils.currency import format_coins, format_stars

logger = logging.getLogger(__name__)
GMP_RATE = 3  # Legacy rate for already pending historical requests only.
router = Router(name="withdraw")

def _build_withdraw_text(user: dict) -> str:
    settings = get_settings()
    min_referrals = settings.get("min_referrals", 5)
    min_tasks = settings.get("min_tasks", 3)
    referrals_count = len(user.get("referrals", []))
    tasks_count = len(user.get("completed_tasks", []))
    return (
        "🟣 <b>Вывод</b>\n"
        "▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        f"⭐️ Доступно к выводу: <b>{format_stars(user['balance'])}</b> (баланс {format_coins(user['casino_coins'])} 🪙)\n\n"
        f"📋 Условия: {min_referrals} друзей и {min_tasks} заданий\n"
        f"📊 У тебя: {referrals_count} друзей и {tasks_count} заданий\n\n"
        "Выбери сумму вывода 👇"
    )


@router.callback_query(F.data == "withdraw")
async def withdraw_menu_callback(call: CallbackQuery, bot: Bot) -> None:
    user_id = call.from_user.id
    if not await check_subscription(bot, user_id):
        await show_subscription_message(bot, call.message.chat.id)
        return

    user = get_user(user_id)
    if not user:
        await call.answer("Пользователь не найден. Используйте /start.")
        return

    await edit_screen(
        bot, call.message.chat.id, call.message.message_id,
        _build_withdraw_text(user), reply_markup=withdraw_method_markup(), parse_mode="HTML",
    )


@router.message(Command("withdraw"))
async def withdraw_command(message: Message, bot: Bot) -> None:
    """Открыть меню вывода."""
    user_id = message.from_user.id
    if not await check_subscription(bot, user_id):
        await show_subscription_message(bot, message.chat.id)
        return

    user = get_user(user_id)
    if not user:
        await message.reply("Пользователь не найден. Используйте /start.")
        return

    await message.answer(
        _build_withdraw_text(user),
        reply_markup=withdraw_method_markup(),
        parse_mode="HTML",
    )


@router.callback_query(F.data == "withdraw_method_stars")
async def withdraw_method_stars_callback(call: CallbackQuery) -> None:
    text = (
        "⭐ <b>Вывод звёзд</b>\n"
        "▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        "Выбери сумму для вывода 👇"
    )
    await edit_screen(call.bot, call.message.chat.id, call.message.message_id, text, reply_markup=withdraw_amounts_markup(), parse_mode="HTML")


async def _process_withdrawal(call: CallbackQuery, bot: Bot, amount: int) -> None:
    user_id = call.from_user.id
    if not await check_subscription(bot, user_id):
        await show_subscription_message(bot, call.message.chat.id)
        return

    user = get_user(user_id)
    if not user:
        await call.answer("Пользователь не найден. Используйте /start.")
        return

    settings = get_settings()
    min_referrals = settings.get("min_referrals", 5)
    min_tasks = settings.get("min_tasks", 3)
    referrals_count = len(user.get("referrals", []))
    tasks_count = len(user.get("completed_tasks", []))
    balance = user["balance"]

    back_target = "withdraw_method_stars"

    if user.get("frozen", False):
        await bot.edit_message_text(
            chat_id=call.message.chat.id,
            message_id=call.message.message_id,
            text="Твой аккаунт заморожен, вывод невозможен!",
            reply_markup=back_markup("cancel"),
        )
        return

    if balance < amount:
        await bot.edit_message_text(
            chat_id=call.message.chat.id,
            message_id=call.message.message_id,
            text=f"Недостаточно звезд!\nТвой баланс: {balance} звезд ⭐️",
            reply_markup=back_markup(back_target),
        )
        return

    if referrals_count < min_referrals or tasks_count < min_tasks:
        await bot.edit_message_text(
            chat_id=call.message.chat.id,
            message_id=call.message.message_id,
            text=(
                f"Не хватает условий!\nНужно: {min_referrals} друзей и {min_tasks} заданий\n"
                f"У тебя: {referrals_count} друзей и {tasks_count} заданий"
            ),
            reply_markup=back_markup(back_target),
        )
        return
    if not spend_stars(user_id, amount):
        await bot.edit_message_text(
            chat_id=call.message.chat.id,
            message_id=call.message.message_id,
            text="Недостаточно средств для вывода.",
            reply_markup=back_markup(back_target),
        )
        return
    withdrawal_id = create_withdrawal(user_id, amount, user["username"], method="stars")

    confirm_text = f"✅ Заявка №{withdrawal_id} на {amount} звёзд ⭐️ создана!"
    public_text = (
        f"Заявка №{withdrawal_id}\n"
        f"Пользователь: @{user['username']} | ID: {user_id}\n"
        f"Метод: ⭐ Звёзды\n"
        f"Количество: {amount} звёзд ⭐️\n"
        f"Статус: Ожидание"
    )
    await bot.edit_message_text(
        chat_id=call.message.chat.id,
        message_id=call.message.message_id,
        text=confirm_text,
        reply_markup=back_markup("cancel"),
    )

    public_msg = await bot.send_message(PUBLIC_CHANNEL_ID, public_text)

    markup = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="Отправлено",
                    callback_data=f"withdraw_sent_{withdrawal_id}_{public_msg.message_id}",
                ),
                InlineKeyboardButton(
                    text="Отказано",
                    callback_data=f"withdraw_denied_{withdrawal_id}_{public_msg.message_id}",
                ),
            ]
        ]
    )
    admin_msg = await bot.send_message(ADMIN_CHANNEL_ID, public_text, reply_markup=markup)
    update_withdrawal(withdrawal_id, admin_msg_id=admin_msg.message_id)


@router.callback_query(F.data.regexp(r"^wstars_\d+$"))
async def withdraw_stars_amount_callback(call: CallbackQuery, bot: Bot) -> None:
    await _process_withdrawal(call, bot, amount=int(call.data.split("_")[1]))


@router.callback_query(F.data.startswith("withdraw_sent_") | F.data.startswith("withdraw_denied_"))
async def withdraw_admin_decision_callback(call: CallbackQuery, bot: Bot) -> None:
    if call.from_user.id not in ADMIN_IDS:
        return

    parts = call.data.split("_")
    action = parts[1]
    withdrawal_id = int(parts[2])
    public_msg_id = int(parts[3])

    withdrawal = get_withdrawal(withdrawal_id)
    if not withdrawal:
        await call.answer("Заявка не найдена.")
        return

    status = "Звезды отправлены" if action == "sent" else "Отказано"
    update_withdrawal(withdrawal_id, status=status)

    target_user_id = withdrawal["user_id"]
    stars = withdrawal["stars"]
    method = withdrawal.get("method", "stars")
    gmp_amount = withdrawal.get("gmp_amount")

    if method == "gmp":
        public_text = (
            f"Заявка №{withdrawal_id}\n"
            f"Пользователь: @{withdrawal['username']} | ID: {target_user_id}\n"
            f"Метод: 💎 GMP\n"
            f"Количество: {gmp_amount} GMP (списано {stars} ⭐️)\n"
            f"Курс: 1 ⭐️ = {GMP_RATE} GMP\n"
            f"Статус: {status}"
        )
    else:
        public_text = (
            f"Заявка №{withdrawal_id}\n"
            f"Пользователь: @{withdrawal['username']} | ID: {target_user_id}\n"
            f"Метод: ⭐ Звёзды\n"
            f"Количество: {stars} звезд ⭐️\n"
            f"Статус: {status}"
        )

    await bot.edit_message_text(chat_id=PUBLIC_CHANNEL_ID, message_id=public_msg_id, text=public_text)
    await bot.edit_message_text(chat_id=ADMIN_CHANNEL_ID, message_id=call.message.message_id, text=public_text)

    if action == "sent":
        await bot.send_message(target_user_id, f"✅ Заявка №{withdrawal_id} выполнена!")
    else:
        await bot.send_message(target_user_id, f"❌ Заявка №{withdrawal_id} отклонена.")
        user = get_user(target_user_id)
        if user and not user.get("frozen", False):
            add_stars(target_user_id, stars)

