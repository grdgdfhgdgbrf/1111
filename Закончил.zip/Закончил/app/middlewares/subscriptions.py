"""Block bot features until a user joins every active required channel."""
from typing import Any, Awaitable, Callable

from aiogram import BaseMiddleware
from aiogram.types import CallbackQuery, Message, TelegramObject

from app.config import ADMIN_IDS
from app.handlers.common import check_subscription, show_subscription_message


_EXTRA_WORDS = {
    "перевод", "перевести", "передать", "кинуть", "скинуть", "вывод", "б", "баланс", "balance",
    "профиль", "проф", "profile", "игры", "казино", "games", "выдать", "выдай", "начислить",
    "инфо", "инфа", "info", "бан", "разбан",
    "помощь", "хелп", "команды", "help",
    "топ", "богачи", "top", "бонус", "bonus", "ежедневка", "daily", "дуэль", "дуэли", "duel", "вызвать",
}


def _looks_like_command(text: str) -> bool:
    """Команда со слэшем или одно из ключевых слов бота (игры, перевод, вывод...)."""
    if not text:
        return False
    first = text.split(maxsplit=1)[0].lower()
    if first.startswith("/"):
        return True
    from app.handlers.casino import GAME_ALIASES
    return first in _EXTRA_WORDS or first in GAME_ALIASES


class RequiredSubscriptionMiddleware(BaseMiddleware):
    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        user = event.from_user if isinstance(event, (Message, CallbackQuery)) else None
        if not user or user.id in ADMIN_IDS:
            return await handler(event, data)

        if isinstance(event, Message):
            text = event.text or ""
            command = text.split(maxsplit=1)[0].split("@", 1)[0].lower() if text else ""
            if command == "/start":
                return await handler(event, data)
            if event.chat.type != "private" and not _looks_like_command(text):
                # Обычная болтовня в группе: ничего не требуем и ничего не отвечаем.
                return await handler(event, data)
            chat_id = event.chat.id
        elif isinstance(event, CallbackQuery):
            if event.data == "check_subscription":
                return await handler(event, data)
            if not event.message:
                return await handler(event, data)
            chat_id = event.message.chat.id
        else:
            return await handler(event, data)

        bot = data.get("bot") or event.bot
        if await check_subscription(bot, user.id):
            return await handler(event, data)

        await show_subscription_message(bot, chat_id)
        if isinstance(event, CallbackQuery):
            await event.answer("Сначала подпишись на обязательные каналы.", show_alert=True)
        return None
