"""Профиль, реферальная программа, топ рефереров, заработок звёзд и команды меню."""
import logging
from datetime import datetime, timedelta

from aiogram import Router, Bot, F
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from app.handlers.common import (
    check_subscription,
    show_subscription_message,
    show_main_menu,
    show_earn_tasks,
    get_bot_username,
)
from app.keyboards.user import back_markup, main_menu_markup, top_period_markup
from app.services.settings import get_settings
from app.services.users import get_user, get_all_users
from app.services.withdrawals import get_user_withdrawals
from app.utils.currency import format_coins, format_stars

logger = logging.getLogger(__name__)
router = Router(name="menu")



def _build_profile_text(user: dict) -> str:
    reg_date = datetime.fromisoformat(user["registration_date"]).strftime("%m.%d.%Y")
    referrals_count = len(user.get("referrals", []))
    tasks_count = len(user.get("completed_tasks", []))
    withdrawals_count = len(
        [w for w in get_user_withdrawals(user["user_id"]) if w["status"] == "Звезды отправлены"]
    )
    return (
        "🔵 <b>Мой профиль</b>\n"
        "▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        f"🆔 ID: <code>{user['user_id']}</code>\n"
        f"📅 Регистрация: {reg_date}\n\n"
        f"💰 Баланс: <b>{format_coins(user['casino_coins'])} 🪙</b> (≈ {format_stars(user['balance'])} ⭐ к выводу)\n"
        f"✅ Выполнено заданий: {tasks_count}\n"
        f"👥 Приглашено друзей: {referrals_count}\n\n"
        "🏆 <b>Статистика</b>\n"
        f"💸 Всего выводов: {withdrawals_count}"
    )


async def _build_referral_text(bot: Bot, user: dict) -> str:
    settings = get_settings()
    referral_reward = settings.get("referral_reward", 1)
    referrals_count = len(user.get("referrals", []))

    bot_username = await get_bot_username(bot)
    referral_link = f"https://t.me/{bot_username}?start={user['user_id']}"
    return (
        "👥 <b>Реферальная программа</b>\n"
        "▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        f"Приглашай друзей и получай {format_stars(referral_reward)} ⭐ после того, как приглашённый выполнит 5 заданий.\n\n"
        "🔗 <b>Твоя реферальная ссылка</b>\n"
        "<i>Нажми, чтобы скопировать ссылку</i>\n"
        f"<code>{referral_link}</code>\n\n"
        "📊 <b>Статистика</b>\n"
        f"├ 👥 Успешных рефералов: {referrals_count}\n"
        f"└ ⭐️ Оплата за одного: {format_stars(referral_reward)}"
    )


def _build_top_text(period: str) -> str:
    now = datetime.now()
    periods = {
        "day": (timedelta(days=1), "Топ-5 за сутки"),
        "week": (timedelta(weeks=1), "Топ-5 за неделю"),
        "month": (timedelta(days=30), "Топ-5 за месяц"),
    }
    time_delta, title = periods.get(period, periods["day"])

    all_users = get_all_users()
    top_users = []
    for user in all_users:
        recent_referrals = []
        for r in user.get("referrals", []):
            referred = get_user(r)
            if referred and now - datetime.fromisoformat(referred["registration_date"]) <= time_delta:
                recent_referrals.append(r)
        if recent_referrals:
            name = f"{user['first_name']} {user['last_name']}".strip()
            top_users.append((name, len(recent_referrals)))

    top_users.sort(key=lambda x: x[1], reverse=True)
    top_5 = top_users[:5]

    if not top_5:
        return f"🏆 <b>{title}</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬\nПока нет данных для топа!"

    return f"🏆 <b>{title}</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n" + "\n".join(
        f"{'🥇🥈🥉'[i:i + 1] if i < 3 else f'{i + 1}.'} {name} — {ref} друзей"
        for i, (name, ref) in enumerate(top_5)
    )



@router.callback_query(F.data == "earn_stars")
async def earn_stars_callback(call: CallbackQuery, bot: Bot, state: FSMContext) -> None:
    user_id = call.from_user.id
    if not await check_subscription(bot, user_id):
        await show_subscription_message(bot, call.message.chat.id)
        return
    await call.answer()
    try:
        await bot.delete_message(call.message.chat.id, call.message.message_id)
    except Exception:
        pass
    shown = await show_earn_tasks(bot, call.message.chat.id, user_id, state)
    if not shown:
        await bot.send_message(call.message.chat.id, "😔 Сейчас нет доступных заданий. Загляните позже!")


@router.callback_query(F.data == "profile")
async def profile_callback(call: CallbackQuery, bot: Bot) -> None:
    user_id = call.from_user.id
    if not await check_subscription(bot, user_id):
        await show_subscription_message(bot, call.message.chat.id)
        return

    user = get_user(user_id)
    if not user:
        await call.answer("Пользователь не найден. Используйте /start.")
        return

    await bot.edit_message_text(
        chat_id=call.message.chat.id,
        message_id=call.message.message_id,
        text=_build_profile_text(user),
        reply_markup=back_markup("cancel"),
        parse_mode="HTML",
    )


@router.callback_query(F.data == "referral")
async def referral_callback(call: CallbackQuery, bot: Bot) -> None:
    user_id = call.from_user.id
    if not await check_subscription(bot, user_id):
        await show_subscription_message(bot, call.message.chat.id)
        return

    user = get_user(user_id)
    if not user:
        await call.answer("Пользователь не найден. Используйте /start.")
        return

    await bot.edit_message_text(
        chat_id=call.message.chat.id,
        message_id=call.message.message_id,
        text=await _build_referral_text(bot, user),
        reply_markup=back_markup("cancel"),
        parse_mode="HTML",
    )


@router.callback_query(F.data.startswith("top_"))
async def top_callback(call: CallbackQuery, bot: Bot) -> None:
    period = call.data.split("_")[1]
    await bot.edit_message_text(
        chat_id=call.message.chat.id,
        message_id=call.message.message_id,
        text=_build_top_text(period),
        reply_markup=top_period_markup(period),
        parse_mode="HTML",
    )


@router.callback_query(F.data == "cancel")
async def cancel_callback(call: CallbackQuery, bot: Bot) -> None:
    menu_text = (
        "🏠 <b>Главное меню</b>\n"
        "▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
        "Выбирай действие ниже 👇"
    )
    await bot.edit_message_text(
        chat_id=call.message.chat.id,
        message_id=call.message.message_id,
        text=menu_text,
        reply_markup=main_menu_markup(),
        parse_mode="HTML",
    )


@router.callback_query(F.data == "none")
async def none_callback(call: CallbackQuery) -> None:
    await call.answer()



@router.message(Command("menu"))
async def menu_command(message: Message, bot: Bot) -> None:
    """Открыть главное меню."""
    user_id = message.from_user.id
    if not await check_subscription(bot, user_id):
        await show_subscription_message(bot, message.chat.id)
        return
    await show_main_menu(bot, message.chat.id)


@router.message(Command("earn"))
async def earn_command(message: Message, bot: Bot, state: FSMContext) -> None:
    """Показать доступные задания PiarFlow."""
    user_id = message.from_user.id
    if not await check_subscription(bot, user_id):
        await show_subscription_message(bot, message.chat.id)
        return
    shown = await show_earn_tasks(bot, message.chat.id, user_id, state)
    if not shown:
        await message.answer("😔 Сейчас нет доступных заданий. Загляните позже!")


@router.message(Command("profile"))
async def profile_command(message: Message, bot: Bot) -> None:
    """Показать профиль пользователя."""
    user_id = message.from_user.id
    if not await check_subscription(bot, user_id):
        await show_subscription_message(bot, message.chat.id)
        return

    user = get_user(user_id)
    if not user:
        await message.reply("Пользователь не найден. Используйте /start.")
        return

    await message.answer(
        _build_profile_text(user),
        reply_markup=back_markup("cancel"),
        parse_mode="HTML",
    )


@router.message(Command("referral"))
async def referral_command(message: Message, bot: Bot) -> None:
    """Показать реферальную ссылку и статистику."""
    user_id = message.from_user.id
    if not await check_subscription(bot, user_id):
        await show_subscription_message(bot, message.chat.id)
        return

    user = get_user(user_id)
    if not user:
        await message.reply("Пользователь не найден. Используйте /start.")
        return

    await message.answer(
        await _build_referral_text(bot, user),
        reply_markup=back_markup("cancel"),
        parse_mode="HTML",
    )


@router.message(Command("top"))
async def top_command(message: Message) -> None:
    """Показать топ рефереров за сутки."""
    await message.answer(
        _build_top_text("day"),
        reply_markup=top_period_markup("day"),
        parse_mode="HTML",
    )


